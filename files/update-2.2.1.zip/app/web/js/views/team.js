// Team songbook on the desktop: approve songs sent from the team phones, publish the church library to GitHub.
import { S, h, toast, modal, saveSong, native } from "../core.js";
import { stripChords } from "../chords.js";

const T = () => native?.team;
const ago = (iso) => { const d = (Date.now() - new Date(iso)) / 60000; return d < 60 ? `${Math.max(1, Math.round(d))} min ago` : d < 1440 ? `${Math.round(d / 60)} h ago` : new Date(iso).toLocaleDateString(); };
const norm = (t) => (t || "").replace(/\[[^\]]*\]/g, "").replace(/^\s*[\d१-९]+[.)\s]+/, "").replace(/[^\p{L}\p{M}\p{N}]+/gu, "").toLowerCase();
// the same song already in the songbook? (same title, or the same first line)
function findDuplicate(song) {
  const v = song?.versions?.[song.lang] || Object.values(song?.versions || {})[0]; if (!v) return null;
  const t = norm(v.title || song.title), l = norm(v.sections?.[0]?.lines?.[0]);
  return S.songs.find(s => s.id !== song.id && Object.values(s.versions || {}).some(x => (t && norm(x.title) === t) || (l && l.length > 8 && norm(x.sections?.[0]?.lines?.[0]) === l))) || null;
}
const preview = (song) => { const v = song?.versions?.[song.lang] || Object.values(song?.versions || {})[0]; return (v?.sections || []).slice(0, 2).map(s => `[${s.label}]\n` + s.lines.slice(0, 4).map(stripChords).join("\n")).join("\n\n"); };

export async function inboxCount() { if (!T()) return 0; const st = await T().status(); if (!st.hasToken) return 0; const r = await T().inbox(); return r.ok ? r.items.length : 0; }

export async function openInbox(onSelect, onChange) {
  if (!T()) return toast("The song inbox works in the desktop app");
  const st = await T().status(); if (!st.hasToken) return modal("Song inbox", h("p", { class: "muted" }, "Add the GitHub team key in Settings → Team songbook first."), [{ label: "OK" }]);
  const body = h("div", { class: "col", style: "max-height:66vh;overflow:auto;padding-right:4px" }, h("div", { class: "muted" }, "Loading songs from the team phones…"));
  const close = modal("Song inbox — from the team phones", body, [{ label: "Close" }]); close.firstChild.style.width = "min(760px, 92vw)";
  const r = await T().inbox();
  body.innerHTML = "";
  if (!r.ok) { body.append(h("div", { class: "muted" }, r.error)); return; }
  if (!r.items.length) { body.append(h("div", { class: "muted" }, "Nothing waiting. New songs from the team phones appear here.")); return; }
  for (const it of r.items) {
    const song = it.song || {}; const exists = S.songs.find(s => s.id === song.id); const dup = !exists && findDuplicate(song);
    const row = h("div", { class: "card col", style: "gap:6px" },
      h("div", { class: "row" }, h("b", { style: "flex:1" }, song.title || "Untitled"),
        h("span", { class: "chip" }, it.kind === "edit" || exists ? "Correction" : "New song"),
        h("span", { class: "dim", style: "font-size:12px" }, `${it.by || "Team"} · ${ago(it.at)}`)),
      it.note ? h("div", { class: "muted", style: "font-size:12.5px" }, "Note: " + it.note) : null,
      dup ? h("div", { style: "font-size:12.5px;color:#d97706" }, `⚠ Looks like a song already in the songbook: ${(dup.books || []).map(b => b.book + " " + b.num).join(", ")} “${dup.title}”. Reject it, or use “Add and edit” if it really is different.`) : null,
      h("pre", { style: "white-space:pre-wrap;font:inherit;font-size:13px;margin:0;max-height:180px;overflow:auto;background:var(--bg2,rgba(0,0,0,.04));padding:8px;border-radius:8px" }, preview(song)),
      h("div", { class: "row" },
        h("button", { class: "btn sm primary", onclick: () => approve(false) }, exists ? "Accept correction" : "Add to songs"),
        h("button", { class: "btn sm", onclick: () => approve(true) }, "Add and edit"),
        h("span", { style: "flex:1" }),
        h("button", { class: "btn sm ghost", onclick: reject }, "Reject")));
    async function approve(edit) {
      const s = { ...(exists || {}), ...song, status: song.status === "fix" ? "fix" : "ok", source: song.source || "team:" + (it.by || "phone") };
      delete s._score; await saveSong(s);
      const d = await T().remove(it.path, it.sha, "approved"); if (!d.ok) toast(d.error);
      row.remove(); onChange?.(); toast(`“${s.title}” added — Publish library to send it to everyone`);
      if (edit) { close.remove(); onSelect?.(s.id, true); }
    }
    async function reject() { const d = await T().remove(it.path, it.sha, "rejected"); if (!d.ok) return toast(d.error); row.remove(); onChange?.(); toast("Rejected"); }
    body.append(row);
  }
}

export async function publishLibrary(btn, out) {
  if (!T()) return;
  const by = S.settings.team?.name || "";
  if (btn) btn.disabled = true;
  T().onStep?.((t) => { if (out) out.textContent = t; });
  const songs = S.songs.filter(s => s.status !== "draft");
  const r = await T().publish(JSON.parse(JSON.stringify(songs)), by, { ...(S.settings.deletedSongs || {}) });
  if (btn) btn.disabled = false;
  const msg = !r.ok ? "Could not publish: " + r.error : r.nothing ? "Nothing new to publish — the library is up to date." : `Published library ${r.version}: ${r.added} new, ${r.changed} changed, ${r.removed || 0} removed (${r.total.toLocaleString()} songs). Other computers get it within 2 hours, phones when they open the songbook.`;
  if (out) out.textContent = msg; toast(msg.split(".")[0]);
  return r;
}

export function teamCard() {
  const box = h("div", { class: "card col" });
  if (!T()) return box;
  const render = async () => {
    const st = await T().status(); S.settings.team ||= {};
    const tok = h("input", { class: "input", type: "password", placeholder: st.hasToken ? "•••••••• (saved — paste a new one to replace)" : "Paste the GitHub key (github_pat_…)", autocomplete: "off" });
    const inbox = h("input", { class: "input", value: st.inbox });
    const name = h("input", { class: "input", value: S.settings.team.name || "", placeholder: "e.g. Media desk" });
    const books = Object.keys(S.books || {}).length ? S.books : { RH: "Revival Hindi Songbook" };
    const newBook = h("select", { class: "input" }, ...Object.entries(books).map(([k, v]) => h("option", { value: k, selected: k === (S.settings.team.newBook || "RH") }, `${k} — ${v}`)));
    newBook.onchange = async () => { S.settings.team.newBook = newBook.value; (await import("../core.js")).saveSettings(); const { nextBookNumber } = await import("../core.js"); toast(`New songs will be numbered from ${newBook.value} ${nextBookNumber().num}`); };
    const out = h("div", { class: "muted", style: "font-size:12.5px;min-height:18px" }, st.lastPublish ? `Last published: library ${st.lastPublish.version} · ${new Date(st.lastPublish.at).toLocaleString()} · ${st.lastPublish.added} new, ${st.lastPublish.changed} changed` : "");
    const pub = h("button", { class: "btn primary", disabled: !st.hasToken, onclick: () => publishLibrary(pub, out) }, "Publish library to everyone");
    box.innerHTML = "";
    box.append(h("div", { style: "font-weight:650;font-size:14px" }, "Team songbook & publishing"),
      h("div", { class: "muted", style: "font-size:12.5px" }, "Songs added on the team phones wait in Songs → Inbox. After approving, Publish sends the locked library to GitHub; every computer and phone then gets the new songs."),
      h("div", { class: "row" }, h("label", { class: "f", style: "flex:2" }, "GitHub key", tok), h("label", { class: "f", style: "flex:2" }, "Inbox repository", inbox), h("label", { class: "f", style: "flex:1" }, "This desk's name", name)),
      h("div", { class: "row" },
        h("button", { class: "btn", onclick: async () => { S.settings.team.name = name.value.trim(); const { saveSettings } = await import("../core.js"); saveSettings(); await T().set(tok.value || null, inbox.value); const c = await T().check(); toast(c.ok ? "Team key works ✓" : c.error); render(); } }, "Save & test"),
        st.hasToken ? h("button", { class: "btn ghost", onclick: async () => { await T().set("", null); render(); } }, "Remove key") : null,
        h("button", { class: "btn", onclick: () => openInbox() }, "Open inbox"), pub),
      h("label", { class: "f" }, "New songs get the next number in", newBook),
      out,
      h("div", { class: "dim", style: "font-size:11.5px" }, "Key: github.com → Settings → Developer settings → Fine-grained tokens → only the repositories “revival-song-inbox” and “revival-worship-releases”, permission Contents: Read and write. It stays on this computer."));
  };
  render();
  return box;
}
