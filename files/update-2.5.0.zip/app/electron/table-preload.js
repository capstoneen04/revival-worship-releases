// Runs inside The Table window. Adds a small control bar:
//   ▣ Lower third · ▶ Projector · ✕ Clear  — sends the selected text (or the paragraph you clicked) straight to the screen
//   ⇣ Follow — while on, the paragraph at the reading line goes on screen as you scroll (after you stop for a moment)
// The sermon title and date code are taken from the result / page the text belongs to (not the first one on the page).
const { ipcRenderer } = require("electron");

const CODE_RE = /\b(\d{2}-\d{4}[A-Z]?)\b/;
const clean = (t) => (t || "").replace(/\s+/g, " ").trim();
const titleCase = (t) => t === t.toUpperCase() ? t.toLowerCase().replace(/(^|[\s(-])([a-z])/g, (m, a, b) => a + b.toUpperCase()) : t;

// "59-0611 The Time Of Decision 57-58" → { code, title, range }   (search hits add the paragraph range at the end)
function parseHeader(t) {
  t = clean(t); const code = (t.match(CODE_RE) || [])[1] || "";
  let rest = clean(t.replace(CODE_RE, "")).replace(/^[\s\-–|·:]+/, "");
  const rm = rest.match(/\s(\d{1,4})(?:\s*-\s*(\d{1,4}))?$/); const range = rm ? rm[1] : "";
  if (rm) rest = rest.slice(0, rm.index);
  return { code, title: titleCase(clean(rest.replace(/[\s\-–|·:]+$/, ""))), range };
}
const isHeader = (el) => { const t = clean(el.innerText); return t && t.length < 160 && CODE_RE.test(t) && ![...el.children].some(c => CODE_RE.test(c.innerText || "")); };
const hasTitle = (el) => /[A-Za-z]{3,}/.test(clean(el.innerText).replace(CODE_RE, ""));
// the sermon a node belongs to: the nearest header (date code + title) BEFORE it inside the same search hit / sermon panel —
// not simply the first one on the page (that was the "wrong title" bug)
function sermonFor(node) {
  const start = node && (node.nodeType === 1 ? node : node.parentElement);
  for (let n = start, i = 0; n && n !== document.documentElement && i < 10; n = n.parentElement, i++) {
    const before = [...n.querySelectorAll("*")].filter(el => isHeader(el) && (el.compareDocumentPosition(start) & Node.DOCUMENT_POSITION_FOLLOWING) && el.getBoundingClientRect().height);
    if (!before.length) continue;
    const titled = before.filter(hasTitle);
    const h = parseHeader((titled.length ? titled[titled.length - 1] : before[before.length - 1]).innerText);
    if (!h.title) { const bar = document.querySelector("[class*=sermon-title-bar]"); if (bar) { const b = parseHeader(bar.innerText); if (b.code === h.code) h.title = b.title; } }
    return h;
  }
  const bar = document.querySelector("[class*=sermon-title-bar]");
  if (bar) return parseHeader(bar.innerText);
  return parseHeader(CODE_RE.test(document.title) ? document.title : "");
}
// the paragraph block (starts with its number) that contains a node
function paragraphOf(node) {
  for (let n = node && (node.nodeType === 1 ? node : node.parentElement), i = 0; n && n !== document.body && i < 8; n = n.parentElement, i++) {
    const t = clean(n.innerText); const m = t.match(/^\[?(\d{1,4})\]?\s+(\S.*)$/s);
    if (m && t.length < 6000) return { el: n, para: m[1], text: m[2] };
  }
  return null;
}

let target = "lower", follow = false, lastFollow = "";
function send(action, payload) { ipcRenderer.send("quote", { ...payload, action }); }
function fromSelection() {
  const s = window.getSelection(); const text = clean(s?.toString());
  if (!text) return null;
  const meta = sermonFor(s.anchorNode);
  const p = paragraphOf(s.anchorNode);
  return { text, title: meta.title, code: meta.code, para: p?.para || meta.range || "" };
}
function atReadingLine() {
  const y = Math.round(window.innerHeight * 0.33), x = Math.round(window.innerWidth / 2);
  for (const dy of [0, 20, -20, 45, -45, 80]) { const el = document.elementFromPoint(x, y + dy); const p = paragraphOf(el); if (p) { const meta = sermonFor(p.el); return { text: clean(p.text), title: meta.title, code: meta.code, para: p.para, el: p.el }; } }
  return null;
}

window.addEventListener("DOMContentLoaded", () => {
  const bar = document.createElement("div");
  bar.style.cssText = "position:fixed;right:18px;bottom:18px;z-index:2147483647;display:flex;gap:6px;align-items:center;background:rgba(15,20,35,.92);padding:8px;border-radius:16px;box-shadow:0 8px 28px rgba(0,0,0,.35);font:600 14px -apple-system,system-ui,sans-serif";
  const mk = (label, bg, tip) => { const b = document.createElement("button"); b.textContent = label; b.title = tip; b.style.cssText = `border:0;border-radius:11px;padding:10px 14px;background:${bg};color:#fff;font:inherit;cursor:pointer`; bar.appendChild(b); return b; };
  const lower = mk("▣ Lower third", "#1f6fe0", "Show the selected text on the OBS lower third");
  const proj = mk("▶ Projector", "#d64545", "Show the selected text on the projector");
  const clear = mk("✕ Clear", "#3a4256", "Take the quote off the lower third and the projector");
  const fol = mk("⇣ Follow: off", "#3a4256", "On: the paragraph at the top third of the window goes on screen as you scroll");
  const note = document.createElement("span"); note.style.cssText = "color:#cfd6e6;font-weight:500;padding:0 6px;max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"; bar.appendChild(note);
  const say = (t) => { note.textContent = t; clearTimeout(say.t); say.t = setTimeout(() => (note.textContent = ""), 2500); };
  const go = (action) => {
    target = action;
    const q = fromSelection();
    if (!q) { say("Select some text first"); return; }
    send(action, q); say(`${action === "lower" ? "Lower third" : "Projector"} ✓ ${q.code} ¶${q.para || "?"}`);
  };
  lower.onclick = () => go("lower"); proj.onclick = () => go("project");
  clear.onclick = () => { ipcRenderer.send("quote", { action: "clear" }); say("Cleared"); };
  let marker = null;
  fol.onclick = () => {
    follow = !follow; lastFollow = "";
    fol.textContent = follow ? `⇣ Follow: on (${target === "lower" ? "lower third" : "projector"})` : "⇣ Follow: off";
    fol.style.background = follow ? "#16a34a" : "#3a4256";
    if (!marker) { marker = document.createElement("div"); marker.style.cssText = "position:fixed;left:0;right:0;height:0;border-top:2px dashed rgba(31,111,224,.55);z-index:2147483646;pointer-events:none"; document.body.appendChild(marker); }
    marker.style.top = Math.round(window.innerHeight * 0.33) + "px"; marker.style.display = follow ? "" : "none";
    if (follow) onScrollEnd();
  };
  let t = null;
  const onScrollEnd = () => {
    if (!follow) return;
    const q = atReadingLine(); if (!q || !q.text) return;
    const key = q.code + "|" + q.para + "|" + q.text.slice(0, 40); if (key === lastFollow) return; lastFollow = key;
    const { el, ...payload } = q; send(target, payload); say(`Following ¶${q.para}`);
  };
  window.addEventListener("scroll", () => { if (!follow) return; clearTimeout(t); t = setTimeout(onScrollEnd, 600); }, true);
  document.body.appendChild(bar);
});
