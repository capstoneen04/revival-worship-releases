// Minimal obs-websocket v5 client (OBS Studio 28+ has it built in: Tools → WebSocket Server Settings)
async function sha256b64(s) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return btoa(String.fromCharCode(...new Uint8Array(buf)));
}

export class OBSClient extends EventTarget {
  constructor() { super(); this.ws = null; this.connected = false; this.pending = new Map(); this.n = 0; }
  connect(url = "ws://localhost:4455", password = "") {
    this.disconnect();
    return new Promise((resolve, reject) => {
      let ws;
      try { ws = new WebSocket(url, "obswebsocket.json"); } catch (e) { reject(e); return; }
      this.ws = ws;
      const timer = setTimeout(() => { reject(new Error("Timed out connecting to OBS")); try { ws.close(); } catch { } }, 6000);
      ws.onmessage = async (e) => {
        const m = JSON.parse(e.data);
        if (m.op === 0) { // Hello
          const ident = { rpcVersion: 1, eventSubscriptions: (1 << 2) | (1 << 3) };
          if (m.d.authentication) {
            const { challenge, salt } = m.d.authentication;
            const secret = await sha256b64(password + salt);
            ident.authentication = await sha256b64(secret + challenge);
          }
          ws.send(JSON.stringify({ op: 1, d: ident }));
        } else if (m.op === 2) { // Identified
          clearTimeout(timer); this.connected = true; this.dispatchEvent(new Event("connected")); resolve(true);
        } else if (m.op === 7) { // RequestResponse
          const p = this.pending.get(m.d.requestId);
          if (p) { this.pending.delete(m.d.requestId); m.d.requestStatus.result ? p.res(m.d.responseData || {}) : p.rej(new Error(m.d.requestStatus.comment || "OBS request failed")); }
        } else if (m.op === 5) {
          this.dispatchEvent(new CustomEvent("event", { detail: m.d }));
        }
      };
      ws.onclose = (e) => {
        clearTimeout(timer);
        const was = this.connected; this.connected = false;
        if (!was) reject(new Error(e.code === 4009 ? "Wrong OBS WebSocket password" : "Could not connect to OBS (is OBS open and WebSocket server enabled?)"));
        this.dispatchEvent(new Event("disconnected"));
      };
    });
  }
  disconnect() { if (this.ws) { try { this.ws.close(); } catch { } } this.ws = null; this.connected = false; }
  call(requestType, requestData = {}) {
    if (!this.connected) return Promise.reject(new Error("OBS not connected"));
    const requestId = "r" + (++this.n);
    return new Promise((res, rej) => {
      this.pending.set(requestId, { res, rej });
      this.ws.send(JSON.stringify({ op: 6, d: { requestType, requestId, requestData } }));
      setTimeout(() => { if (this.pending.has(requestId)) { this.pending.delete(requestId); rej(new Error("OBS timeout")); } }, 5000);
    });
  }
  async scenes() { const r = await this.call("GetSceneList"); return { current: r.currentProgramSceneName, list: (r.scenes || []).map(s => s.sceneName).reverse() }; }
  // scene changes fade like Studio Mode: ms = 0 → Cut, else OBS's Fade with that duration (Settings → Transitions)
  async setScene(name) {
    const ms = this.fxMs ?? 300;
    if (this.fxSet !== ms) {
      try { await this.call("SetCurrentSceneTransition", { transitionName: ms ? "Fade" : "Cut" }); if (ms) await this.call("SetCurrentSceneTransitionDuration", { transitionDuration: ms }); this.fxSet = ms; } catch { }
    }
    return this.call("SetCurrentProgramScene", { sceneName: name });
  }
  async addBrowserSource(sceneName, inputName, url, w = 1920, h = 1080) {
    try {
      await this.call("CreateInput", { sceneName, inputName, inputKind: "browser_source", inputSettings: { url, width: w, height: h, reroute_audio: false, shutdown: false, restart_when_active: false, css: "body{background-color:rgba(0,0,0,0);margin:0;overflow:hidden}" }, sceneItemEnabled: true });
      return "created";
    } catch (e) {
      // already exists: add existing input to scene and update URL
      await this.call("SetInputSettings", { inputName, inputSettings: { url, width: w, height: h } });
      try { await this.call("CreateSceneItem", { sceneName, sourceName: inputName, sceneItemEnabled: true }); } catch { }
      return "updated";
    }
  }
}
