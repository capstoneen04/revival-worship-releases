// Sermon page: paste the pastor's details → fills the service, the stream (EN + हिंदी), YouTube title/description and thumbnail.
import { S, h, toast, modal, saveService, saveSettings, uid, onChange, emit, dateCode, present, NOTE_PARTS, hideLower } from "../core.js";
import { parseSermon, splitRefs, matchPerson, moodFor } from "../sermon-parse.js";
import { people, photoUrl, openPeopleEditor } from "../people.js";
import { drawThumbnail, geminiPrompt, MOODS } from "../thumbnail.js";

const EXAMPLE = `18/10/26 M [UN] BRO ROYAL

Title - New Church built up by God-called men, God-trained men.  { P - 25}
Sub - Men who are not afraid to face the fire! and knows His omnipotence and healing power.
Ins - Walking down in the armor of God, may we go as gallant soldiers, to face the enemy.
Scripture - Numbers 27 : 15 - 20 ; 1 Samuel 16 : 12 - 14 ; 1 king 19 : 18 - 21 ; Galatians 2 : 7 - 9.

शीर्षक - नया कलीसिया जो बनाया गया ख़ुदा द्वारा बुलाए गए और प्रशिक्षित पुरुषों द्वारा.  { P - 25}
विषय - वे पुरुष जो आग का सामना करने से नहीं डरते और उसकी सर्वशक्तिमत्ता तथा चंगाई की सामर्थ को जानते हैं.
प्रेरणा - ख़ुदा के हथियारों से लैस होकर, आइए हम दुश्मन का सामना करने के लिए एक वीर सैनिक के रूप में आगे बढ़ें.
पवित्रशास्त्र - गिनती 27:15-20; 1 शमूएल 16:12-14; 1 राजा 19:18-21; गलतियों 2:7-9.`;

export function blankSermon() { return { raw: "", date: new Date().toISOString().slice(0, 10), session: new Date().getHours() < 15 ? "M" : "E", placeCode: "", place: "", preacherId: "", preacherText: "", page: "", meeting: "", en: {}, hi: {}, thumb: { mood: "auto", style: "minimal", photoScale: 0.64, photoX: 0.0, photoY: 0.02, background: "" } }; }
export function currentSermon() { if (!S.service) return blankSermon(); S.service.sermon ||= blankSermon(); S.service.sermon.thumb ||= blankSermon().thumb; return S.service.sermon; }
export function sermonCode(sm) { const [y, m, d] = (sm.date || "").split("-"); return y ? `${y.slice(2)}${m}${d} ${sm.session || "M"}` : dateCode(); }
const MONTHS = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
export function eventLine(sm) { const [y, m] = (sm.date || "").split("-"); const mm = m ? MONTHS[+m - 1] + " " + y : ""; return [(sm.meeting || "Sunday Meeting").toUpperCase(), mm].filter(Boolean).join(" | "); }

// Put the sermon into today's service + stream info
export async function applySermon(sm, person) {
  const b = S.settings.broadcast;
  if (person) { b.speaker = person.name; b.speakerShort = person.short || person.name; }
  b.sermonTitle = sm.en.title || sm.hi.title || b.sermonTitle;
  b.serviceCode = sermonCode(sm);
  if (sm.place) b.place = sm.place;
  if (sm.meeting) b.meeting = sm.meeting;
  await saveSettings();
  const items = S.service.items;
  let it = items.find(x => x.type === "sermon");
  if (!it) { it = { id: uid("it"), type: "sermon" }; items.unshift(it); }
  it.sermon = structuredClone({ ...sm, thumb: undefined, raw: undefined });
  // scriptures as Bible items (KJV + Hindi), right after the sermon notes, no duplicates
  let at = items.indexOf(it) + 1;
  for (const r of splitRefs(sm.en.scripture || "")) {
    if (!r.ref) continue;
    if (items.some(x => x.type === "bible" && x.label === r.label)) continue;
    items.splice(at++, 0, { id: uid("it"), type: "bible", ref: r.ref, label: r.label, version: "both" });
  }
  await saveService();
}

export function youtubeTitles(sm, person) {
  const short = person?.short || person?.name || sm.preacherText || "";
  const t = (sm.en.title || "").replace(/[.]+$/, "");
  const place = [sm.place].filter(Boolean).join(" ");
  return [
    [sermonCode(sm), "Revival Church", short, sm.meeting || "Sunday Meeting", place].filter(Boolean).join(" | "),
    [t, short, sermonCode(sm)].filter(Boolean).join(" | "),
  ].map(x => x.length > 100 ? x.slice(0, 99) + "…" : x);
}
export function youtubeDescription(sm, person) {
  const b = S.settings.broadcast, E = sm.en, H = sm.hi, pg = sm.page ? `  {${sm.page}}` : "";
  const L = [];
  if (E.title) L.push(`${E.title}${pg}`);
  if (E.sub) L.push(`Subject: ${E.sub}`);
  if (E.ins) L.push(`Inspiration: ${E.ins}`);
  if (E.scripture) L.push(`Scripture: ${E.scripture.replace(/\s*:\s*/g, ":").replace(/\s*-\s*/g, "-").replace(/\s*;\s*/g, "; ")}`);
  if (H.title || H.sub) L.push("");
  if (H.title) L.push(`शीर्षक: ${H.title}${pg}`);
  if (H.sub) L.push(`विषय: ${H.sub}`);
  if (H.ins) L.push(`प्रेरणा: ${H.ins}`);
  if (H.scripture) L.push(`पवित्रशास्त्र: ${H.scripture}`);
  L.push("", `Preacher: ${person?.name || sm.preacherText || ""}`);
  L.push(`${b.streamName || "Revival Church Mumbai"} · ${sm.meeting || "Sunday Meeting"} · ${sermonCode(sm)}${sm.place ? " · " + sm.place : ""}`);
  if (b.address) L.push(`Prayer Hall: ${b.address}`);
  if (b.nextService) L.push(`Join us: ${b.nextService}`);
  L.push("", "#RevivalChurchMumbai #TheMessage #Sermon");
  return L.join("\n");
}

export function sermonView(root) {
  const page = h("div", { class: "pagepad sermon-grid" });
  root.appendChild(page);
  const left = h("div", { class: "col", style: "gap:12px;min-width:0" }), right = h("div", { class: "col", style: "gap:12px;min-width:0" });
  page.append(left, right);
  const canvas = h("canvas", { class: "thumb-canvas", width: 1920, height: 1080 });
  let plist = [], drawT = null;

  async function render() {
    plist = await people();
    const sm = currentSermon();
    left.innerHTML = ""; right.innerHTML = "";
    // ---- paste ----
    const ta = h("textarea", { class: "input", rows: 7, placeholder: "Paste the message from the pastor here…\n\n18/10/26 M [UN] BRO ROYAL\nTitle - …\nSub - …\nIns - …\nScripture - …\nशीर्षक - …", style: "font-family:var(--lyric)" });
    ta.value = sm.raw || "";
    left.append(h("div", { class: "card col" },
      h("div", { class: "row", style: "justify-content:space-between" }, h("div", { class: "ct" }, "1 · Paste the sermon details"), h("button", { class: "btn sm ghost", onclick: () => { ta.value = EXAMPLE; } }, "Example")),
      ta,
      h("div", { class: "row" },
        h("button", { class: "btn primary", onclick: async () => {
          const p = parseSermon(ta.value);
          if (!p.en.title && !p.hi.title) return toast("Couldn’t find a “Title -” line");
          const keep = currentSermon();
          const person = matchPerson(p.preacherText, plist);
          Object.assign(keep, { raw: ta.value, date: p.date || keep.date, session: p.session || keep.session, placeCode: p.placeCode, place: p.place || keep.place, preacherText: p.preacherText, preacherId: person?.id || keep.preacherId, page: p.page, en: p.en, hi: p.hi });
          if (keep.thumb.mood === "auto" || !keep.thumb.mood) keep.thumb.mood = "auto";
          await saveService(); toast(person ? `Read — preacher: ${person.name}` : "Read — please choose the preacher"); render();
        } }, "Read details"),
        h("button", { class: "btn ghost", onclick: async () => { S.service.sermon = blankSermon(); await saveService(); render(); } }, "Clear"))));

    // ---- details ----
    const person = plist.find(p => p.id === sm.preacherId) || null;
    const f = (lab, obj, key, o = {}) => {
      const el = h(o.area ? "textarea" : "input", { class: "input", rows: o.area ? 2 : null, type: o.type || null, style: (o.hi ? "font-family:var(--lyric);" : "") + (o.css || ""), placeholder: o.ph || "" });
      el.value = obj[key] || "";
      el.oninput = () => { obj[key] = el.value; dirty(); };
      return h("label", { class: "f", style: o.style || "" }, lab, el);
    };
    const psel = h("select", { class: "input", onchange: e => { if (e.target.value === "__m") { openPeopleEditor(); e.target.value = sm.preacherId || ""; return; } sm.preacherId = e.target.value; dirty(true); } },
      h("option", { value: "" }, sm.preacherText ? `— “${sm.preacherText}” not matched —` : "— choose —"), ...plist.map(p => h("option", { value: p.id, selected: p.id === sm.preacherId }, p.name)), h("option", { value: "__m" }, "Add / edit people…"));
    const sess = h("select", { class: "input", onchange: e => { sm.session = e.target.value; dirty(true); } }, ...[["M", "M · Morning"], ["E", "E · Evening"], ["N", "N · Night"]].map(([k, v]) => h("option", { value: k, selected: sm.session === k }, v)));
    left.append(h("div", { class: "card col" },
      h("div", { class: "ct" }, "2 · Check the details"),
      h("div", { class: "row", style: "align-items:flex-end" }, f("Date", sm, "date", { type: "date", style: "width:150px" }), h("label", { class: "f", style: "width:130px" }, "Session", sess),
        h("label", { class: "f", style: "flex:1;min-width:180px" }, "Preacher", psel)),
      h("div", { class: "row", style: "align-items:flex-end" }, f("Meeting", sm, "meeting", { ph: "Sunday Meeting / Punjab Meetings", style: "flex:1" }), f("Place", sm, "place", { ph: "Ulhasnagar", style: "flex:1" }), f("Page", sm, "page", { ph: "P-25", style: "width:90px" })),
      h("div", { class: "notes-2col" },
        h("div", { class: "col", style: "gap:8px" }, h("div", { class: "ct2" }, "English"),
          f("Title", sm.en, "title", { area: true }), f("Subject", sm.en, "sub", { area: true }), f("Inspiration", sm.en, "ins", { area: true }), f("Scripture", sm.en, "scripture", { area: true })),
        h("div", { class: "col", style: "gap:8px" }, h("div", { class: "ct2" }, "हिन्दी"),
          f("शीर्षक", sm.hi, "title", { area: true, hi: true }), f("विषय", sm.hi, "sub", { area: true, hi: true }), f("प्रेरणा", sm.hi, "ins", { area: true, hi: true }), f("पवित्रशास्त्र", sm.hi, "scripture", { area: true, hi: true }))),
      h("div", { class: "row" },
        h("button", { class: "btn primary", onclick: async () => { await applySermon(sm, person); toast("Added to today’s service: sermon notes + " + splitRefs(sm.en.scripture || "").filter(r => r.ref).length + " scriptures"); } }, "3 · Use for this service"),
        h("span", { class: "dim", style: "font-size:11.5px" }, "Adds the sermon notes and the scriptures (KJV + Hindi) to the service, and sets the speaker, title and date code on every screen."))));

    // ---- show on stream ----
    left.append(h("div", { class: "card col" }, h("div", { class: "ct" }, "On stream while preaching"), sermonButtons(),
      h("div", { class: "dim", style: "font-size:11.5px" }, "Shows as a lower third over the preacher (Sermon scene) or in the side panel (Sermon Split) — in the stream language chosen on the Produce page, with the other language under it.")));

    // ---- YouTube ----
    const [t1, t2] = youtubeTitles(sm, person), desc = youtubeDescription(sm, person);
    const copy = (txt, what) => navigator.clipboard.writeText(txt).then(() => toast(what + " copied"));
    right.append(h("div", { class: "card col" },
      h("div", { class: "ct" }, "YouTube"),
      ...[t1, t2].map((t, i) => h("div", { class: "row", style: "flex-wrap:nowrap" }, h("div", { class: "copyable", style: "flex:1" }, t), h("span", { class: "dim", style: "font-size:11px;width:44px;text-align:right" }, t.length + "/100"), h("button", { class: "btn sm", onclick: () => copy(t, "Title") }, i ? "Copy (title first)" : "Copy title"))),
      h("div", { class: "row", style: "align-items:flex-start;flex-wrap:nowrap" }, h("pre", { class: "copyable", style: "flex:1;white-space:pre-wrap;max-height:220px;overflow:auto;margin:0;font-family:var(--lyric)" }, desc), h("button", { class: "btn sm", onclick: () => copy(desc, "Description") }, "Copy"))));

    // ---- thumbnail ----
    const th = sm.thumb;
    const mood = th.mood === "auto" || !th.mood ? (S.settings.broadcast.themeThumb?.mood || moodFor(sm.en.title)) : th.mood;
    let bgs = [];
    try { bgs = (await fetch("/api/media?dir=Thumbnails/Backgrounds").then(r => r.json())).files; } catch { }
    const moodSel = h("select", { class: "input", onchange: e => { th.mood = e.target.value; th.background = ""; dirty(true); } },
      h("option", { value: "auto", selected: th.mood === "auto" }, `Automatic from the title (${MOODS[mood].name.replace(/ \(.*/, "")})`), ...Object.entries(MOODS).map(([k, m]) => h("option", { value: k, selected: th.mood === k }, m.name)));
    const bgSel = h("select", { class: "input", onchange: e => { th.background = e.target.value; dirty(true); } }, h("option", { value: "" }, "Bokeh (made by the app)"), ...bgs.map(b => h("option", { value: b.url, selected: th.background === b.url }, b.name)));
    const bgFile = h("input", { type: "file", accept: "image/*", style: "display:none", onchange: async e => {
      const file = e.target.files[0]; if (!file) return;
      const r = await fetch(`/api/upload?path=${encodeURIComponent("Thumbnails/Backgrounds/" + file.name.replace(/[^\w .()-]+/g, "_"))}`, { method: "POST", body: file }).then(r => r.json());
      th.background = r.url; dirty(true); render();
    } });
    const sl = (lab, key, min, max, step) => h("label", { class: "row", style: "gap:8px;flex-wrap:nowrap" }, h("span", { class: "muted", style: "width:84px;font-size:12px" }, lab), h("input", { type: "range", min, max, step, value: th[key] ?? 0, style: "flex:1", oninput: e => { th[key] = +e.target.value; dirty(); } }));
    right.append(h("div", { class: "card col" },
      h("div", { class: "row", style: "justify-content:space-between" }, h("div", { class: "ct" }, "Thumbnail"),
        h("div", { class: "seg" }, ...[["minimal", "Minimal"], ["bilingual", "English + हिंदी"]].map(([k, v]) => h("button", { class: "btn sm" + (th.style === k ? " on" : ""), onclick: () => { th.style = k; dirty(true); } }, v)))),
      h("div", { class: "screen", style: "border-radius:8px" }, canvas),
      h("div", { class: "row", style: "flex-wrap:nowrap" }, h("label", { class: "f", style: "flex:1" }, "Colour", moodSel), h("label", { class: "f", style: "flex:1" }, "Background", bgSel)),
      h("div", { class: "row" }, h("button", { class: "btn sm", onclick: () => bgFile.click() }, "Upload background (e.g. from Gemini)…"), bgFile,
        h("button", { class: "btn sm ghost", onclick: () => copy(geminiPrompt({ title: sm.en.title, preacher: person?.name, event: eventLine(sm), mood }), "Gemini prompt") }, "Copy Gemini prompt")),
      person?.photo ? h("div", { class: "col", style: "gap:4px" }, sl("Preacher size", "photoScale", 0.5, 1.3, 0.01), sl("Move ↔", "photoX", -0.4, 0.4, 0.005), sl("Move ↕", "photoY", -0.2, 0.4, 0.005))
        : h("div", { class: "warnline" }, person ? `No photo for ${person.name} yet — `  : "Choose the preacher first. ", person ? h("a", { href: "#", onclick: e => { e.preventDefault(); openPeopleEditor(person.id); } }, "add a cut-out photo") : null),
      h("div", { class: "row" },
        h("button", { class: "btn primary", onclick: saveThumb }, "Save thumbnail"),
        h("button", { class: "btn", onclick: async () => { const blob = await new Promise(r => canvas.toBlob(r, "image/png")); await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]); toast("Thumbnail copied — paste into Figma or YouTube"); } }, "Copy image"),
        h("span", { class: "dim", style: "font-size:11px" }, "1920×1080 JPEG under 2 MB (YouTube’s limit), saved in Media/Thumbnails"))));
    redraw();
  }

  function dirty(full) { clearTimeout(drawT); drawT = setTimeout(async () => { await saveService(); if (full) render(); else redraw(); }, full ? 10 : 150); }
  async function redraw() {
    const sm = currentSermon(), person = plist.find(p => p.id === sm.preacherId), th = sm.thumb;
    await drawThumbnail(canvas, { title: sm.en.title || sm.hi.title, titleHi: sm.hi.title, preacher: person?.name || sm.preacherText, event: eventLine(sm), mood: th.mood === "auto" || !th.mood ? (S.settings.broadcast.themeThumb?.mood || moodFor(sm.en.title)) : th.mood, background: th.background || S.settings.broadcast.themeThumb?.background || "", photo: photoUrl(person), photoScale: th.photoScale, photoX: th.photoX, photoY: th.photoY, style: th.style, seed: sm.en.title });
  }
  async function saveThumb() {
    const sm = currentSermon();
    let q = 0.92, blob;
    do { blob = await new Promise(r => canvas.toBlob(r, "image/jpeg", q)); q -= 0.06; } while (blob.size > 1.9e6 && q > 0.5);
    const name = `${sermonCode(sm).replace(" ", "")} ${(sm.en.title || "thumbnail").replace(/[^\w ,'-]+/g, "").slice(0, 60)}.jpg`;
    try { await fetch(`/api/upload?path=${encodeURIComponent("Thumbnails/" + name)}`, { method: "POST", body: blob }); } catch { }
    const a = h("a", { href: URL.createObjectURL(blob), download: name }); a.click();
    toast(`Saved ${name} (${(blob.size / 1e6).toFixed(1)} MB) in Media/Thumbnails`);
  }

  onChange(w => { if (root.classList.contains("on") && (w === "people" || w === "service")) { if (!document.activeElement || !root.contains(document.activeElement)) render(); } });
  return { onShow() { render(); } };
}

// Title / Subject / Inspiration / Scripture buttons (also used on the Produce page)
export function sermonButtons() {
  const box = h("div", { class: "col", style: "gap:6px" });
  const draw = () => {
    box.innerHTML = "";
    const it = (S.service?.items || []).find(x => x.type === "sermon");
    if (!it) { box.append(h("div", { class: "dim", style: "font-size:12px" }, "Paste the sermon details on the Sermon page and press “Use for this service”.")); return; }
    const parts = NOTE_PARTS.filter(([k]) => it.sermon?.en?.[k] || it.sermon?.hi?.[k]);
    const liveIdx = S.live.key === it.id && !S.live.override ? S.live.index : -1;
    box.append(h("div", { class: "ctl-grid", style: `grid-template-columns:repeat(${parts.length || 1},1fr)` }, ...parts.map(([k, en, hi], i) =>
      h("button", { class: "btn" + (liveIdx === i && S.lowerFollow ? " live" : ""), title: hi, onclick: async () => { await present(it, i, { fromService: true }); if (!S.lowerFollow) { S.lowerFollow = true; } emit("lower"); const { broadcast } = await import("../core.js"); broadcast(); } }, en))),
      h("div", { class: "row", style: "gap:6px;align-items:center" }, h("span", { class: "dim", style: "font-size:11.5px" }, "On stream:"),
        ...[[0, "English + हिंदी together"], [3, "English, then हिंदी after 3 s"]].map(([v, t]) => h("button", { class: "btn sm" + (+(S.settings.notesHindiAfter || 0) === v ? " on" : ""), onclick: async () => { S.settings.notesHindiAfter = v; const c = await import("../core.js"); c.saveSettings(); draw(); } }, t))),
      h("div", { class: "row" }, h("button", { class: "btn sm live", onclick: () => hideLower() }, "Hide from stream"), h("span", { class: "dim", style: "font-size:11.5px" }, (it.sermon?.en?.title || "").slice(0, 60))));
  };
  draw(); onChange(w => { if (w === "live" || w === "lower" || w === "service") draw(); });
  return box;
}
