import { S, h, db, uid, present, showLowerCard, addToService, toast, onChange, native } from "../core.js";

const CODE_RE = /\b(\d{2}-\d{4}[A-Z]?|\d{2}-\d{2}-\d{2,4})\b/;

export function messageView(root) {
  const text = h("textarea", { class: "input quote-text", rows: 9, placeholder: "Paste or capture a quote from The Table…" });
  const title = h("input", { class: "input", placeholder: "Sermon title (e.g. The Rapture)", style: "flex:1" });
  const code = h("input", { class: "input", placeholder: "Date code 65-1204", style: "width:150px" });
  const para = h("input", { class: "input", placeholder: "¶", style: "width:70px" });
  const libQ = h("input", { class: "input", type: "search", placeholder: "Search saved quotes", style: "width:100%" });
  const lib = h("div", { class: "scroll list" });
  let editingId = null;

  const tableCard = h("div", { class: "card col" },
    h("div", { style: "font-weight:650;font-size:14px" }, "The Table (Voice of God Recordings)"),
    native?.openTable
      ? h("div", { class: "col" }, h("div", { class: "muted" }, "Opens The Table in its own window. Sign in as usual, select a paragraph, then press ▣ Lower third or ▶ Projector in the bar at the bottom right — it goes on screen straight away (✕ Clear takes it off). Turn on ⇣ Follow and the paragraph at the dashed line goes on screen as you scroll. Every quote is kept in the Quote library here."),
        h("div", { class: "row" }, h("button", { class: "btn primary", onclick: () => native.openTable() }, "Open The Table")))
      : h("div", { class: "col" }, h("div", { class: "muted" }, "In the Mac app, The Table opens in its own window with a one-click “Send to Revival” button. In a browser, open it in a new tab, copy a paragraph and paste it below — the date code and paragraph number are picked up automatically."),
        h("div", { class: "row" }, h("a", { class: "btn", href: "https://table.branham.org", target: "_blank", rel: "noopener" }, "Open table.branham.org ↗"),
          h("button", { class: "btn", onclick: async () => { try { const t = await navigator.clipboard.readText(); setQuote({ text: t }); } catch { toast("Paste with ⌘V into the box instead"); } } }, "Paste from clipboard"))));

  root.append(
    h("div", { class: "pagepad", style: "flex:1;display:flex;flex-direction:column;gap:14px;min-width:0" },
      tableCard,
      h("div", { class: "card col" },
        h("div", { style: "font-weight:650;font-size:14px" }, "Quote"),
        text,
        h("div", { class: "row", style: "flex-wrap:nowrap" }, title, code, para),
        h("div", { class: "row" },
          h("button", { class: "btn primary", onclick: () => { const q = cur(); if (!q) return; showLowerCard({ type: "message", kicker: "The Message", lines: [q.text], ref: refOf(q) }); toast("Quote on OBS lower third"); } }, "Lower third"),
          h("button", { class: "btn live", onclick: () => { const q = cur(); if (q) present({ type: "message", ...q }); } }, "▶ Project"),
          h("button", { class: "btn", onclick: () => { const q = cur(); if (q) addToService({ type: "message", ...q }); } }, "+ Service"),
          h("button", { class: "btn", onclick: save }, "Save to library"),
          h("span", { style: "flex:1" }),
          h("button", { class: "btn ghost", onclick: () => { editingId = null; text.value = title.value = code.value = para.value = ""; } }, "Clear")),
        h("div", { class: "dim", style: "font-size:12px" }, "Long quotes are split over several slides automatically; on the lower third they shrink to fit."))),
    h("div", { class: "panel", style: "width:360px;flex:0 0 360px;border-left:1px solid var(--line);border-right:0" },
      h("div", { class: "panel-h" }, h("h2", {}, "Quote library")), h("div", { style: "padding:8px 10px" }, libQ), lib));

  function refOf(q) { return [q.title, q.code, q.para ? `¶${q.para}` : ""].filter(Boolean).join(" · "); }
  function cur() { const t = text.value.trim(); if (!t) { toast("Enter a quote first"); return null; } return { text: t, title: title.value.trim(), code: code.value.trim(), para: para.value.trim() }; }
  function setQuote(q) {
    let t = (q.text || "").trim();
    // pull out leading paragraph number "123 " and date code
    const pm = t.match(/^\[?(\d{1,4})\]?\s+(?=\S)/); if (pm && !q.para) { q.para = pm[1]; t = t.slice(pm[0].length); }
    const cm = (q.title || "").match(CODE_RE) || t.match(CODE_RE); if (cm && !q.code) q.code = cm[1];
    text.value = t; if (q.title) title.value = q.title.replace(CODE_RE, "").replace(/[-–|·]+\s*$/, "").trim(); if (q.code) code.value = q.code; if (q.para) para.value = q.para;
    editingId = null;
  }
  text.addEventListener("paste", () => setTimeout(() => setQuote({ text: text.value, title: title.value, code: code.value, para: para.value }), 0));
  async function save() {
    const q = cur(); if (!q) return;
    await db.put("quotes", { id: editingId || uid("q"), ...q, saved: new Date().toISOString() });
    toast("Saved"); renderLib();
  }
  async function renderLib() {
    const all = (await db.all("quotes")).sort((a, b) => (b.saved || "").localeCompare(a.saved || ""));
    const f = libQ.value.toLowerCase();
    lib.innerHTML = "";
    const hits = all.filter(q => !f || (q.text + " " + q.title + " " + q.code).toLowerCase().includes(f));
    if (!hits.length) lib.appendChild(h("div", { class: "empty" }, all.length ? "No match" : "Saved quotes appear here."));
    hits.forEach(q => lib.appendChild(h("div", { class: "item", onclick: () => { editingId = q.id; text.value = q.text; title.value = q.title || ""; code.value = q.code || ""; para.value = q.para || ""; } },
      h("div", { style: "min-width:0;flex:1" }, h("div", { style: "font-weight:600" }, refOf(q) || "Quote"), h("div", { class: "s", style: "white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden" }, q.text)),
      h("button", { class: "btn sm ghost", onclick: async (e) => { e.stopPropagation(); await db.del("quotes", q.id); renderLib(); } }, "✕"))));
  }
  libQ.oninput = renderLib;
  onChange(w => { if (w && w.quote) { setQuote({ ...w.quote }); } if (w === "quotes" || (w && w.quote)) renderLib(); });
  renderLib();
  return { onShow() { renderLib(); } };
}
