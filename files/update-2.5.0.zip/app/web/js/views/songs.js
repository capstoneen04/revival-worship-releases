import { S, h, saveSong, deleteSong, addToService, present, toast, modal, LANGS, songOpts, onChange, uid, native, nextBookNumber } from "../core.js";
import { openInbox, inboxCount } from "./team.js";
import { bookLabel } from "../search.js";
import { romanize, capitalizeLines } from "../translit.js";
import { krutiToUnicode, looksLikeKruti } from "../krutidev.js";
import { chordSegments, sectionColor, songHasChords, transposeKey, orderLabel, isChord, stripChords, CHORD } from "../chords.js";

export { sectionsToText, textToSections } from "../song-text.js";
import { sectionsToText, textToSections } from "../song-text.js";

export function songsView(root) {
  const inboxBtn = h("button", { class: "btn sm ghost", title: "Songs sent from the team phones", onclick: () => openInbox({
    review: (draft, opts) => { review = { song: draft, ...opts }; selected = draft; mode = "edit"; tabLang = draft.lang; renderList(); renderDetail(); },
    open: (id) => { const s = S.songs.find(x => x.id === id); if (s) select(s); },
    changed: () => refreshInbox(),
  }) }, "Inbox");
  window.rwOpenInbox = () => inboxBtn.click();      // Settings → "Open inbox" opens it here, where Review can open the editor
  const refreshInbox = () => inboxCount().then(n => { inboxBtn.textContent = n ? `Inbox (${n})` : "Inbox"; inboxBtn.classList.toggle("primary", n > 0); }).catch(() => { });
  if (native?.team) setTimeout(refreshInbox, 1500);
  let review = null;     // a song from the inbox being reviewed (not saved until "Save song")
  let selected = null, mode = "view", tabLang = null, filters = { lang: "", book: "", status: "", category: "", tag: "" }, query = "", showChords = true, transpose = 0;
  const list = h("div", { class: "scroll list" });
  const q = h("input", { class: "input", type: "search", placeholder: "Search number, title, any line — Hindi, Hinglish or English", autofocus: true });
  const count = h("span", { class: "dim" });
  const fLang = h("select", { class: "input", style: "flex:1" }, h("option", { value: "" }, "All languages"), ...Object.entries(LANGS).map(([k, v]) => h("option", { value: k }, v)));
  const fBook = h("select", { class: "input", style: "flex:1" }, h("option", { value: "" }, "All books"));
  const fStatus = h("select", { class: "input", style: "flex:1" }, h("option", { value: "" }, "Any status"), h("option", { value: "fix" }, "Needs fixing"), h("option", { value: "review" }, "Not reviewed"), h("option", { value: "ok" }, "Approved"));
  for (const [k, v] of Object.entries(S.books || {})) fBook.appendChild(h("option", { value: k }, v));
  const fCat = h("select", { class: "input", style: "flex:1" }), fTag = h("select", { class: "input", style: "flex:1" });
  function fillCats() {
    const cats = [...new Set(S.songs.map(x => x.category).filter(Boolean))].sort(), tags = [...new Set(S.songs.flatMap(x => x.tags || []))].sort();
    fCat.innerHTML = ""; fCat.append(h("option", { value: "" }, "All categories"), ...cats.map(c => h("option", { value: c, selected: c === filters.category }, c)));
    fTag.innerHTML = ""; fTag.append(h("option", { value: "" }, "All tags"), ...tags.map(c => h("option", { value: c, selected: c === filters.tag }, c)));
  }
  fillCats();
  const detail = h("div", { class: "detail" });
  root.append(
    h("div", { class: "panel left" },
      h("div", { class: "panel-h", style: "flex-direction:column;align-items:stretch" },
        h("div", { class: "search" }, h("span", { html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>' }), q),
        h("div", { class: "row", style: "flex-wrap:nowrap" }, fLang, fBook, fStatus),
        h("div", { class: "row", style: "flex-wrap:nowrap" }, fCat, fTag),
        h("div", { class: "row" }, count, h("span", { style: "flex:1" }), native?.team ? inboxBtn : null, h("button", { class: "btn sm ghost", onclick: () => importSongs() }, "Import…"), h("button", { class: "btn sm", onclick: () => newSong() }, "+ New song"))),
      list),
    detail);

  let timer;
  q.oninput = () => { clearTimeout(timer); timer = setTimeout(() => { query = q.value; renderList(); }, 60); };
  q.onkeydown = e => {
    if (e.key === "Enter") { const first = list.querySelector(".item"); if (first) first.click(); if (e.shiftKey && selected) goLive(selected); }
    if (e.key === "ArrowDown") { e.preventDefault(); moveSel(1); } if (e.key === "ArrowUp") { e.preventDefault(); moveSel(-1); }
  };
  [fLang, fBook, fStatus, fCat, fTag].forEach(s => s.onchange = () => { filters = { lang: fLang.value, book: fBook.value, status: fStatus.value, category: fCat.value, tag: fTag.value }; renderList(); });

  let results = [];
  function renderList() {
    results = S.index.search(query, { ...filters, limit: 400 });
    count.textContent = `${results.length}${results.length === 400 ? "+" : ""} songs`;
    list.innerHTML = "";
    const frag = document.createDocumentFragment();
    for (const { song } of results) {
      const v = song.versions[song.lang] || Object.values(song.versions)[0];
      const first = stripChords(v?.sections?.[0]?.lines?.[0] || "");
      const b = (song.books || [])[0];
      frag.appendChild(h("div", { class: "item" + (selected && selected.id === song.id ? " sel" : ""), "data-id": song.id, onclick: () => select(song), ondblclick: () => goLive(song) },
        h("div", { class: "num" }, b ? String(b.num) : ""),
        h("div", { style: "min-width:0;flex:1" }, h("div", { class: "t" }, song.title), h("div", { class: "s" }, first)),
        h("div", { class: "meta" }, ...Object.keys(song.versions).filter(l => !(song.versions[l].auto)).map(l => h("span", { class: "tag " + l }, l === "hi-Latn" ? "HL" : l.toUpperCase())), song.status === "fix" ? h("span", { class: "tag fix" }, "FIX") : null)));
    }
    list.appendChild(frag);
    if (!results.length) list.appendChild(h("div", { class: "empty" }, "No songs found. Try fewer words, the song number, or Hinglish spelling."));
  }
  function moveSel(d) {
    const i = results.findIndex(r => selected && r.song.id === selected.id);
    const n = results[Math.max(0, Math.min(results.length - 1, i + d))];
    if (n) { select(n.song); list.querySelector(`[data-id="${n.song.id}"]`)?.scrollIntoView({ block: "nearest" }); }
  }
  function select(song) {
    selected = song; mode = "view"; tabLang = null;
    list.querySelectorAll(".item").forEach(x => x.classList.toggle("sel", x.dataset.id === song.id));
    renderDetail();
  }
  function goLive(song) { present({ type: "song", songId: song.id }); toast("Live: " + song.title); }

  function renderDetail() {
    detail.innerHTML = "";
    const song = selected;
    if (!song) { detail.appendChild(h("div", { class: "empty", style: "margin:auto" }, h("div", { style: "font-size:15px;margin-bottom:6px;color:var(--text)" }, `${S.songs.length.toLocaleString()} songs in the library`), "Search on the left. Enter selects, double-click or Shift+Enter puts a song on the projector.")); return; }
    if (mode === "edit") return renderEditor(song);
    const langs = Object.keys(song.versions);
    if (!tabLang || !song.versions[tabLang]) tabLang = songOpts(song).lang1;
    const v = song.versions[tabLang];
    const status = song.status || "review";
    detail.append(
      h("div", { class: "song-head" },
        h("h2", {}, v.title || song.title),
        h("div", { class: "row" },
          ...(song.books || []).map(b => h("span", { class: "tag", title: S.books[b.book] || b.book }, bookLabel(S.books, b))),
          song.key ? h("span", { class: "tag" }, "Key " + transposeKey(song.key, transpose)) : null,
          song.category ? h("span", { class: "tag" }, song.category) : null,
          ...(song.tags || []).slice(0, 4).map(t => h("span", { class: "tag review" }, t)),
          h("span", { class: "tag " + (status === "ok" ? "ok" : status) }, status === "ok" ? "Approved" : status === "fix" ? "Needs fixing" : "Not reviewed"),
          song.author ? h("span", { class: "dim" }, "Lyrics by " + song.author) : null,
          song.order ? h("span", { class: "dim", title: "Song order" }, "Order: " + song.order) : null),
        song.notes ? h("div", { class: "muted", style: "font-size:12.5px;margin-top:6px;white-space:pre-wrap" }, song.notes) : null,
        h("div", { class: "row", style: "margin-top:12px" },
          h("button", { class: "btn live", onclick: () => goLive(song) }, "▶ Go live"),
          h("button", { class: "btn", onclick: () => addToService({ type: "song", songId: song.id }) }, "+ Add to service"),
          h("button", { class: "btn", onclick: () => { mode = "edit"; renderDetail(); } }, "Edit"),
          status !== "ok" ? h("button", { class: "btn ghost", onclick: async () => { song.status = "ok"; await saveSong(song); renderDetail(); toast("Marked as approved"); } }, "✓ Mark approved") : null,
          h("span", { style: "flex:1" }),
          h("button", { class: "btn ghost", onclick: () => modal("Delete this song?", h("p", { class: "muted" }, song.title), [{ label: "Cancel" }, { label: "Delete", cls: "live", fn: async () => { await deleteSong(song.id); selected = null; renderList(); renderDetail(); } }]) }, "Delete"))),
      h("div", { class: "tabs" }, ...langs.map(l => h("button", { class: l === tabLang ? "on" : "", onclick: () => { tabLang = l; renderDetail(); } }, (LANGS[l] || l) + (song.versions[l].auto ? " (auto)" : ""))),
        h("button", { onclick: () => addVersion(song) }, "+ Language")),
      songHasChords(song) ? h("div", { class: "row", style: "gap:6px;padding:6px 0" },
        h("button", { class: "btn sm" + (showChords ? " on" : ""), onclick: () => { showChords = !showChords; renderDetail(); } }, "Chords"),
        h("button", { class: "btn sm", disabled: !showChords, onclick: () => { transpose--; renderDetail(); } }, "♭ −1"),
        h("span", { class: "dim" }, transpose ? `${transpose > 0 ? "+" : ""}${transpose}` + (song.key ? ` → ${transposeKey(song.key, transpose)}` : "") : "original key"),
        h("button", { class: "btn sm", disabled: !showChords, onclick: () => { transpose++; renderDetail(); } }, "♯ +1")) : null,
      h("div", { class: "scroll" }, h("div", { class: "lyrics" }, ...v.sections.map(s => h("div", { class: "sec" }, h("div", { class: "lab", style: `color:${sectionColor(s.label)}` }, s.label),
        ...s.lines.map(l => showChords && /\[[A-G]/.test(l) ? h("div", { class: "chordline" }, ...chordSegments(l, transpose).map(g => h("span", { class: "cs" }, h("b", {}, g.chord || "\u00a0"), h("span", {}, g.text || "\u00a0")))) : h("div", {}, l.replace(/\[[A-G][^\]]{0,10}\]/g, ""))))))));
  }

  function renderEditor(song) {
    const langs = Object.keys(song.versions);
    let edLang = tabLang && song.versions[tabLang] ? tabLang : langs[0];
    const title = h("input", { class: "input", value: song.title });
    const key = h("input", { class: "input", value: song.key || "", placeholder: "e.g. D", style: "width:80px" });
    const tags = h("input", { class: "input", value: (song.tags || []).join(", "), placeholder: "worship, praise, communion" });
    const yt = h("input", { class: "input", value: song.youtube || "", placeholder: "https://youtu.be/…" });
    const cats = [...new Set(S.songs.map(x => x.category).filter(Boolean))].sort();
    const cat = h("input", { class: "input", value: song.category || "", placeholder: "Worship, Praise, Communion…", list: "rw-cats" });
    const catList = h("datalist", { id: "rw-cats" }, ...cats.map(c => h("option", { value: c })));
    const author = h("input", { class: "input", value: song.author || "", placeholder: "Writer / composer" });
    const order = h("input", { class: "input", value: song.order || "", placeholder: "e.g. V1 C V2 C B C  (blank = verse, chorus after each verse)" });
    const notes = h("textarea", { class: "input", rows: 2, style: "min-height:56px;height:56px", placeholder: "Notes for the team (tempo, who leads, when to sing)" }); notes.value = song.notes || "";
    const nb = nextBookNumber();
    const books = h("input", { class: "input", value: (song.books?.length ? song.books : [nb]).map(b => `${b.book} ${b.num}`).join(", "), placeholder: `${nb.book} ${nb.num}` });
    const drafts = {}; langs.forEach(l => (drafts[l] = { title: song.versions[l].title || "", text: sectionsToText(song.versions[l].sections) }));
    const vtitle = h("input", { class: "input" });
    const ta = h("textarea", { class: "input", spellcheck: "false" });
    const checkNote = h("div", { class: "muted", style: "font-size:12.5px;color:#d97706" }, "");
    const tabs = h("div", { class: "tabs", style: "padding:0" });
    function loadLang() {
      tabs.innerHTML = "";
      Object.keys(drafts).forEach(l => tabs.appendChild(h("button", { class: l === edLang ? "on" : "", onclick: () => { save(); edLang = l; loadLang(); } }, LANGS[l] || l)));
      vtitle.value = drafts[edLang].title; ta.value = drafts[edLang].text;
    }
    function save() { drafts[edLang] = { title: vtitle.value, text: ta.value }; }
    loadLang();
    const reviewing = review && review.song === song;
    detail.append(h("div", { class: "scroll" }, h("div", { class: "pagepad editor col" },
      reviewing ? h("div", { class: "card", style: "background:rgba(59,130,246,.12);border-color:rgba(59,130,246,.4);font-size:13px" }, h("b", {}, `Reviewing a ${review.isNew ? "new song" : "correction"} from ${review.by}. `), review.isNew ? "Checked against the whole songbook — not there yet. " : "", "Fix anything, then Save song — it is added to the songbook and cleared from the inbox. Cancel keeps it in the inbox.") : null,
      h("div", { class: "row" }, h("label", { class: "f", style: "flex:1" }, "Song title", title), h("label", { class: "f" }, "Key", key)),
      h("div", { class: "row" }, h("label", { class: "f", style: "flex:1" }, "Book numbers", books), h("label", { class: "f", style: "flex:1" }, "Tags", tags), h("label", { class: "f", style: "flex:1" }, "YouTube / reference", yt)),
      h("div", { class: "row" }, h("label", { class: "f", style: "flex:1" }, "Category", cat, catList), h("label", { class: "f", style: "flex:1" }, "Lyrics by", author)),
      h("label", { class: "f" }, h("span", {}, "Song order ", h("span", { class: "dim" }, `sections: ${orderLabel(song.versions[langs[0]]?.sections)}`)), order),
      h("label", { class: "f" }, "Notes", notes),
      h("div", { class: "section-title" }, "Lyrics by language"), tabs,
      h("label", { class: "f" }, "Title in this language", vtitle),
      h("div", { class: "muted", style: "font-size:12px" }, "Put each section under a label in square brackets, e.g. [Chorus], [Verse 1], [Bridge]. Leave a blank line between sections. Repeat marks: (x2). Chords go inside the line: [G]Amazing [C]grace — the projector never shows them; musicians see them on the stage display."),
      ta, checkNote,
      h("div", { class: "row" },
        h("button", { class: "btn sm", onclick: () => {   // only the Kruti Dev lines: keep [Verse 1] labels, chords and lines that are already Hindi
          let n = 0;
          const CH = new RegExp(String.raw`(\[${CHORD}\])`);
          ta.value = ta.value.split("\n").map(l => {
            if (!l.trim() || (/^\s*\[[^\]]*\]\s*$/.test(l) && !/[;'{}]/.test(l)) || !looksLikeKruti(stripChords(l))) return l;   // labels, Hindi and English lines stay
            n++; return l.split(CH).map((part, i) => i % 2 ? part : krutiToUnicode(part)).join("");      // keep [G] chords
          }).join("\n");
          toast(n ? `Converted ${n} line${n > 1 ? "s" : ""} from Kruti Dev` : "No Kruti Dev lines found"); } }, "Fix Kruti Dev text"),
        h("button", { class: "btn sm", title: "Turn Hindi typed in English letters into Hindi script; the Hinglish is kept as its own version", onclick: async () => {
          save();
          const { loadHinglishDict, hinglishToHindi, looksHinglish } = await import("../hinglish.js");
          const src = drafts[edLang]; if (!looksHinglish(src.text)) return toast("No Hinglish found in this language's lyrics");
          const dict = await loadHinglishDict();
          const typedTitle = (!src.title || /^new song$/i.test(src.title)) ? title.value.trim() : src.title;   // a new song's language title is still "New song"
          const body = hinglishToHindi(src.text, dict), head = hinglishToHindi(typedTitle, dict);
          const hinglish = { ...src, title: typedTitle };
          if (edLang !== "hi" || !drafts["hi-Latn"]) drafts["hi-Latn"] = hinglish;   // keep what was typed as the Hinglish version
          if (!/[ऀ-ॿ]/.test(title.value) && /[A-Za-z]/.test(title.value)) title.value = hinglishToHindi(title.value, dict).text;   // a Hindi song gets a Hindi title
          drafts.hi = { title: head.text, text: body.text };
          if (edLang !== "hi" && edLang !== "hi-Latn" && edLang !== song.lang) delete drafts[edLang];
          song.lang = "hi"; edLang = "hi"; loadLang();
          const unk = [...new Set([...head.unknown, ...body.unknown])];
          checkNote.textContent = unk.length ? `Converted ${body.words} words. Please check these (not in the songbook's words yet): ${unk.join(", ")}` : `Converted ${body.words} words — all found in the songbook's words. Read it through once.`;
          toast("Converted to Hindi — the Hinglish is kept too");
        } }, "Hinglish → हिंदी"),
        edLang === "hi" ? h("button", { class: "btn sm", onclick: () => { save(); drafts["hi-Latn"] = { title: capitalizeLines(romanize(drafts.hi.title)), text: capitalizeLines(romanize(drafts.hi.text)).replace(/^\[(.*)\]$/gm, (m, a) => `[${a.charAt(0).toUpperCase() + a.slice(1)}]`), auto: true }; loadLang(); toast("Hinglish version regenerated"); } }, "Regenerate Hinglish") : null,
        h("span", { style: "flex:1" }),
        h("button", { class: "btn ghost", onclick: () => { const was = reviewing; if (was) { review = null; selected = null; } mode = "view"; renderDetail(); if (was) toast("Not saved — it is still in the inbox"); } }, "Cancel"),
        h("button", { class: "btn primary", onclick: async () => {
          save();
          song.title = title.value.trim() || song.title; song.key = key.value.trim(); song.youtube = yt.value.trim();
          song.category = cat.value.trim(); song.author = author.value.trim(); song.order = order.value.trim(); song.notes = notes.value.trim();
          song.tags = tags.value.split(",").map(s => s.trim()).filter(Boolean);
          song.books = books.value.split(",").map(s => s.trim().match(/^([A-Za-z0-9]+)\s+(\d+)$/)).filter(Boolean).map(m => ({ book: m[1].toUpperCase(), num: +m[2] }));
          for (const [l, d] of Object.entries(drafts)) {
            const secs = textToSections(d.text);
            if (!secs.length) { delete song.versions[l]; continue; }
            song.versions[l] = { title: d.title || song.title, sections: secs, ...(d.auto || (song.versions[l]?.auto && d.text === sectionsToText(song.versions[l].sections)) ? { auto: true } : {}) };
          }
          if (!Object.keys(song.versions).length) { toast("A song needs lyrics in at least one language"); return; }
          if (song.status === "fix") song.status = "review";
          await saveSong(song); mode = "view"; fillCats(); renderList(); renderDetail(); toast(`Saved — ${song.books.map(b => b.book + " " + b.num).join(", ")}`);
          if (reviewing) { const r = review; review = null; r.onSaved?.(song); }
        } }, "Save song")))));
  }

  function addVersion(song) {
    const sel = h("select", { class: "input" }, ...Object.entries(LANGS).filter(([k]) => !song.versions[k]).map(([k, v]) => h("option", { value: k }, v)));
    const t = h("input", { class: "input", placeholder: "Title in this language" });
    const ta = h("textarea", { class: "input", rows: 12, placeholder: "[Verse 1]\n…\n\n[Chorus]\n…" });
    modal("Add a language version", h("div", { class: "col" }, h("label", { class: "f" }, "Language", sel), h("label", { class: "f" }, "Title", t), h("label", { class: "f" }, "Lyrics", ta),
      h("div", { class: "muted", style: "font-size:12px" }, "Tip: Image→Text can read lyrics from a photo of a songbook page.")),
      [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: async () => {
        let text = ta.value; if (looksLikeKruti(text)) text = krutiToUnicode(text);
        const secs = textToSections(text); if (!secs.length) { toast("Enter some lyrics"); return false; }
        song.versions[sel.value] = { title: t.value || song.title, sections: secs };
        await saveSong(song); tabLang = sel.value; renderDetail();
      } }]);
  }

  async function importSongs() {
    const { parseSongFile } = await import("../song-import.js");
    const input = h("input", { type: "file", multiple: true, accept: ".xml,.cho,.chordpro,.chopro,.pro,.crd,.txt,.show,.json,.vvs,.vvsong" });
    const body = h("div", { class: "col" });
    const cat = h("input", { class: "input", placeholder: "Category for these songs (optional)" });
    let found = [];
    body.append(h("p", { class: "muted", style: "margin:0" }, "Choose song files: VerseVIEW export, OpenLyrics / OpenLP (.xml), OpenSong, ChordPro (.cho), FreeShow (.show) or text (.txt). You can pick many at once. Songs are added to this computer's library only."),
      h("button", { class: "btn", onclick: () => input.click() }, "Choose files…"), cat);
    const listEl = h("div", { class: "col", style: "max-height:46vh;overflow:auto;gap:4px" }); body.append(listEl);
    const existing = new Map(S.songs.map(x => [x.title.trim().toLowerCase(), x]));
    input.onchange = async () => {
      listEl.innerHTML = "Reading…"; found = [];
      const errors = [];
      for (const f of input.files) { const r = await parseSongFile(f); if (r.error) errors.push(`${f.name}: ${r.error}`); for (const sg of r.songs) found.push({ ...sg, file: f.name, format: r.format, dup: existing.has(sg.title.trim().toLowerCase()), use: !existing.has(sg.title.trim().toLowerCase()) }); }
      listEl.innerHTML = "";
      if (!found.length) listEl.append(h("div", { class: "warnline" }, "No songs found in these files." + (errors.length ? " " + errors.join(" · ") : "")));
      found.forEach(sg => { const cb = h("input", { type: "checkbox", checked: sg.use, onchange: e => (sg.use = e.target.checked) });
        listEl.append(h("label", { class: "row", style: "gap:8px;font-size:13px;flex-wrap:nowrap" }, cb, h("span", { style: "flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:var(--lyric)" }, sg.title),
          h("span", { class: "dim", style: "font-size:11.5px;white-space:nowrap" }, `${Object.keys(sg.versions).filter(l => !sg.versions[l].auto).map(l => l.toUpperCase()).join("+")} · ${sg.versions[sg.lang].sections.length} parts · ${sg.format}`),
          sg.dup ? h("span", { class: "tag fix", title: "A song with this title is already in the library" }, "already here") : null)); });
      if (errors.length && found.length) listEl.append(h("div", { class: "dim", style: "font-size:11.5px" }, errors.join(" · ")));
    };
    modal("Import songs", body, [{ label: "Cancel" }, { label: "Import selected", cls: "primary", fn: async () => {
      const pick = found.filter(x => x.use); if (!pick.length) { toast("Nothing selected"); return false; }
      for (const sg of pick) {
        const { file, format, dup, use, fixedKruti, ...song } = sg;
        await saveSong({ ...song, id: uid("s"), category: cat.value.trim() || song.category || "", status: "review", books: [], imported: new Date().toISOString() });
      }
      fillCats(); renderList(); toast(`Imported ${pick.length} song${pick.length > 1 ? "s" : ""}`);
    } }]);
  }

  async function newSong(prefill) {
    const song = { id: uid("s"), title: prefill?.title || "New song", lang: prefill?.lang || "hi", key: "", tags: [], books: [], status: "review",
      versions: { [prefill?.lang || "hi"]: { title: prefill?.title || "New song", sections: prefill?.sections || [{ label: "Verse 1", lines: ["…"] }] } } };
    await saveSong(song); selected = song; mode = "edit"; tabLang = song.lang; renderList(); renderDetail();
  }

  onChange(w => { if (w === "songs" && !document.hidden) { /* keep list fresh */ } });
  renderList(); renderDetail();
  return { onShow() { q.focus(); renderList(); }, select, newSong };
}
