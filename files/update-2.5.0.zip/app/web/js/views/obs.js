import { S, h, db, uid, obsConnect, saveSettings, showLowerCard, hideLower, toast, onChange, emit } from "../core.js";

export function obsView(root) {
  const page = h("div", { class: "pagepad" });
  root.appendChild(page);
  const base = () => (location.protocol.startsWith("http") ? location.origin : "http://localhost:7777");

  function render() {
    const o = S.settings.obs, ls = S.settings.lowerStyle;
    page.innerHTML = "";
    const url = h("input", { class: "input", value: o.url, style: "width:220px" });
    const pw = h("input", { class: "input", type: "password", value: o.password, placeholder: "WebSocket password", style: "width:200px" });
    const auto = h("input", { type: "checkbox", checked: o.autoConnect });
    const sources = [
      ["Lower third (lyrics, verses, quotes, names)", "/obs/lower-third.html"],
      ["Full-screen lyrics on transparent background", "/output.html?mode=obs"],
      ["Projector output (with background)", "/output.html?mode=projector"],
      ["Stage / confidence display", "/output.html?mode=stage"],
    ];
    const sceneSel = (kind) => { const s = h("select", { class: "input" }, h("option", { value: "" }, "— don’t switch —"), ...S.obsScenes.list.map(n => h("option", { value: n }, n))); s.value = o.autoScenes[kind] || ""; s.onchange = () => { o.autoScenes[kind] = s.value; saveSettings(); }; return s; };
    page.append(h("div", { class: "two" },
      h("div", { class: "col", style: "gap:14px" },
        h("div", { class: "card col" },
          h("div", { class: "row" }, h("div", { style: "font-weight:650;font-size:14px;flex:1" }, "Connect to OBS"), h("span", { class: "pill" + (S.obs.connected ? " ok" : "") }, h("span", { class: "dot" }), S.obs.connected ? "Connected" : "Not connected")),
          h("div", { class: "muted", style: "font-size:12.5px" }, "In OBS: Tools → WebSocket Server Settings → tick “Enable WebSocket server”, then “Show Connect Info” to copy the password. Works with OBS on this Mac (ws://localhost:4455) or another computer (ws://its-ip:4455)."),
          h("div", { class: "row" }, url, pw),
          h("div", { class: "row" }, h("label", { class: "row", style: "gap:6px" }, auto, "Connect automatically"), h("span", { style: "flex:1" }),
            S.obs.connected ? h("button", { class: "btn", onclick: () => { S.obs.disconnect(); emit("obs"); } }, "Disconnect") : null,
            h("button", { class: "btn primary", onclick: async () => { o.url = url.value.trim(); o.password = pw.value; o.autoConnect = auto.checked; await saveSettings(); obsConnect(); } }, "Connect"))),
        h("div", { class: "card col" },
          h("div", { style: "font-weight:650;font-size:14px" }, "Scenes"),
          S.obs.connected ? h("div", { class: "row" }, ...S.obsScenes.list.map(n => h("button", { class: "btn" + (n === S.obsScenes.current ? " live" : ""), onclick: () => S.obs.setScene(n).catch(e => toast(e.message)) }, n))) : h("div", { class: "dim" }, "Connect to see your scenes (Before Beginning, Intro, Song Leading…)."),
          h("div", { class: "section-title" }, "Switch scenes automatically"),
          h("div", { class: "col" },
            h("label", { class: "f" }, "When a song goes live", sceneSel("song")),
            h("label", { class: "f" }, "When scripture goes live", sceneSel("bible")),
            h("label", { class: "f" }, "When a Message quote goes live", sceneSel("message")),
            h("label", { class: "f" }, "When the screen is blanked", sceneSel("blank")))),
        h("div", { class: "card col" },
          h("div", { style: "font-weight:650;font-size:14px" }, "Overlay sources for OBS"),
          h("div", { class: "muted", style: "font-size:12.5px" }, "Add these as Browser Sources (1920 × 1080). The Revival app must be running. “Add to current scene” does it for you."),
          ...sources.map(([label, path]) => h("div", { class: "col", style: "gap:4px" }, h("div", { style: "font-weight:550" }, label), h("div", { class: "row", style: "flex-wrap:nowrap" }, h("div", { class: "copyable", style: "flex:1" }, base() + path),
            h("button", { class: "btn sm", onclick: async () => { await navigator.clipboard.writeText(base() + path); toast("Copied"); } }, "Copy"),
            h("button", { class: "btn sm", disabled: !S.obs.connected, onclick: async () => { try { const r = await S.obs.addBrowserSource(S.obsScenes.current, "Revival – " + label.split(" (")[0], base() + path); toast(r === "created" ? "Added to " + S.obsScenes.current : "Updated in " + S.obsScenes.current); } catch (e) { toast(e.message); } } }, "Add to current scene")))))),
      h("div", { class: "col", style: "gap:14px" },
        h("div", { class: "card col" },
          h("div", { style: "font-weight:650;font-size:14px" }, "Lower third style"),
          h("div", { class: "row" }, ...[["pro", "Revival Pro (navy & gold)"], ["minimal", "Minimal (text only)"], ["outline", "Outline lyrics (bold white, like the convention videos)"]].map(([k, v]) => h("button", { class: "btn" + (ls.look === k ? " on" : ""), onclick: () => { ls.look = k; saveSettings(); render(); } }, v))),
          h("div", { class: "row" },
            h("label", { class: "f" }, "Colour", colorIn(ls, "accent")), h("label", { class: "f" }, "Colour 2", colorIn(ls, "accent2")),
            h("label", { class: "row", style: "gap:6px;margin-top:16px" }, (() => { const c = h("input", { type: "checkbox", checked: ls.logo !== false }); c.onchange = () => { ls.logo = c.checked; saveSettings(); }; return c; })(), "Show logo"),
            h("label", { class: "f" }, "Name & title cards fade out after (sec, 0 = stay)", (() => { const n = h("input", { class: "input", type: "number", min: 0, max: 60, value: S.settings.nameCardSeconds ?? 5, style: "width:90px" }); n.onchange = () => { S.settings.nameCardSeconds = Math.max(0, +n.value || 0); saveSettings(); }; return n; })())),
          h("div", { class: "row", style: "align-items:center;gap:10px" }, h("span", { style: "font-size:13px" }, "Transitions (projector, lower third, OBS scenes):"),
            h("div", { class: "seg" }, ...[[0, "Cut"], [300, "Fade 300 ms"], [600, "Fade 600 ms"]].map(([ms, v]) => h("button", { class: "btn sm" + (+(S.settings.transition ?? 300) === ms ? " on" : ""), onclick: async () => { S.settings.transition = ms; saveSettings(); (await import("../core.js")).broadcast(); render(); } }, v)))),
          h("div", { class: "row" }, h("button", { class: "btn", onclick: () => showLowerCard({ type: "name", name: "Name Surname", role: "Song Leader" }) }, "Test name card"),
            h("button", { class: "btn", onclick: () => showLowerCard({ type: "bible", lines: ["For God so loved the world, that he gave his only begotten Son…"], lines2: ["क्योंकि परमेश्वर ने जगत से ऐसा प्रेम रखा…"], ref: "John 3:16 · यूहन्ना 3:16" }) }, "Test verse"),
            h("button", { class: "btn ghost", onclick: hideLower }, "Hide"))),
        peopleCard(),
        titleCard())));
  }
  function colorIn(obj, key) { const c = h("input", { type: "color", value: obj[key], style: "width:60px;height:30px;border:0;background:none" }); c.onchange = () => { obj[key] = c.value; saveSettings(); }; return c; }

  function peopleCard() {
    const list = h("div", { class: "col", style: "gap:4px" });
    const load = async () => {
      const { people } = await import("../people.js");
      list.innerHTML = "";
      for (const p of await people()) list.appendChild(h("div", { class: "row", style: "flex-wrap:nowrap" },
        h("div", { style: "flex:1" }, h("b", {}, p.name), h("span", { class: "muted" }, p.role ? " — " + p.role : "")),
        h("button", { class: "btn sm", onclick: () => showLowerCard({ type: "name", name: p.name, role: p.details || p.role }) }, "Show")));
    };
    load(); onChange(w => { if (w === "people") load(); });
    return h("div", { class: "card col" }, h("div", { class: "row", style: "justify-content:space-between" }, h("div", { style: "font-weight:650;font-size:14px" }, "People (name cards)"),
      h("button", { class: "btn sm", onclick: async () => (await import("../people.js")).openPeopleEditor() }, "Add / edit / delete…")), list);
  }
  function titleCard() {
    const t = h("input", { class: "input", placeholder: "e.g. Pakur Meetings 2021 – Unfolding of the names in the book" });
    const s = h("input", { class: "input", placeholder: "Speaker or subtitle (optional)" });
    return h("div", { class: "card col" }, h("div", { style: "font-weight:650;font-size:14px" }, "Title card"), t, s,
      h("div", { class: "row" }, h("button", { class: "btn primary", onclick: () => { if (t.value) showLowerCard({ type: "title", title: t.value, subtitle: s.value }); } }, "Show title"), h("button", { class: "btn ghost", onclick: hideLower }, "Hide")));
  }
  onChange(w => { if (w === "obs" && root.classList.contains("on")) render(); });
  render();
  return { onShow: render };
}
