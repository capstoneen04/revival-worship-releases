// Tiny IndexedDB layer + seeding from data/songs.json
const DB_NAME = "revival-worship";
const DB_VER = 1;
const STORES = ["songs", "services", "quotes", "people", "settings", "media"];
let _db;

function open() {
  if (_db) return Promise.resolve(_db);
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, DB_VER);
    r.onupgradeneeded = () => {
      const db = r.result;
      for (const s of STORES) if (!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: "id" });
    };
    r.onsuccess = () => { _db = r.result; res(_db); };
    r.onerror = () => rej(r.error);
  });
}

function tx(store, mode = "readonly") { return open().then(db => db.transaction(store, mode).objectStore(store)); }
const wrap = req => new Promise((res, rej) => { req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error); });

export const db = {
  async all(store) { return wrap((await tx(store)).getAll()); },
  async get(store, id) { return wrap((await tx(store)).get(id)); },
  async put(store, obj) { return wrap((await tx(store, "readwrite")).put(obj)); },
  async del(store, id) { return wrap((await tx(store, "readwrite")).delete(id)); },
  async clear(store) { return wrap((await tx(store, "readwrite")).clear()); },
  async bulkPut(store, arr) {
    const d = await open();
    return new Promise((res, rej) => {
      const t = d.transaction(store, "readwrite");
      const os = t.objectStore(store);
      for (const o of arr) os.put(o);
      t.oncomplete = () => res(arr.length);
      t.onerror = () => rej(t.error);
    });
  },
};

export async function getSetting(key, dflt) {
  const r = await db.get("settings", key);
  return r ? r.value : dflt;
}
export async function setSetting(key, value) { return db.put("settings", { id: key, value }); }

// Seed library on first run
export async function ensureSeeded(onProgress) {
  const seeded = await getSetting("seedVersion", 0);
  let meta = await getSetting("books", null);
  if (seeded) return { seeded: false, books: meta };
  // A new computer starts with the church's own database (songs, members, services, themes, settings) that ships with the app
  // or that was copied into "Revival Worship App/Backup". Falls back to the plain song library.
  const plain = await getSetting("seedPlain", 0);
  if (plain) await db.del("settings", "seedPlain");
  if (!plain) try {
    const r = await fetch("/api/seed-data", { cache: "no-store" });
    if (r.ok) {
      onProgress && onProgress("Setting up the church library…");
      const data = await r.json();
      if (data && data.app === "revival-worship" && Array.isArray(data.songs) && data.songs.length) {
        await importBackup(data);
        if (!(await getSetting("seedVersion", 0))) { await setSetting("seedVersion", 1); }
        return { seeded: true, books: await getSetting("books", null), from: decodeURIComponent(r.headers.get("x-source") || "") };
      }
    }
  } catch { }
  onProgress && onProgress("Loading song library…");
  const r = await fetch("data/songs.json").catch(() => null);
  if (!r || !r.ok) return { seeded: false, books: meta, locked: true };   // library still locked → try again next start
  const data = await r.json();
  await db.bulkPut("songs", data.songs);
  await setSetting("books", data.books);
  await setSetting("seedVersion", data.version);
  await setSetting("libSongsVersion", data.version);
  // members are not shipped with the app: they come from the church backup (Settings → Restore, or the Backup folder)
  return { seeded: true, books: data.books };
}

// A newer song library arrived (update or first unlock on a computer that already had songs):
// add songs that are new; songs already here — including the team's edits — are left as they are.
export async function mergeLibrarySongs(onProgress) {
  const r = await fetch("data/songs.json", { cache: "no-store" }); if (!r.ok) return { added: 0 };
  const data = await r.json();
  const have = await getSetting("libSongsVersion", await getSetting("seedVersion", 0));
  if (!data.version || data.version <= have) return { added: 0 };
  onProgress && onProgress("Adding new songs…");
  const existing = new Map((await db.all("songs")).map(s => [s.id, s]));
  // new songs, plus songs corrected by the team (published copy is newer than this computer's copy)
  const add = data.songs.filter(s => { const mine = existing.get(s.id); return !mine || String(s.updated || "") > String(mine.updated || ""); });
  if (add.length) await db.bulkPut("songs", add);
  const books = await getSetting("books", null);
  await setSetting("books", { ...(data.books || {}), ...(books || {}) });
  await setSetting("libSongsVersion", data.version);
  return { added: add.length };
}
export async function exportBackup() {
  const out = { app: "revival-worship", exported: new Date().toISOString() };
  for (const s of ["songs", "services", "quotes", "people", "settings"]) out[s] = await db.all(s);
  // passwords are never written into backups (the Mac app reads OBS's password from OBS itself)
  out.settings = out.settings.map(r => r.id === "app" && r.value?.obs ? { ...r, value: { ...r.value, obs: { ...r.value.obs, password: "" } } } : r);
  return out;
}
// Automatic copy of the database into "Revival Worship App/Backup" (one file per day, last 30 kept)
let _bkTimer = null, _bkLast = "";
export async function saveBackupToFolder() {
  const data = await exportBackup();
  const sig = JSON.stringify([data.songs.length, data.people.length, data.services.length]) + JSON.stringify(data).length;
  if (sig === _bkLast) return { ok: true, same: true };
  const r = await fetch("/api/backup", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(data) });
  if (!r.ok) throw new Error(await r.text());
  _bkLast = sig; return r.json();
}
export function startAutoBackup() {
  if (_bkTimer) return;
  const run = () => saveBackupToFolder().catch(() => { });
  setTimeout(run, 20000);                                   // shortly after opening
  _bkTimer = setInterval(run, 30 * 60 * 1000);              // and every 30 minutes (skipped when nothing changed)
  addEventListener("pagehide", run);
}
export async function importBackup(obj) {
  for (const s of ["songs", "services", "quotes", "people", "settings"]) if (Array.isArray(obj[s])) { await db.clear(s); await db.bulkPut(s, obj[s]); }
}
export function uid(prefix = "x") { return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
