// Revival Worship — app core (started by electron/shell.js, which picks the installed copy or a downloaded update)
const { app, BrowserWindow, ipcMain, screen, shell, Menu, dialog, net, session, systemPreferences, nativeTheme, safeStorage } = require("electron");
const atem = require("./atem.js");
const path = require("path");
const fs = require("fs");
const os = require("os");
const { start } = require("../server/server.js");
const { createLibrary } = require("./library.js");
const { createTeam } = require("./team.js");
const { createUpdater } = require("./updater.js");
// When started without the shell (developer `electron electron/main.js`), behave like the installed copy
const RW = global.RW || { SHELL: 2, codeRoot: path.join(__dirname, ".."), version: require("../web/version.json").version, bundledVersion: require("../web/version.json").version, fromUpdate: false,
  updatesDir: path.join(app.getPath("userData"), "updates"), resources: app.isPackaged ? process.resourcesPath : path.join(__dirname, "..", "dist-resources"), markGood() { }, readState: () => ({}), writeState() { } };

const PORT = 7777;
let server = null, mainWin = null, tableWin = null;
const outputs = {};   // mode -> BrowserWindow

if (!app.requestSingleInstanceLock()) app.quit();
app.on("second-instance", () => { if (mainWin) { if (mainWin.isMinimized()) mainWin.restore(); mainWin.focus(); } });

function webRoot() { return path.join(__dirname, "..", "web"); }   // this copy's web app (installed or downloaded update)
const appDir = path.join(os.homedir(), "Documents", "Revival Church", "Revival Worship App");
// church library (songs + Hindi Bible), locked in public downloads
const library = createLibrary({ userData: app.getPath("userData"), appDir, safeStorage });
const libraryPacks = () => {
  const out = [path.join(RW.resources, "church-library.rwpack")];
  try { for (const f of fs.readdirSync(RW.updatesDir)) if (/^library-.*\.rwpack$/.test(f)) out.push(path.join(RW.updatesDir, f)); } catch { }
  return out;
};
let updater = null;
function base() { return `http://localhost:${PORT}`; }

function createMain() {
  mainWin = new BrowserWindow({
    width: 1440, height: 900, minWidth: 1100, minHeight: 680, title: "Revival Worship", backgroundColor: "#0e1014",
    titleBarStyle: "default",
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, backgroundThrottling: false },
  });
  mainWin.loadURL(`${base()}/index.html`);
  mainWin.webContents.once("did-finish-load", () => setTimeout(() => RW.markGood(), 3000));   // this version starts fine → keep it
  mainWin.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith(base())) {
      const m = new URL(url).searchParams.get("mode");
      if (m) { openOutput(m); return { action: "deny" }; }
      return { action: "allow" };
    }
    shell.openExternal(url); return { action: "deny" };
  });
  mainWin.on("closed", () => { mainWin = null; for (const w of Object.values(outputs)) if (!w.isDestroyed()) w.close(); if (tableWin && !tableWin.isDestroyed()) tableWin.close(); });
}

function openOutput(mode = "projector", displayId) {
  const displays = screen.getAllDisplays();
  const primary = screen.getPrimaryDisplay();
  let d = displays.find(x => x.id === displayId);
  if (!d) d = displays.find(x => x.id !== primary.id) || null;      // first external screen
  const existing = outputs[mode];
  if (existing && !existing.isDestroyed()) existing.close();
  const opts = { title: mode === "stage" ? "Stage Display" : "Projector", backgroundColor: "#000000", show: false, webPreferences: { backgroundThrottling: false } };
  let win;
  if (d) {
    win = new BrowserWindow({ ...opts, x: d.bounds.x, y: d.bounds.y, width: d.bounds.width, height: d.bounds.height, frame: false, resizable: false, movable: false, enableLargerThanScreen: true, hasShadow: false });
    win.setAlwaysOnTop(true, "screen-saver");
    win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    win.once("ready-to-show", () => { win.setBounds(d.bounds); win.showInactive(); });
  } else {
    win = new BrowserWindow({ ...opts, width: 960, height: 540 });
    win.once("ready-to-show", () => win.show());
  }
  win.setMenuBarVisibility(false);
  win.loadURL(`${base()}/output.html?mode=${mode}`);
  outputs[mode] = win;
  win.on("closed", () => { if (outputs[mode] === win) delete outputs[mode]; });
  return true;
}

function openTable() {
  if (tableWin && !tableWin.isDestroyed()) { tableWin.focus(); return; }
  tableWin = new BrowserWindow({
    width: 1200, height: 860, title: "The Table — Voice of God Recordings",
    webPreferences: { preload: path.join(__dirname, "table-preload.js"), contextIsolation: true, partition: "persist:table" },
  });
  tableWin.loadURL("https://table.branham.org");
  tableWin.webContents.setWindowOpenHandler(({ url }) => { tableWin.loadURL(url); return { action: "deny" }; });
  tableWin.on("closed", () => (tableWin = null));
}

ipcMain.handle("displays", () => {
  const primary = screen.getPrimaryDisplay();
  return screen.getAllDisplays().map((d, i) => ({ id: d.id, label: d.label || `Display ${i + 1}`, width: d.size.width, height: d.size.height, primary: d.id === primary.id }));
});
ipcMain.handle("open-output", (e, mode, displayId) => openOutput(mode, displayId));
ipcMain.handle("close-outputs", () => { for (const w of Object.values(outputs)) if (!w.isDestroyed()) w.close(); });
ipcMain.handle("open-table", () => openTable());
ipcMain.handle("ui-theme", (e, t) => { nativeTheme.themeSource = ["light", "dark", "system"].includes(t) ? t : "dark"; if (mainWin) mainWin.setBackgroundColor(nativeTheme.shouldUseDarkColors ? "#0e1014" : "#f3f4f7"); return true; });
ipcMain.handle("open-media-folder", (e, sub) => { const p = sub === "@app" ? (server?.appDir || "") : sub === "@backup" ? path.join(server?.appDir || "", "Backup") : path.join(server?.mediaRoot || "", sub || ""); require("fs").mkdirSync(p, { recursive: true }); return shell.openPath(p); });
ipcMain.handle("obs-local-config", () => {
  // Read OBS's own WebSocket settings on this Mac so the app can connect without retyping them
  const obsDir = process.platform === "win32" ? path.join(process.env.APPDATA || path.join(os.homedir(), "AppData", "Roaming"), "obs-studio")
    : process.platform === "darwin" ? path.join(os.homedir(), "Library", "Application Support", "obs-studio") : path.join(os.homedir(), ".config", "obs-studio");
  const f = path.join(obsDir, "plugin_config", "obs-websocket", "config.json");
  try { const c = JSON.parse(fs.readFileSync(f, "utf8")); return { found: true, enabled: !!c.server_enabled, port: c.server_port || 4455, auth: c.auth_required !== false, password: c.server_password || "" }; }
  catch (e) { return { found: false }; }
});
// ---- ATEM Mini Pro ----
atem.init((ch, data) => { if (mainWin && !mainWin.isDestroyed()) mainWin.webContents.send(ch, data); });
ipcMain.handle("atem", async (e, c, ...a) => { try { const r = await atem.cmd(c, ...a); return { ok: true, result: r ?? null }; } catch (err) { return { ok: false, error: err.message }; } });

// ---- branham.org Quote of the Day + Daily Bread (fetched once a day, cached by the app) ----
ipcMain.handle("qotd", async () => {
  try {
    const r = await net.fetch("https://branham.org/en/QuoteOfTheDay", { headers: { "User-Agent": "RevivalWorship/1.2 (church media)" } });
    const html = await r.text();
    const grab = (id) => { const m = html.match(new RegExp(`id="${id}"[^>]*>([\\s\\S]*?)</span>`)); return m ? m[1] : ""; };
    const clean = (x) => x.replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>\s*<p[^>]*>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&#39;|&rsquo;/g, "’").replace(/&quot;/g, '"').replace(/[ \t]+/g, " ").trim();
    const q = { code: clean(grab("title")), title: clean(grab("summary")), text: clean(grab("content")), bread: { ref: clean(grab("scripturereference")), text: clean(grab("scripturetext")) }, date: new Date().toISOString().slice(0, 10), source: "branham.org" };
    if (!q.text) return { ok: false, error: "Quote not found on the page" };
    return { ok: true, qotd: q };
  } catch (err) { return { ok: false, error: err.message }; }
});

// ---- church library + updates ----
ipcMain.handle("library-status", () => library.status(libraryPacks()));
// ---- team songbook: inbox + publish the library ----
const team = createTeam({ userData: app.getPath("userData"), safeStorage, library, updatesDir: RW.updatesDir, getSalt: () => library.bestPack(libraryPacks())?.salt });
const teamCall = (fn) => async (...a) => { try { return { ok: true, ...(await fn(...a)) }; } catch (err) { return { ok: false, error: err.message }; } };
ipcMain.handle("team-status", () => team.status());
ipcMain.handle("team-set", (e, tok, inbox) => team.setToken(tok, inbox));
ipcMain.handle("team-check", teamCall(() => team.check()));
ipcMain.handle("team-inbox", teamCall(async () => ({ items: await team.inbox() })));
ipcMain.handle("team-remove", teamCall((e, p, sha, why) => team.remove(p, sha, why)));
ipcMain.handle("team-publish", teamCall(async (e, songs, by) => { const r = await team.publish(songs, { by, onStep: (t) => e.sender.send("team-step", t) }); try { library.autoUpdate(libraryPacks()); } catch { } return r; }));
ipcMain.handle("library-unlock", (e, pw) => { try { return { ok: true, ...library.unlock(pw, libraryPacks()) }; } catch (err) { return { ok: false, error: err.code === "WRONG_PASSWORD" ? "That password is not right" : err.message }; } });
ipcMain.handle("update-status", () => ({ ...(updater?.status() || {}), config: updater?.config() }));
ipcMain.handle("update-check", () => updater?.check({ download: true }));
ipcMain.handle("update-config", (e, c) => updater?.setConfig(c));
ipcMain.handle("update-restart", () => updater?.restart());
ipcMain.handle("update-previous", () => updater?.usePrevious());
ipcMain.handle("update-latest", () => updater?.useLatest());
ipcMain.handle("open-url", (e, u) => { if (/^https:\/\//.test(u)) shell.openExternal(u); });
ipcMain.handle("ask-camera", async () => { try { return process.platform === "darwin" ? await systemPreferences.askForMediaAccess("camera") : true; } catch { return false; } });
ipcMain.on("quote", (e, q) => { if (mainWin) { mainWin.webContents.send("quote", q); mainWin.focus(); } });

function buildMenu() {
  const t = [
    ...(process.platform === "darwin" ? [{ role: "appMenu" }] : [{ label: "File", submenu: [{ role: "quit", label: "Exit" }] }]),
    { role: "editMenu" },
    { label: "Present", submenu: [
      { label: "Open Projector", accelerator: "CmdOrCtrl+P", click: () => openOutput("projector") },
      { label: "Open Stage Display", accelerator: "CmdOrCtrl+Shift+P", click: () => openOutput("stage") },
      { label: "Close Outputs", click: () => { for (const w of Object.values(outputs)) if (!w.isDestroyed()) w.close(); } },
      { type: "separator" },
      { label: "Open The Table", accelerator: "CmdOrCtrl+T", click: () => openTable() },
    ] },
    { label: "View", submenu: [{ role: "reload" }, { role: "toggleDevTools" }, { type: "separator" }, { role: "resetZoom" }, { role: "zoomIn" }, { role: "zoomOut" }, { type: "separator" }, { role: "togglefullscreen" }] },
    { role: "windowMenu" },
    { role: "help", submenu: [{ label: "Phone remote & OBS links…", click: () => mainWin && mainWin.webContents.executeJavaScript("window.rwShow && rwShow('settings')") }] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(t));
}

app.whenReady().then(async () => {
  try {
    // seed files: the installer's, plus any new ones that came with a downloaded update
    const seedDir = [app.isPackaged ? path.join(process.resourcesPath, "seed") : path.join(__dirname, "..", "seed"), path.join(__dirname, "..", "seed")];
    try { library.autoUpdate(libraryPacks()); } catch { }
    server = await start({ port: PORT, root: webRoot(), log: () => { }, seedDir: [...new Set(seedDir)], libraryDir: library.dir, fallbackRoot: RW.bundled ? path.join(RW.bundled, "web") : null });
  } catch (e) {
    dialog.showErrorBox("Revival Worship", `Port ${PORT} is already in use. Is Revival Worship already open?\n\n${e.message}`);
    app.quit(); return;
  }
  // allow the Audio Monitor to listen to the ATEM / microphone
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(perm === "media" || perm === "clipboard-sanitized-write" || perm === "clipboard-read"));
  session.defaultSession.setPermissionCheckHandler(() => true);
  if (process.platform === "darwin") { try { systemPreferences.askForMediaAccess("microphone"); } catch { } }
  buildMenu();
  createMain();
  updater = createUpdater({ RW, library, libraryPacks, onStatus: (st) => { if (mainWin && !mainWin.isDestroyed()) mainWin.webContents.send("update-status", st); } });
  screen.on("display-removed", () => { for (const [m, w] of Object.entries(outputs)) if (!w.isDestroyed()) { const b = w.getBounds(); if (!screen.getAllDisplays().some(d => b.x >= d.bounds.x && b.x < d.bounds.x + d.bounds.width)) w.close(); } });
});
app.on("activate", () => { if (!mainWin) createMain(); });
app.on("window-all-closed", () => app.quit());
