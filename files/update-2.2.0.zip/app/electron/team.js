// Team songbook: songs added on the team phones arrive in a private GitHub "inbox" repo; the media desk approves
// them here and publishes the church library (locked pack) to the public update repo, so every computer and phone
// gets the new songs. Needs a GitHub fine-grained token (Contents: read & write) for the inbox + releases repos,
// pasted once in Settings. The token is kept with the OS keychain (safeStorage) and never leaves this computer.
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { buildPack, decryptPack, readHeader } = require("./library.js");

const API = () => (process.env.RW_GITHUB_API || "https://api.github.com").replace(/\/$/, "");
const DEFAULTS = { inbox: "capstoneen04/revival-song-inbox", releases: "capstoneen04/revival-worship-releases" };

function createTeam({ userData, safeStorage, library, updatesDir, getSalt }) {
  const dir = path.join(userData, "team"), tokFile = path.join(dir, ".token"), cfgFile = path.join(dir, "team.json");
  const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };
  const cfg = () => ({ ...DEFAULTS, ...readJson(cfgFile, {}) });
  const token = () => {
    try { const s = fs.readFileSync(tokFile, "utf8"); if (s.startsWith("k1:")) return safeStorage.decryptString(Buffer.from(s.slice(3), "base64")); if (s.startsWith("k0:")) return Buffer.from(s.slice(3), "base64").toString(); } catch { }
    return "";
  };
  async function gh(method, url, body, { raw = false, ok404 = false } = {}) {
    const t = token(); if (!t) throw new Error("Add the GitHub team key in Settings first");
    const r = await fetch(API() + url, { method, headers: { authorization: "Bearer " + t, accept: raw ? "application/vnd.github.raw" : "application/vnd.github+json", "x-github-api-version": "2022-11-28", "user-agent": "RevivalWorship", ...(body ? { "content-type": "application/json" } : {}) }, body: body ? JSON.stringify(body) : undefined });
    if (ok404 && r.status === 404) return null;
    if (r.status === 401) throw new Error("GitHub refused the team key (expired or wrong)");
    if (r.status === 403 || r.status === 404) throw new Error(`GitHub: no access to ${url.split("/").slice(2, 4).join("/")} — check the key's repositories and “Contents: Read and write”`);
    if (!r.ok) throw new Error(`GitHub ${r.status}: ${(await r.text()).slice(0, 120)}`);
    return raw ? Buffer.from(await r.arrayBuffer()) : r.status === 204 ? null : r.json();
  }
  const enc = (s) => encodeURIComponent(s).replace(/%2F/g, "/");
  const getFile = async (repo, p) => gh("GET", `/repos/${repo}/contents/${enc(p)}`, null, { ok404: true });
  const delFile = (repo, p, sha, message) => gh("DELETE", `/repos/${repo}/contents/${enc(p)}`, { message, sha });
  // one commit with several files (Git Data API: big files up to 100 MB, all-or-nothing)
  async function commit(repo, message, put = {}, remove = []) {
    const ref = await gh("GET", `/repos/${repo}/git/ref/heads/main`); const parent = ref.object.sha;
    const base = await gh("GET", `/repos/${repo}/git/commits/${parent}`);
    const tree = [];
    for (const [p, buf] of Object.entries(put)) { const blob = await gh("POST", `/repos/${repo}/git/blobs`, { content: Buffer.from(buf).toString("base64"), encoding: "base64" }); tree.push({ path: p, mode: "100644", type: "blob", sha: blob.sha }); }
    for (const p of remove) tree.push({ path: p, mode: "100644", type: "blob", sha: null });
    const t = await gh("POST", `/repos/${repo}/git/trees`, { base_tree: base.tree.sha, tree });
    const c = await gh("POST", `/repos/${repo}/git/commits`, { message, tree: t.sha, parents: [parent] });
    await gh("PATCH", `/repos/${repo}/git/refs/heads/main`, { sha: c.sha });
    return c.sha;
  }
  const version = (d = new Date()) => `${d.getFullYear() % 100}.${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}.${String(d.getHours()).padStart(2, "0")}${String(d.getMinutes()).padStart(2, "0")}`;
  const newer = (a, b) => String(a?.updated || "") > String(b?.updated || "");

  const team = {
    status() { const c = cfg(); return { hasToken: !!token(), inbox: c.inbox, releases: c.releases, lastPublish: c.lastPublish || null }; },
    setToken(t, inbox) {
      fs.mkdirSync(dir, { recursive: true });
      if (t === "") { try { fs.unlinkSync(tokFile); } catch { } }
      else if (t) { const s = safeStorage.isEncryptionAvailable() ? "k1:" + safeStorage.encryptString(t.trim()).toString("base64") : "k0:" + Buffer.from(t.trim()).toString("base64"); fs.writeFileSync(tokFile, s, { mode: 0o600 }); }
      if (inbox) fs.writeFileSync(cfgFile, JSON.stringify({ ...readJson(cfgFile, {}), inbox: inbox.trim() }));
      return team.status();
    },
    async check() { const c = cfg(); await gh("GET", `/repos/${c.inbox}`); await gh("GET", `/repos/${c.releases}`); return { ok: true }; },
    // ---- inbox ----
    async inbox() {
      const c = cfg(); const list = await gh("GET", `/repos/${c.inbox}/contents/inbox`, null, { ok404: true }) || [];
      const out = [];
      for (const f of list.filter(f => f.type === "file" && f.name.endsWith(".json"))) {
        try { const data = JSON.parse((await gh("GET", `/repos/${c.inbox}/contents/${enc(f.path)}`, null, { raw: true })).toString("utf8")); out.push({ name: f.name, path: f.path, sha: f.sha, ...data }); } catch { }
      }
      return out.sort((a, b) => String(a.at).localeCompare(String(b.at)));
    },
    async remove(p, sha, why = "approved") { const c = cfg(); await delFile(c.inbox, p, sha, `Song ${why}`); return { ok: true }; },
    // ---- publish: merge this computer's songs into the newest published library and upload a new locked pack ----
    async publish(localSongs, { by = "", onStep = () => { } } = {}) {
      const c = cfg(); const key = library.key(); if (!key) throw new Error("Unlock the church library on this computer first");
      onStep("Reading the published library…");
      const manFile = await getFile(c.releases, "latest.json"); if (!manFile) throw new Error("latest.json not found in " + c.releases);
      const man = JSON.parse(Buffer.from(manFile.content, "base64").toString("utf8"));
      let files = {}, base = [], pubSalt = null;
      if (man.library?.name) {
        const buf = await gh("GET", `/repos/${c.releases}/contents/files/${enc(man.library.name)}`, null, { raw: true });
        const tmp = path.join(dir, "published.rwpack"); fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(tmp, buf);
        pubSalt = readHeader(tmp).header.salt;
        files = decryptPack(tmp, key).data.files; fs.unlinkSync(tmp);
      } else { const inst = library.readInstalled(); if (inst) files = inst.files; }
      const songsDoc = files["songs.json"] ? JSON.parse(Buffer.from(files["songs.json"], "base64").toString("utf8")) : { version: 0, songs: [] };
      base = songsDoc.songs || [];
      onStep("Merging songs…");
      const byId = new Map(base.map(s => [s.id, s])); let added = 0, changed = 0;
      for (const s of localSongs) {
        if (!s?.id || !s.versions) continue;
        const clean = { ...s }; delete clean._score;
        const old = byId.get(s.id);
        if (!old) { byId.set(s.id, clean); added++; }
        else if (newer(s, old) && JSON.stringify({ ...old, updated: 0 }) !== JSON.stringify({ ...clean, updated: 0 })) { byId.set(s.id, clean); changed++; }
      }
      if (!added && !changed) return { ok: true, nothing: true, version: man.library?.version };
      const v = version();
      songsDoc.songs = [...byId.values()]; songsDoc.version = Date.now(); songsDoc.generated = new Date().toISOString(); songsDoc.publishedBy = by;
      files["songs.json"] = Buffer.from(JSON.stringify(songsDoc)).toString("base64");
      onStep("Locking the library…");
      const salt = pubSalt || getSalt(); if (!salt) throw new Error("Church library file not found on this computer");
      const { header, buf } = buildPack({ files, key, salt, version: v });
      const name = `church-library-${v}.rwpack`;
      onStep("Uploading to GitHub…");
      const lib = { name, size: buf.length, sha256: crypto.createHash("sha256").update(buf).digest("hex"), version: v };
      const fresh = await getFile(c.releases, "latest.json");   // re-read: keep anything changed meanwhile (e.g. a new app version)
      const man2 = JSON.parse(Buffer.from(fresh.content, "base64").toString("utf8")); const oldName = man2.library?.name;
      man2.library = lib;
      await commit(c.releases, `Church library ${v}: ${added} new, ${changed} changed${by ? " (" + by + ")" : ""}`,
        { [`files/${name}`]: buf, "latest.json": Buffer.from(JSON.stringify(man2, null, 1)) }, oldName && oldName !== name ? [`files/${oldName}`] : []);
      // this computer: install the new pack right away
      try { fs.mkdirSync(updatesDir, { recursive: true }); fs.writeFileSync(path.join(updatesDir, `library-${v}.rwpack`), buf); } catch { }
      fs.writeFileSync(cfgFile, JSON.stringify({ ...readJson(cfgFile, {}), lastPublish: { version: v, at: new Date().toISOString(), added, changed, total: songsDoc.songs.length } }));
      return { ok: true, version: v, added, changed, total: songsDoc.songs.length, header: { version: header.version } };
    },
  };
  return team;
}
module.exports = { createTeam, DEFAULTS };
