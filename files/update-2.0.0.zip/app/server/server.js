// Revival Worship local server: serves the app, OBS overlays, phone remote, and a WebSocket message bus.
// Usage: node server/server.js  (or started automatically by the Mac app)
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { WebSocketServer } = require("ws");

const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml", ".ttf": "font/ttf", ".woff2": "font/woff2", ".wasm": "application/wasm", ".gz": "application/gzip", ".ico": "image/x-icon", ".webmanifest": "application/manifest+json", ".mp4": "video/mp4", ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".aac": "audio/aac", ".wav": "audio/wav", ".ogg": "audio/ogg", ".webp": "image/webp", ".gif": "image/gif", ".heic": "image/heic" };
const MEDIA_OK = /\.(mp3|m4a|aac|wav|ogg|jpg|jpeg|png|webp|gif)$/i;

// Church media (pictures + music) lives in the Revival Church folder so it is easy to add/replace files in Finder
function defaultMediaRoot() { return process.env.RW_MEDIA || path.join(os.homedir(), "Documents", "Revival Church", "Revival Worship App", "Media"); }
function safeJoin(root, rel) { const f = path.normalize(path.join(root, rel || "")); return f.startsWith(path.normalize(root)) ? f : null; }
function sendFile(req, res, file, st) {
  const type = MIME[path.extname(file).toLowerCase()] || "application/octet-stream";
  const range = req.headers.range && /bytes=(\d*)-(\d*)/.exec(req.headers.range);
  if (range) {
    const start = range[1] ? +range[1] : 0, end = range[2] ? Math.min(+range[2], st.size - 1) : st.size - 1;
    res.writeHead(206, { "content-type": type, "content-range": `bytes ${start}-${end}/${st.size}`, "accept-ranges": "bytes", "content-length": end - start + 1, "access-control-allow-origin": "*", "cache-control": "no-cache" });
    fs.createReadStream(file, { start, end }).pipe(res); return;
  }
  res.writeHead(200, { "content-type": type, "content-length": st.size, "accept-ranges": "bytes", "cache-control": "no-cache", "access-control-allow-origin": "*" });
  fs.createReadStream(file).pipe(res);
}

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) if (a.family === "IPv4" && !a.internal) out.push(a.address);
  return out;
}

// ---- first-run setup: copy the church resources that ship inside the app into Documents/Revival Church/Revival Worship App ----
// Files are copied only once each (remembered in .rw-seeded.json), and never over a file that already exists, so anything
// the team changes, replaces or removes later stays the way they left it.
const FOLDERS = ["Media/Pictures", "Media/Music/Start", "Media/Music/End", "Media/People", "Media/Thumbnails/Backgrounds", "Media/Themes", "Backup", "ATEM presets"];
function setupFolders(appDir, seedDirs, log = () => { }) {
  const list = (Array.isArray(seedDirs) ? seedDirs : [seedDirs]).filter(d => d && fs.existsSync(d));
  let total = { appDir, created: [], copied: 0, skipped: 0, errors: [] };
  for (const [i, d] of (list.length ? list : [null]).entries()) { const r = setupOne(appDir, d, log); if (i === 0) total.created = r.created; total.copied += r.copied; total.skipped += r.skipped; total.errors.push(...r.errors); }
  return total;
}
function setupOne(appDir, seedDir, log) {
  const report = { appDir, created: [], copied: 0, skipped: 0, errors: [] };
  for (const d of FOLDERS) { const f = path.join(appDir, d); if (!fs.existsSync(f)) { try { fs.mkdirSync(f, { recursive: true }); report.created.push(d); } catch (e) { report.errors.push(d + ": " + e.message); } } }
  if (!seedDir || !fs.existsSync(seedDir)) return report;
  const manFile = path.join(appDir, ".rw-seeded.json");
  let man = {}; try { man = JSON.parse(fs.readFileSync(manFile, "utf8")); } catch { }
  const walk = (rel) => {
    for (const e of fs.readdirSync(path.join(seedDir, rel), { withFileTypes: true })) {
      if (e.name.startsWith(".")) continue;
      const r = rel ? rel + "/" + e.name : e.name;
      if (e.isDirectory()) { fs.mkdirSync(path.join(appDir, r), { recursive: true }); walk(r); continue; }
      if (r.startsWith("Backup/")) continue;                   // the bundled database is read in place (see /api/seed-data)
      const dest = path.join(appDir, r);
      if (man[r] || fs.existsSync(dest)) { report.skipped++; man[r] = man[r] || 1; continue; }
      try { fs.copyFileSync(path.join(seedDir, r), dest); man[r] = 1; report.copied++; } catch (e) { report.errors.push(r + ": " + e.message); }
    }
  };
  try { walk(""); } catch (e) { report.errors.push(e.message); }
  try { fs.writeFileSync(manFile, JSON.stringify(man, null, 1)); } catch { }
  if (report.copied) log(`First-run setup: copied ${report.copied} files into ${appDir}`);
  return report;
}
const isLocal = (req) => /^(::1|127\.|::ffff:127\.)/.test(req.socket.remoteAddress || "");
function readJsonBody(req, max, cb) { let n = 0, chunks = []; req.on("data", c => { n += c.length; if (n > max) req.destroy(); else chunks.push(c); }); req.on("end", () => { try { cb(null, JSON.parse(Buffer.concat(chunks).toString("utf8"))); } catch (e) { cb(e); } }); }

function start({ port = 7777, root = path.join(__dirname, "..", "web"), host = "0.0.0.0", log = console.log, mediaRoot = defaultMediaRoot(), seedDir = null, libraryDir = null, fallbackRoot = null } = {}) {
  const appDir = path.dirname(mediaRoot), backupDir = path.join(appDir, "Backup");
  const seedDirs = Array.isArray(seedDir) ? seedDir : [seedDir];
  seedDir = seedDirs.find(d => d && fs.existsSync(path.join(d, "Backup", "church-data.json"))) || seedDirs[0] || null;
  const setup = setupFolders(appDir, seedDirs, log);
  // songs + Hindi Bible: from the unlocked church library (installed app) or the repo's library/ folder (developer copy)
  const libDirs = [libraryDir, path.join(__dirname, "..", "library")].filter(Boolean);
  const LIB_FILES = { "/data/songs.json": "songs.json", "/data/bible-hindi.json": "bible-hindi.json" };
  const cache = { state: null, theme: null, broadcast: null };
  const server = http.createServer((req, res) => {
    const u = new URL(req.url, "http://x");
    if (u.pathname === "/api/info") {
      res.writeHead(200, { "content-type": "application/json", "access-control-allow-origin": "*" });
      res.end(JSON.stringify({ port, hostname: os.hostname(), addresses: lanAddresses(), clients: wss.clients.size }));
      return;
    }
    if (u.pathname === "/api/send" && req.method === "POST") {
      let body = ""; req.on("data", c => (body += c)); req.on("end", () => { try { broadcast(JSON.parse(body)); } catch { } res.writeHead(204, { "access-control-allow-origin": "*" }); res.end(); });
      return;
    }
    // ---- setup + database backups (this computer only) ----
    if (u.pathname === "/api/setup") { res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify({ ...setup, seedDir: !!seedDir, bundledData: !!(seedDir && fs.existsSync(path.join(seedDir, "Backup", "church-data.json"))) })); return; }
    if (u.pathname === "/api/seed-data") {
      // newest database to start a fresh computer with: a backup someone copied into Backup/, else the one shipped in the app
      if (!isLocal(req)) { res.writeHead(403); res.end(); return; }
      let pick = null;
      try { const list = fs.readdirSync(backupDir).filter(n => /^church-data.*\.json$/.test(n)).map(n => path.join(backupDir, n)); list.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs); pick = list[0] || null; } catch { }
      if (!pick && seedDir) { const b = path.join(seedDir, "Backup", "church-data.json"); if (fs.existsSync(b)) pick = b; }
      if (!pick) { res.writeHead(404); res.end("{}"); return; }
      res.writeHead(200, { "content-type": "application/json", "x-source": encodeURIComponent(path.basename(pick)), "cache-control": "no-store" }); fs.createReadStream(pick).pipe(res); return;
    }
    if (u.pathname === "/api/backup" && req.method === "POST") {
      if (!isLocal(req)) { res.writeHead(403); res.end(); return; }
      readJsonBody(req, 200 * 1024 * 1024, (err, data) => {
        if (err || !data || data.app !== "revival-worship") { res.writeHead(400); res.end("bad backup"); return; }
        try {
          fs.mkdirSync(backupDir, { recursive: true });
          const day = new Date(), stamp = `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(day.getDate()).padStart(2, "0")}`;
          const f = path.join(backupDir, `church-data ${stamp}.json`), tmp = f + ".tmp";
          fs.writeFileSync(tmp, JSON.stringify(data)); fs.renameSync(tmp, f);         // never leaves a half-written file
          const old = fs.readdirSync(backupDir).filter(n => /^church-data .*\.json$/.test(n)).sort().reverse().slice(30);   // keep 30 days
          for (const n of old) { try { fs.unlinkSync(path.join(backupDir, n)); } catch { } }
          res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify({ ok: true, file: f }));
        } catch (e) { res.writeHead(500); res.end(e.message); }
      });
      return;
    }
    // ---- media library ----
    if (u.pathname === "/api/media") {
      const dir = safeJoin(mediaRoot, u.searchParams.get("dir") || "");
      let files = [];
      try { files = fs.readdirSync(dir).filter(n => MEDIA_OK.test(n) && !n.startsWith(".")).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).map(n => ({ name: n, url: "/media/" + encodeURI(path.relative(mediaRoot, path.join(dir, n)).split(path.sep).join("/")), size: fs.statSync(path.join(dir, n)).size })); } catch { }
      res.writeHead(200, { "content-type": "application/json", "access-control-allow-origin": "*", "cache-control": "no-cache" });
      let dirs = []; try { dirs = fs.readdirSync(dir, { withFileTypes: true }).filter(d => d.isDirectory() && !d.name.startsWith(".") && d.name !== "Removed").map(d => d.name).sort(); } catch { }
      res.end(JSON.stringify({ root: mediaRoot, dir: u.searchParams.get("dir") || "", files, dirs })); return;
    }
    if (u.pathname === "/api/upload" && req.method === "POST") {
      const rel = u.searchParams.get("path") || "";
      const f = safeJoin(mediaRoot, rel);
      const themeJson = /^Themes\/[^/]+\/theme\.json$/.test(rel);
      if (!f || !(MEDIA_OK.test(f) || themeJson)) { res.writeHead(400); res.end("bad path"); return; }
      fs.mkdirSync(path.dirname(f), { recursive: true });
      const out = fs.createWriteStream(f); let n = 0;
      req.on("data", c => { n += c.length; if (n > 300 * 1024 * 1024) req.destroy(); });
      req.pipe(out);
      out.on("finish", () => { res.writeHead(200, { "content-type": "application/json", "access-control-allow-origin": "*" }); res.end(JSON.stringify({ ok: true, url: "/media/" + encodeURI(rel) })); });
      out.on("error", e => { res.writeHead(500); res.end(e.message); });
      return;
    }
    if (u.pathname === "/api/media-remove" && req.method === "POST") {
      // never deletes: moves the file into Media/Removed so it can be brought back in Finder
      const rel = u.searchParams.get("path") || "", f = safeJoin(mediaRoot, rel);
      try { const dest = path.join(mediaRoot, "Removed", path.basename(f)); fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.renameSync(f, dest); res.writeHead(200, { "access-control-allow-origin": "*" }); res.end("{}"); }
      catch (e) { res.writeHead(500); res.end(e.message); }
      return;
    }
    if (LIB_FILES[u.pathname]) {
      const f = libDirs.map(d => path.join(d, LIB_FILES[u.pathname])).find(x => fs.existsSync(x));
      if (!f) { res.writeHead(404, { "content-type": "application/json" }); res.end(JSON.stringify({ error: "library-locked" })); return; }
      fs.stat(f, (err, st) => { if (err) { res.writeHead(404); res.end(); return; } sendFile(req, res, f, st); });
      return;
    }
    if (u.pathname.startsWith("/media/")) {
      const f = safeJoin(mediaRoot, decodeURIComponent(u.pathname.slice(7)));
      if (!f) { res.writeHead(403); res.end(); return; }
      fs.stat(f, (err, st) => { if (err || !st.isFile()) { res.writeHead(404); res.end("Not found"); return; } sendFile(req, res, f, st); });
      return;
    }
    let p = decodeURIComponent(u.pathname);
    if (p === "/") p = "/index.html";
    // an update carries only what changed; big unchanged files (libraries, pictures) come from the installed copy
    const roots = [root, fallbackRoot].filter(Boolean);
    const tryRoot = (k) => {
      if (k >= roots.length) { res.writeHead(404, { "content-type": "text/plain" }); res.end("Not found"); return; }
      const file = path.normalize(path.join(roots[k], p));
      if (!file.startsWith(path.normalize(roots[k]))) { res.writeHead(403); res.end(); return; }
      fs.stat(file, (err, st) => { if (err || !st.isFile()) return tryRoot(k + 1); sendFile(req, res, file, st); });
    };
    tryRoot(0);
  });
  const wss = new WebSocketServer({ server, path: "/bus", maxPayload: 32 * 1024 * 1024 });
  function broadcast(msg, except) {
    if (msg && msg.type === "state") cache.state = msg;
    if (msg && msg.type === "theme") cache.theme = msg;
    if (msg && msg.type === "broadcast") cache.broadcast = msg;
    const s = JSON.stringify(msg);
    for (const c of wss.clients) if (c !== except && c.readyState === 1) c.send(s);
  }
  wss.on("connection", (ws) => {
    ws.on("message", (data) => {
      let msg; try { msg = JSON.parse(data); } catch { return; }
      if (msg.type === "hello") return;
      if (msg.type === "need-state") {
        if (cache.theme) ws.send(JSON.stringify(cache.theme));
        if (cache.state) ws.send(JSON.stringify(cache.state));
        if (cache.broadcast) ws.send(JSON.stringify(cache.broadcast));
      }
      broadcast(msg, ws);
    });
  });
  return new Promise((resolve, reject) => {
    server.on("error", reject);
    server.listen(port, host, () => { log(`Revival Worship server on http://localhost:${port}  (LAN: ${lanAddresses().map(a => `http://${a}:${port}`).join(", ")})`); resolve({ server, wss, broadcast, port, lanAddresses, mediaRoot, appDir, setup }); });
  });
}

module.exports = { start, lanAddresses };
if (require.main === module) start({ port: +process.env.PORT || 7777 }).catch(e => { console.error(e.message); process.exit(1); });
