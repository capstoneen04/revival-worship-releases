import { ensureSeeded, startAutoBackup, mergeLibrarySongs } from "./db.js";
import { libraryGate } from "./unlock.js";
import { S, bus, onChange, emit, loadSettings, loadLibrary, loadService, sendTheme, sendBroadcast, broadcast, next, prev, toggleOverride, toggleLowerFollow, openOutput, obsConnect, isTyping, go, native, toast } from "./core.js";
import { songsView } from "./views/songs.js";
import { serviceView } from "./views/service.js";
import { liveView } from "./views/live.js";
import { bibleView } from "./views/bible.js";
import { messageView } from "./views/message.js";
import { ocrView } from "./views/ocr.js";
import { obsView } from "./views/obs.js";
import { broadcastView } from "./views/broadcast.js";
import { settingsView } from "./views/settings.js";
import { productionView } from "./views/production.js";
import { sermonView } from "./views/sermon.js";
import { guideView } from "./views/guide.js";
import { applySplitLayout, refreshOverlays } from "./autoframe.js";
import { startHealth, healthText, healthTip } from "./obs-health.js";
import { startSound, sound } from "./sound.js";
import { startUi } from "./ui-theme.js";
import { atemConnect } from "./atem-client.js";

const VIEWS = { guide: ["Guide — what to use when", guideView], production: ["Production", productionView], sermon: ["Sermon · YouTube · Thumbnail", sermonView], songs: ["Songs", songsView], service: ["Service planner", serviceView], live: ["Live", liveView], bible: ["Bible", bibleView], message: ["The Message", messageView], ocr: ["Image → Text", ocrView], obs: ["OBS & Lower Thirds", obsView], broadcast: ["Broadcast", broadcastView], settings: ["Settings", settingsView] };
const mounted = {};
let current = null;

export function show(name) {
  if (!VIEWS[name]) name = "songs";
  current = name;
  document.querySelectorAll("#rail button[data-view]").forEach(b => b.classList.toggle("on", b.dataset.view === name));
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("on", v.id === "v-" + name));
  document.getElementById("viewtitle").textContent = VIEWS[name][0];
  const el = document.getElementById("v-" + name);
  if (!mounted[name]) mounted[name] = VIEWS[name][1](el) || {};
  mounted[name].onShow?.();
  try { localStorage.setItem("rw-view", name); } catch { }
}
window.rwShow = show;
window.rwViews = mounted;

async function boot() {
  const bootEl = document.getElementById("boot");
  await loadSettings();
  await libraryGate(bootEl);
  const seeded = await ensureSeeded(msg => (bootEl.textContent = msg));
  if (!seeded.seeded) await mergeLibrarySongs(msg => (bootEl.textContent = msg)).catch(() => { });
  await loadLibrary();
  await loadService();
  bootEl.remove();
  startAutoBackup();
  document.querySelectorAll("#rail button[data-view]").forEach(b => b.onclick = () => show(b.dataset.view));
  document.querySelectorAll("#onair [data-act]").forEach(b => b.onclick = () => {
    const a = b.dataset.act;
    if (a === "next") next(); else if (a === "prev") prev(); else if (a === "lower") toggleLowerFollow();
    else if (a === "projector") openOutput("projector"); else toggleOverride(a);
  });
  onChange(updateTop);
  updateTop();
  // first run → the Guide; after that, the last page used
  let start = "guide"; try { start = localStorage.getItem("rw-view") || "guide"; } catch { }
  show(start);
  sendTheme(); broadcast(); sendBroadcast();
  if (S.settings.obs.autoConnect && (S.settings.obs.connectedOnce || native?.obsLocalConfig)) obsConnect(true);
  setInterval(() => { if (S.settings.obs.autoConnect && !S.obs.connected && native?.obsLocalConfig) obsConnect(true); }, 15000);
  if (native?.onQuote) native.onQuote(q => { emit({ quote: q }); show("message"); });
  // OBS just connected: put the split scenes in the chosen layout (and start auto-framing if it's portrait)
  let wasObs = false;
  // only overlays that failed to load are reloaded — working ones are never touched (nothing flashes on stream)
  onChange(w => { if (w === "obs") { if (S.obs.connected && !wasObs) { setTimeout(() => refreshOverlays().catch(() => { }), 2500); applySplitLayout(); } wasObs = S.obs.connected; } });
  startHealth();
  startSound();
  startUi();
  if (native?.atem && S.settings.atem.auto && S.settings.atem.ip) atemConnect(S.settings.atem.ip, true);
  // keyboard
  document.addEventListener("keydown", e => {
    if ((e.metaKey || e.ctrlKey) && e.key === "0") { e.preventDefault(); show("production"); return; }
    if ((e.metaKey || e.ctrlKey) && /^[1-7]$/.test(e.key)) { e.preventDefault(); show(["songs", "service", "live", "bible", "message", "ocr", "obs"][+e.key - 1]); return; }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "f") { const i = document.querySelector(".view.on input[type=search]"); if (i) { e.preventDefault(); i.focus(); i.select(); } return; }
    if (isTyping() || e.metaKey || e.ctrlKey || e.altKey) return;
    const k = e.key;
    if (k === "ArrowRight" || k === "ArrowDown" || k === " " || k === "PageDown") { e.preventDefault(); next(); }
    else if (k === "ArrowLeft" || k === "ArrowUp" || k === "PageUp") { e.preventDefault(); prev(); }
    else if (k === "b" || k === "B" || k === ".") toggleOverride("blank");
    else if (k === "l" || k === "L") toggleOverride("logo");
    else if (k === "Escape") toggleOverride("clear");
    else if (k === "t" || k === "T") toggleLowerFollow();
    else if (/^[1-9]$/.test(k) || k === "c" || k === "C") {
      const target = k.toLowerCase() === "c" ? /^chorus/i : new RegExp(`^verse ${k}\\b`, "i");
      const i = S.live.slides.findIndex((s, idx) => target.test(s.section || s.label || "") && (k.toLowerCase() !== "c" || idx > S.live.index || true));
      if (i >= 0) go(i);
    }
  });
}

function updateTop() {
  const live = S.live, sl = live.slides[live.index];
  const lab = document.getElementById("live-label");
  const pill = document.getElementById("pill-live");
  if (live.override) { lab.textContent = live.override === "blank" ? "Blank screen" : live.override === "logo" ? "Logo" : "Text cleared"; pill.className = "pill"; }
  else if (sl) { lab.textContent = `${live.title} · ${sl.label || ""}`.slice(0, 48); pill.className = "pill live"; }
  else { lab.textContent = "Nothing live"; pill.className = "pill"; }
  document.getElementById("btn-lower").classList.toggle("on", S.lowerFollow);
  const po = document.getElementById("pill-obs"), lv = S.obsStats?.level;
  po.className = "pill" + (S.obs.connected ? (lv === "bad" ? " bad" : lv === "warn" ? " warn" : " ok") : "");
  po.lastElementChild.textContent = S.obs.connected ? `OBS · ${(S.obsScenes.current || "connected").replace(/^Revival · \d+ /, "")}` : "OBS off";
  const ph = document.getElementById("pill-health");
  if (ph) { const t = healthText(); ph.style.display = t ? "" : "none"; ph.lastElementChild.textContent = t; ph.title = healthTip(); ph.className = "pill" + (lv === "bad" ? " bad" : lv === "warn" ? " warn" : " ok"); }
  const psn = document.getElementById("pill-sound");
  if (psn) { const on = sound.level !== "off" && !!sound.status; psn.style.display = on ? "" : "none"; psn.lastElementChild.textContent = sound.level === "bad" ? "Sound ⚠ " + (sound.alerts[0]?.title || "") : sound.status; psn.title = (sound.alerts || []).map(a => a.title).join("\n") || "Sound OK"; psn.className = "pill" + (sound.level === "bad" ? " bad" : sound.level === "warn" ? " warn" : " ok"); psn.onclick = () => show("production"); }
  const pl = document.getElementById("pill-onair");
  if (pl) { const o = S.obsStats || {}; pl.style.display = o.live ? "" : "none"; pl.lastElementChild.textContent = o.stream ? `LIVE ${o.tc || ""}` : `REC ${o.rtc || ""}`; }
  document.getElementById("pill-bus").className = "pill" + (S.busConnected ? " ok" : "");
  document.getElementById("pill-bus").lastElementChild.textContent = S.busConnected ? "Outputs linked" : "Outputs: this browser";
}

boot().catch(e => { console.error(e); document.getElementById("boot").textContent = "Error: " + e.message; });
