// Bible loading + reference parsing (English & Hindi book names)
const cache = {};
export async function loadBible(id) {
  if (!cache[id]) cache[id] = fetch(`data/bible-${id}.json`).then(r => r.json());
  return cache[id];
}

const EN = ["Genesis", "Exodus", "Leviticus", "Numbers", "Deuteronomy", "Joshua", "Judges", "Ruth", "1 Samuel", "2 Samuel", "1 Kings", "2 Kings", "1 Chronicles", "2 Chronicles", "Ezra", "Nehemiah", "Esther", "Job", "Psalms", "Proverbs", "Ecclesiastes", "Song of Solomon", "Isaiah", "Jeremiah", "Lamentations", "Ezekiel", "Daniel", "Hosea", "Joel", "Amos", "Obadiah", "Jonah", "Micah", "Nahum", "Habakkuk", "Zephaniah", "Haggai", "Zechariah", "Malachi", "Matthew", "Mark", "Luke", "John", "Acts", "Romans", "1 Corinthians", "2 Corinthians", "Galatians", "Ephesians", "Philippians", "Colossians", "1 Thessalonians", "2 Thessalonians", "1 Timothy", "2 Timothy", "Titus", "Philemon", "Hebrews", "James", "1 Peter", "2 Peter", "1 John", "2 John", "3 John", "Jude", "Revelation"];
export const BOOKS_EN = EN;
const ABBR = {
  gen: 1, ge: 1, gn: 1, ex: 2, exo: 2, exod: 2, lev: 3, le: 3, num: 4, nu: 4, deut: 5, dt: 5, de: 5, josh: 6, jos: 6, judg: 7, jdg: 7, ru: 8, rut: 8,
  "1sam": 9, "1sa": 9, "2sam": 10, "2sa": 10, "1ki": 11, "1kgs": 11, "1kings": 11, "2ki": 12, "2kgs": 12, "2kings": 12, "1chr": 13, "1ch": 13, "2chr": 14, "2ch": 14,
  ezr: 15, neh: 16, est: 17, esth: 17, jb: 18, ps: 19, psa: 19, psalm: 19, pss: 19, pr: 20, prov: 20, pro: 20, ecc: 21, eccl: 21, ec: 21, song: 22, sos: 22, ss: 22, songofsongs: 22,
  isa: 23, is: 23, jer: 24, je: 24, lam: 25, la: 25, ezek: 26, eze: 26, ezk: 26, dan: 27, da: 27, dn: 27, hos: 28, ho: 28, joe: 29, jl: 29, am: 30, amo: 30, ob: 31, obad: 31,
  jon: 32, jnh: 32, mic: 33, mi: 33, nah: 34, na: 34, hab: 35, zeph: 36, zep: 36, hag: 37, hg: 37, zech: 38, zec: 38, mal: 39,
  mt: 40, matt: 40, mat: 40, mk: 41, mar: 41, mrk: 41, lk: 42, luk: 42, lu: 42, jn: 43, joh: 43, jhn: 43, ac: 44, act: 44, rom: 45, ro: 45, rm: 45,
  "1cor": 46, "1co": 46, "2cor": 47, "2co": 47, gal: 48, ga: 48, eph: 49, phil: 50, php: 50, col: 51, "1thess": 52, "1th": 52, "2thess": 53, "2th": 53,
  "1tim": 54, "1ti": 54, "2tim": 55, "2ti": 55, tit: 56, phlm: 57, phm: 57, philem: 57, heb: 58, jas: 59, jam: 59, jm: 59, "1pet": 60, "1pe": 60, "1pt": 60, "2pet": 61, "2pe": 61, "2pt": 61,
  "1jn": 62, "1jo": 62, "1john": 62, "2jn": 63, "2jo": 63, "3jn": 64, "3jo": 64, jud: 65, jude: 65, rev: 66, re: 66, rv: 66, revelations: 66,
};

let hiNames = null;
export function setHindiNames(names) { hiNames = names; }

function norm(s) { return s.toLowerCase().replace(/\s+/g, "").replace(/\./g, "").replace(/^(i{1,3})(?=[a-z])/, m => String(m.length)).replace(/^first/, "1").replace(/^second/, "2").replace(/^third/, "3"); }

export function findBook(name) {
  const n = norm(name);
  if (!n) return 0;
  if (/[ऀ-ॿ]/.test(name) && hiNames) {
    const t = name.replace(/\s+/g, "");
    let i = hiNames.findIndex(h => h.replace(/\s+/g, "") === t);
    if (i < 0) i = hiNames.findIndex(h => h.replace(/\s+/g, "").startsWith(t));
    return i + 1;
  }
  if (ABBR[n]) return ABBR[n];
  let i = EN.findIndex(b => norm(b) === n);
  if (i < 0) i = EN.findIndex(b => norm(b).startsWith(n));
  return i + 1;
}

// "jn 3 16", "John 3:16-18", "2 pet 1 4-11", "रोमियों 8:28", "Ps 23"
export function parseRef(q) {
  q = (q || "").trim();
  const m = q.match(/^((?:[1-3]\s*)?[^\d:]+?)\s*(\d+)?(?:\s*[:.\s]\s*(\d+))?(?:\s*[-–]\s*(\d+))?\s*$/);
  if (!m) return null;
  const book = findBook(m[1]);
  if (!book) return null;
  return { book, chapter: m[2] ? +m[2] : 1, verse: m[3] ? +m[3] : null, to: m[4] ? +m[4] : null };
}

export function refLabel(bible, r, opts = {}) {
  const name = (bible && bible.books[r.book - 1]) || EN[r.book - 1];
  let s = `${name} ${r.chapter}`;
  if (r.verse) s += `:${r.verse}`;
  if (r.to && r.to !== r.verse) s += `-${r.to}`;
  return s;
}

export function getVerses(bible, r) {
  const ch = bible.text[r.book - 1]?.[r.chapter - 1] || [];
  const from = r.verse || 1, to = r.to || r.verse || ch.length;
  const out = [];
  for (let v = from; v <= Math.min(to, ch.length); v++) out.push({ v, text: ch[v - 1] });
  return out;
}

export function searchBible(bible, q, limit = 100) {
  const t = q.toLowerCase().trim();
  if (t.length < 3) return [];
  const res = [];
  bible.text.forEach((b, bi) => b.forEach((c, ci) => c.forEach((v, vi) => {
    if (res.length < limit && v.toLowerCase().includes(t)) res.push({ book: bi + 1, chapter: ci + 1, verse: vi + 1, text: v });
  })));
  return res;
}
