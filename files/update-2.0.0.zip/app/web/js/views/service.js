import { S, h, db, uid, saveService, switchService, newService, itemTitle, songById, present, toast, modal, LANGS, onChange, addToService } from "../core.js";
import { parseRef, refLabel, loadBible, setHindiNames } from "../bible.js";

export function itemSub(it) {
  if (it.type === "song") { const s = songById(it.songId); const b = s?.books?.[0]; return [b ? `${b.book} ${b.num}` : "", it.lang1 ? LANGS[it.lang1] : "", it.lang2 ? "+ " + LANGS[it.lang2] : ""].filter(Boolean).join(" · ") || "Song"; }
  if (it.type === "bible") return "Scripture · " + ({ kjv: "KJV", hindi: "Hindi", both: "KJV + Hindi" }[it.version || S.settings.bibleVersion]);
  if (it.type === "message") return [it.code, it.para ? "¶" + it.para : ""].filter(Boolean).join(" ") || "Quote";
  if (it.type === "name") return "Name card · " + (it.role || "");
  if (it.type === "title") return "Title card";
  if (it.type === "text") return "Text / announcement";
  if (it.type === "sermon") return "Title · Subject · Inspiration · Scripture (EN + हिंदी)";
  return "";
}
export const ICON = { song: "♪", bible: "B", message: "M", name: "N", title: "T", text: "Aa", sermon: "S" };

export function quickSongSearch(onPick, placeholder = "Add a song: number, title or any line…") {
  const wrap = h("div", { style: "position:relative" });
  const input = h("input", { class: "input", type: "search", placeholder, style: "width:100%" });
  let box = null, hits = [], hl = 0;
  const close = () => { box?.remove(); box = null; };
  const render = () => {
    close(); if (!input.value.trim()) return;
    hits = S.index.search(input.value, { limit: 12 });
    box = h("div", { class: "quick-results", style: "top:36px;left:0;right:0" }, ...hits.map((r, i) => h("div", { class: "item" + (i === hl ? " hl" : ""), onmousedown: e => { e.preventDefault(); pick(r.song); } },
      h("div", { style: "font-family:var(--lyric);font-weight:550" }, r.song.title), h("div", { class: "dim", style: "font-size:11.5px" }, (r.song.books || []).slice(0, 3).map(b => `${b.book} ${b.num}`).join(" · ")))));
    if (!hits.length) box.appendChild(h("div", { class: "item dim" }, "No match"));
    wrap.appendChild(box);
  };
  const pick = (s) => { onPick(s); input.value = ""; close(); };
  input.oninput = () => { hl = 0; render(); };
  input.onblur = () => setTimeout(close, 150);
  input.onkeydown = e => {
    if (e.key === "ArrowDown") { e.preventDefault(); hl = Math.min(hits.length - 1, hl + 1); render(); }
    if (e.key === "ArrowUp") { e.preventDefault(); hl = Math.max(0, hl - 1); render(); }
    if (e.key === "Enter" && hits[hl]) pick(hits[hl].song);
    if (e.key === "Escape") { input.value = ""; close(); }
  };
  wrap.appendChild(input);
  return wrap;
}

export async function promptBible(onDone) {
  const kjv = await loadBible("kjv"); const hin = await loadBible("hindi"); setHindiNames(hin.books);
  const inp = h("input", { class: "input", placeholder: "e.g. jn 3 16  ·  Rev 10 1-7  ·  रोमियों 8:28" });
  const ver = h("select", { class: "input" }, h("option", { value: "both" }, "KJV + Hindi"), h("option", { value: "kjv" }, "KJV"), h("option", { value: "hindi" }, "Hindi"));
  ver.value = S.settings.bibleVersion;
  const prevw = h("div", { class: "muted", style: "min-height:20px" });
  inp.oninput = () => { const r = parseRef(inp.value); prevw.textContent = r ? refLabel(kjv, r) + " · " + refLabel(hin, r) : "…"; };
  modal("Add scripture", h("div", { class: "col" }, h("label", { class: "f" }, "Reference", inp), prevw, h("label", { class: "f" }, "Version", ver)),
    [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { const r = parseRef(inp.value); if (!r) { toast("Couldn't read that reference"); return false; } onDone({ type: "bible", ref: r, version: ver.value, label: refLabel(kjv, r) }); } }]);
  setTimeout(() => inp.focus(), 50);
}

export function promptCard(type, onDone) {
  if (type === "name") {
    const sel = h("select", { class: "input" }, h("option", { value: "" }, "— choose a saved person —"));
    db.all("people").then(ps => ps.forEach(p => sel.appendChild(h("option", { value: p.id }, `${p.name} — ${p.role}`))));
    const n = h("input", { class: "input", placeholder: "Name" }), r = h("input", { class: "input", placeholder: "Role (Song Leader, Pastor…)" });
    sel.onchange = async () => { const p = await db.get("people", sel.value); if (p) { n.value = p.name; r.value = p.role; } };
    modal("Name card (lower third)", h("div", { class: "col" }, sel, n, r), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!n.value) return false; onDone({ type: "name", name: n.value, role: r.value }); } }]);
  } else if (type === "title") {
    const t = h("input", { class: "input", placeholder: "Sermon or meeting title" }), s = h("input", { class: "input", placeholder: "Speaker / subtitle (optional)" });
    modal("Title card (lower third)", h("div", { class: "col" }, t, s), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!t.value) return false; onDone({ type: "title", title: t.value, subtitle: s.value }); } }]);
  } else if (type === "text") {
    const t = h("input", { class: "input", placeholder: "Heading (optional)" }), x = h("textarea", { class: "input", rows: 8, placeholder: "Announcement or any text. Blank line = new slide." });
    modal("Text slide", h("div", { class: "col" }, t, x), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!x.value.trim()) return false; onDone({ type: "text", title: t.value, text: x.value }); } }]);
  } else if (type === "message") {
    const x = h("textarea", { class: "input", rows: 7, placeholder: "Paste the quote" }), t = h("input", { class: "input", placeholder: "Sermon title" }), c = h("input", { class: "input", placeholder: "Date code e.g. 65-1127B", style: "width:180px" }), p = h("input", { class: "input", placeholder: "¶", style: "width:70px" });
    modal("Message quote", h("div", { class: "col" }, x, t, h("div", { class: "row" }, c, p)), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!x.value.trim()) return false; onDone({ type: "message", text: x.value.trim(), title: t.value, code: c.value, para: p.value }); } }]);
  }
}

export function serviceView(root) {
  const svcList = h("div", { class: "scroll list" });
  const items = h("div", { class: "scroll" });
  const nameIn = h("input", { class: "input", style: "font-weight:600;font-size:15px;flex:1" });
  const dateIn = h("input", { class: "input", type: "date" });
  nameIn.onchange = () => { S.service.name = nameIn.value; saveService(); renderSvcs(); };
  dateIn.onchange = () => { S.service.date = dateIn.value; saveService(); renderSvcs(); };
  const add = (it) => { it.id = uid("it"); S.service.items.push(it); saveService(); renderItems(); };
  root.append(
    h("div", { class: "panel", style: "width:280px;flex:0 0 280px" },
      h("div", { class: "panel-h" }, h("h2", {}, "Services"), h("span", { style: "flex:1" }), h("button", { class: "btn sm", onclick: async () => { const s = newService("New service"); await db.put("services", s); await switchService(s); renderAll(); } }, "+ New")),
      svcList),
    h("div", { style: "flex:1;display:flex;flex-direction:column;min-width:0" },
      h("div", { class: "panel-h", style: "background:var(--panel)" }, nameIn, dateIn,
        h("button", { class: "btn", onclick: async () => { const c = structuredClone(S.service); c.id = uid("svc"); c.name += " (copy)"; c.items.forEach(i => (i.id = uid("it"))); await db.put("services", c); await switchService(c); renderAll(); } }, "Duplicate"),
        h("button", { class: "btn ghost", onclick: () => modal("Delete this service?", h("p", { class: "muted" }, S.service.name), [{ label: "Cancel" }, { label: "Delete", cls: "live", fn: async () => { await db.del("services", S.service.id); const all = await db.all("services"); await switchService(all[0] || newService()); if (!all.length) await db.put("services", S.service); renderAll(); } }]) }, "Delete"),
        h("button", { class: "btn primary", onclick: () => { window.rwShow("live"); } }, "Present ▶")),
      h("div", { class: "panel-h", style: "background:var(--panel)" },
        h("div", { style: "flex:1;min-width:260px" }, quickSongSearch(s => add({ type: "song", songId: s.id }))),
        h("button", { class: "btn", onclick: () => promptBible(add) }, "+ Scripture"),
        h("button", { class: "btn", onclick: () => promptCard("message", add) }, "+ Quote"),
        h("button", { class: "btn", onclick: () => promptCard("name", add) }, "+ Name card"),
        h("button", { class: "btn", onclick: () => promptCard("title", add) }, "+ Title card"),
        h("button", { class: "btn", onclick: () => promptCard("text", add) }, "+ Text")),
      items));

  async function renderSvcs() {
    const all = (await db.all("services")).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    svcList.innerHTML = "";
    for (const s of all) svcList.appendChild(h("div", { class: "item" + (s.id === S.service.id ? " sel" : ""), onclick: async () => { await switchService(s); renderAll(); } },
      h("div", { style: "flex:1;min-width:0" }, h("div", { style: "font-weight:600" }, s.name), h("div", { class: "s" }, `${s.date || ""} · ${s.items.length} items`))));
  }
  function renderItems() {
    nameIn.value = S.service.name; dateIn.value = S.service.date || "";
    items.innerHTML = "";
    if (!S.service.items.length) { items.appendChild(h("div", { class: "empty" }, "Empty service. Add songs with the search box above, then scripture, quotes and name cards.")); return; }
    S.service.items.forEach((it, i) => {
      const song = it.type === "song" ? songById(it.songId) : null;
      const langSel = (key) => { const sel = h("select", { class: "input", style: "height:26px;font-size:12px", onclick: e => e.stopPropagation() }, key === "lang2" ? h("option", { value: "" }, "— none —") : h("option", { value: "" }, "Default"), ...Object.keys(song.versions).map(l => h("option", { value: l }, LANGS[l] || l))); sel.value = it[key] || ""; sel.onchange = () => { it[key] = sel.value || undefined; saveService(); renderItems(); }; return sel; };
      items.appendChild(h("div", { class: "svc-item", style: "padding:10px 16px" },
        h("div", { class: "dim", style: "width:22px;text-align:right" }, String(i + 1)),
        h("div", { class: "ic " + it.type }, ICON[it.type]),
        h("div", { style: "min-width:0;flex:1" }, h("div", { class: "tt" }, itemTitle(it)), h("div", { class: "st" }, itemSub(it))),
        song ? h("div", { class: "row", style: "flex-wrap:nowrap" }, h("span", { class: "dim" }, "Show"), langSel("lang1"), h("span", { class: "dim" }, "with"), langSel("lang2")) : null,
        h("div", { class: "row", style: "flex-wrap:nowrap;gap:2px" },
          h("button", { class: "btn sm ghost", title: "Move up", onclick: () => { if (i > 0) { const a = S.service.items; [a[i - 1], a[i]] = [a[i], a[i - 1]]; saveService(); renderItems(); } } }, "↑"),
          h("button", { class: "btn sm ghost", title: "Move down", onclick: () => { const a = S.service.items; if (i < a.length - 1) { [a[i + 1], a[i]] = [a[i], a[i + 1]]; saveService(); renderItems(); } } }, "↓"),
          h("button", { class: "btn sm ghost", title: "Present now", onclick: () => present(it, 0, { fromService: true }) }, "▶"),
          h("button", { class: "btn sm ghost", title: "Remove", onclick: () => { S.service.items.splice(i, 1); saveService(); renderItems(); } }, "✕"))));
    });
  }
  function renderAll() { renderSvcs(); renderItems(); }
  onChange(w => { if (w === "service") renderItems(); });
  renderAll();
  return { onShow: renderAll };
}
