// Production: one screen to run the whole service — OBS scenes, ATEM cameras, lyrics/verses, lower thirds,
// speaker presets, stream, YouTube title + thumbnail, and the live audio monitor.
import { S, h, onChange, emit, toast, modal, saveSettings, present, next, prev, toggleOverride, toggleLowerFollow, showLowerCard, hideLower, itemTitle, liveSlide, streamLines, dateCode, streamTitle, fetchQotd, native, obsConnect } from "../core.js";
import { ATEM, atem, atemConnect, atemDo, DEFAULT_SPEAKERS } from "../atem-client.js";
import { AudioMonitor, monitor } from "../audio-monitor.js";
import { sound, MODES, setMode, speakerOn, stageMsg } from "../sound.js";
import { cssVar } from "../ui-theme.js";
import { screensCard } from "./screens.js";
import { sermonButtons } from "./sermon.js";
import { preachers, photoUrl, openPeopleEditor } from "../people.js";
import { CAM_NAME, PIP_NAME, pickDevice, buildRevivalScenes } from "./broadcast.js";
import { AF, setSplit, recentre, SPLIT_SCENES, refreshOverlays } from "../autoframe.js";

const SHORT = (n) => n.replace(/^Revival · \d+ /, "");

export function productionView(root) {
  root.classList.add("prod");
  const page = h("div", { class: "prod-grid" });
  root.appendChild(page);
  let progTimer = null, statusTimer = null, status = {};

  // ---------- LEFT: running order + live text ----------
  const left = h("div", { class: "prod-col" });
  const svcBox = h("div", { class: "scroll", style: "max-height:none" });
  const liveBox = h("div", { class: "col", style: "gap:6px" });
  const langBox = h("div", { class: "row" });
  const lowerBox = h("div", { class: "col", style: "gap:6px" });
  left.append(
    card("Service order", h("button", { class: "btn sm ghost", onclick: () => window.rwShow("service") }, "Edit"), svcBox, { grow: true }),
    card("On screen now", null, liveBox),
    card("Sermon points (EN + हिंदी)", h("button", { class: "btn sm ghost", onclick: () => window.rwShow("sermon") }, "Edit"), sermonButtons()),
    card("Stream language", null, langBox),
    card("Lower thirds", null, lowerBox));

  // ---------- CENTRE: program + switching ----------
  const centre = h("div", { class: "prod-col" });
  const prog = h("img", { class: "prog-img", alt: "" });
  const progLab = h("div", { class: "prog-lab" });
  const sceneBox = h("div", { class: "scene-row" });
  const atemBox = h("div", { class: "col", style: "gap:8px" });
  const camBox = h("div", { class: "row" });
  const splitBox = h("div", { class: "col", style: "gap:8px" });
  centre.append(
    h("div", { class: "card prog" }, h("div", { class: "prog-screen" }, prog, progLab, h("div", { class: "prog-empty" }, "OBS program"))),
    card("OBS scenes", h("button", { class: "btn sm ghost", title: "Reload all Revival overlays in OBS", onclick: async () => {
      const run = async (all) => { const r = await refreshOverlays({ all }).catch(() => ({ reloaded: 0, ok: 0 })); toast(r.reloaded ? `Reloaded ${r.reloaded} overlay(s)` + (r.ok ? `, ${r.ok} were fine` : "") : `All ${r.ok} overlays are working — nothing reloaded`); };
      modal("Refresh overlays", h("p", { class: "muted" }, "“Fix blank ones” reloads only overlays that didn’t load — safe during a stream. “Reload all” makes every overlay flash briefly."), [{ label: "Cancel" }, { label: "Reload all", cls: S.obsStats?.live ? "live" : "", fn: () => run(true) }, { label: "Fix blank ones", cls: "primary", fn: () => run(false) }]);
    } }, "Refresh overlays"), sceneBox),
    card("ATEM cameras", null, atemBox),
    card("Split scenes", null, splitBox),
    card("Cameras into OBS", null, camBox));

  // ---------- RIGHT: speaker, stream, audio ----------
  const right = h("div", { class: "prod-col" });
  const spkBox = h("div", { class: "col", style: "gap:6px" });
  const streamBox = h("div", { class: "col", style: "gap:8px" });
  const audioBox = h("div", { class: "col", style: "gap:8px" });
  right.append(card("Speaker", h("button", { class: "btn sm ghost", onclick: editSpeakers }, "Edit"), spkBox), card("Stream", null, streamBox), screensCard(), card("Sound", null, audioBox));
  page.append(left, centre, right);
  // fold away cards you only need now and then (remembered); click a card title to open/close it
  const FOLDED = ["Cameras into OBS", "Start & End screens"];
  const foldKey = (t) => "rw-fold-" + t;
  const isFolded = (t) => { try { const v = localStorage.getItem(foldKey(t)); return v ? v === "1" : FOLDED.includes(t); } catch { return FOLDED.includes(t); } };
  function applyFolds() { page.querySelectorAll(".card > .row:first-child .ct").forEach(ct => ct.closest(".card").classList.toggle("collapsed", isFolded(ct.textContent.trim()))); }
  page.addEventListener("click", e => {
    const ct = e.target.closest(".card > .row:first-child .ct"); if (!ct) return;
    const t = ct.textContent.trim(), f = !isFolded(t); try { localStorage.setItem(foldKey(t), f ? "1" : "0"); } catch { }
    ct.closest(".card").classList.toggle("collapsed", f);
  });
  requestAnimationFrame(applyFolds);

  function card(title, extra, body, o = {}) {
    return h("div", { class: "card col" + (o.grow ? " grow" : ""), style: "gap:8px" }, h("div", { class: "row", style: "justify-content:space-between" }, h("div", { class: "ct" }, title), extra), body);
  }

  // ===== service order =====
  function renderService() {
    svcBox.innerHTML = "";
    const items = S.service?.items || [];
    if (!items.length) svcBox.append(h("div", { class: "dim", style: "padding:10px" }, "No items yet — add songs and verses in the Service planner."));
    items.forEach((it, i) => {
      const on = S.live.key === it.id;
      const ic = { song: "♪", bible: "B", message: "M", name: "N", title: "T", text: "¶", sermon: "S" }[it.type] || "•";
      svcBox.append(h("div", { class: "svc-item" + (on ? " onair" : ""), onclick: () => present(it, 0, { fromService: true }) },
        h("div", { class: "ic " + it.type }, ic), h("div", { style: "min-width:0" }, h("div", { class: "tt" }, itemTitle(it)), h("div", { class: "st" }, on ? "ON AIR" : it.type))));
    });
  }
  // ===== live slide =====
  function renderLive() {
    liveBox.innerHTML = "";
    const sl = liveSlide();
    const txt = sl && sl.lines ? streamLines(sl).main || sl.lines : null;
    liveBox.append(h("div", { class: "live-now" }, S.live.override ? h("div", { class: "dim" }, { blank: "Blank screen", logo: "Logo", clear: "Text cleared" }[S.live.override]) : txt ? h("div", {}, h("div", { class: "lk" }, `${S.live.title} · ${sl.label || ""}`), ...txt.map(l => h("div", { class: "ll" }, l))) : h("div", { class: "dim" }, "Nothing live")));
    const nb = (lab, fn, cls = "") => h("button", { class: "btn " + cls, onclick: fn }, lab);
    liveBox.append(h("div", { class: "ctl-grid", style: "grid-template-columns:1fr 2fr 1fr 1fr" },
      nb("◀", prev), nb("Next ▶", next, "primary"), nb("Blank", () => toggleOverride("blank"), S.live.override === "blank" ? "on" : ""), nb("Clear", () => toggleOverride("clear"), S.live.override === "clear" ? "on" : "")),
      h("button", { class: "btn" + (S.lowerFollow ? " on" : ""), style: "justify-content:center", onclick: toggleLowerFollow }, S.lowerFollow ? "● Lyrics / verses showing on stream" : "Show lyrics / verses on stream (T)"));
  }
  // ===== language =====
  function renderLang() {
    const b = S.settings.broadcast; langBox.innerHTML = "";
    const seg = (k, lab) => h("button", { class: "btn" + (b.streamLang === k ? " on" : ""), onclick: () => { b.streamLang = k; saveSettings(); renderLang(); renderLive(); } }, lab);
    langBox.append(h("div", { class: "seg" }, seg("hi", "हिन्दी Hindi"), seg("en", "English")),
      h("label", { class: "row", style: "gap:6px" }, h("input", { type: "checkbox", checked: b.streamSub !== false, onchange: e => { b.streamSub = e.target.checked; saveSettings(); } }), "Second language under it"));
    const ls = S.settings.lowerStyle;
    langBox.append(h("div", { class: "seg", style: "margin-left:auto" }, ...[["pro", "Pro"], ["minimal", "Minimal"]].map(([k, v]) => h("button", { class: "btn sm" + ((ls.look || "pro") === k ? " on" : ""), onclick: () => { ls.look = k; saveSettings(); renderLang(); } }, v))));
  }
  // ===== lower thirds =====
  function renderLower() {
    const b = S.settings.broadcast; lowerBox.innerHTML = "";
    const sp = currentSpeaker();
    const q = b.qotd;
    const btn = (lab, fn, dis) => h("button", { class: "btn", disabled: dis, style: "justify-content:flex-start", onclick: fn }, lab);
    lowerBox.append(
      btn(`Name: ${b.speaker || "—"}`, () => showLowerCard({ type: "name", name: b.speaker, role: sp?.details || sp?.role || b.streamName }), !b.speaker),
      btn(`Title: ${b.sermonTitle || "—"}`, () => showLowerCard({ type: "title", title: b.sermonTitle, kicker: b.speaker || b.streamName, subtitle: [b.meeting, b.place].filter(Boolean).join(" · ") }), !b.sermonTitle),
      btn(q ? `Quote of the Day · ${q.code}` : "Quote of the Day (fetch first)", () => showLowerCard({ type: "message", kicker: "Quote of the Day", lines: [q.short || q.text], ref: [q.code, q.title].filter(Boolean).join(" · ") }), !q),
      h("div", { class: "row" },
        h("input", { class: "input", style: "flex:1", placeholder: "Sermon title", value: b.sermonTitle || "", onchange: e => { b.sermonTitle = e.target.value; saveSettings(); renderLower(); renderStream(); } }),
        h("button", { class: "btn live", onclick: hideLower }, "Hide")));
  }

  // ===== OBS scenes + program =====
  function renderScenes() {
    sceneBox.innerHTML = "";
    if (!S.obs.connected) { sceneBox.append(h("div", { class: "row" }, h("span", { class: "muted" }, "OBS is not connected."), h("button", { class: "btn sm primary", onclick: () => obsConnect() }, "Connect"))); return; }
    const list = S.obsScenes.list;
    const rev = list.filter(n => n.startsWith("Revival · "));
    if (!rev.length) sceneBox.append(h("button", { class: "btn primary", onclick: async () => { try { await buildRevivalScenes(() => { }); toast("Revival scenes ready"); } catch (e) { toast(e.message); } } }, "Build Revival scenes in OBS"));
    for (const n of (rev.length ? rev : list)) sceneBox.append(h("button", { class: "scene-btn" + (n === S.obsScenes.current ? " live" : ""), onclick: () => S.obs.setScene(n).catch(e => toast(e.message)) }, SHORT(n)));
    const others = list.filter(n => !n.startsWith("Revival · "));
    if (rev.length && others.length) {
      const sel = h("select", { class: "input", style: "width:auto", onchange: e => { if (e.target.value) S.obs.setScene(e.target.value).catch(er => toast(er.message)); e.target.value = ""; } }, h("option", { value: "" }, "Other scenes…"), ...others.map(n => h("option", { value: n }, n)));
      sceneBox.append(sel);
    }
  }
  // Program monitor: a small snapshot from OBS. Every snapshot makes OBS copy a frame off the GPU, so keep it
  // small and slow, slower still while live, and stop it when nobody is looking or it is switched off.
  let progBusy = false, progNext = null;
  const monitorOn = () => { try { return localStorage.getItem("rw-monitor") !== "off"; } catch { return true; } };
  function scheduleProgram(ms) { clearTimeout(progNext); progNext = setTimeout(refreshProgram, ms); }
  async function refreshProgram() {
    const live = !!S.obsStats?.live;
    const wait = live ? 3000 : 1500;
    if (!root.classList.contains("on") || document.hidden || !monitorOn() || !S.obs.connected || !S.obsScenes.current) { progLab.textContent = monitorOn() ? progLab.textContent : ""; return scheduleProgram(wait); }
    if (progBusy) return scheduleProgram(wait);
    progBusy = true;
    try { const r = await S.obs.call("GetSourceScreenshot", { sourceName: S.obsScenes.current, imageFormat: "jpg", imageWidth: live ? 384 : 512, imageCompressionQuality: 55 }); prog.src = r.imageData; prog.style.opacity = 1; progLab.textContent = SHORT(S.obsScenes.current); } catch { }
    progBusy = false;
    scheduleProgram(wait);
  }
  const monBtn = h("button", { class: "prog-toggle", title: "The monitor is a small snapshot from OBS (lighter while live). Turn it off to give OBS every bit of power.", onclick: () => { try { localStorage.setItem("rw-monitor", monitorOn() ? "off" : "on"); } catch { } monBtn.textContent = monitorOn() ? "Monitor on" : "Monitor off"; if (!monitorOn()) { prog.style.opacity = 0; } refreshProgram(); } }, monitorOn() ? "Monitor on" : "Monitor off");
  prog.parentElement?.append(monBtn);

  // ===== ATEM =====
  function renderAtem() {
    atemBox.innerHTML = "";
    const st = ATEM.state;
    if (!ATEM.available) { atemBox.append(h("div", { class: "muted" }, "ATEM control works in the Revival Worship Mac app.")); return; }
    if (!st.connected) {
      const ip = h("input", { class: "input", style: "width:150px", value: S.settings.atem.ip || "192.168.10.240" });
      atemBox.append(
        h("div", { class: "muted", style: "font-size:12px" }, st.status === "connecting" ? `Looking for the ATEM at ${st.ip}… Is its Ethernet cable plugged into the same router/switch as this Mac?` : "Connect the ATEM Mini Pro’s Ethernet port to the same network as this Mac (USB carries only picture and sound)."),
        h("div", { class: "row" }, ip, h("button", { class: "btn primary", onclick: () => atemConnect(ip.value.trim()) }, "Connect"),
          h("button", { class: "btn", onclick: async (e) => { e.target.disabled = true; e.target.textContent = "Searching…"; try { const found = await atem("discover"); if (found?.length) { ip.value = found[0].ip || found[0]; toast("Found " + (found[0].name || "ATEM") + " at " + ip.value); atemConnect(ip.value); } else toast("No ATEM found on the network"); } catch (er) { toast(er.message); } e.target.disabled = false; e.target.textContent = "Find"; } }, "Find")));
      return;
    }
    const ins = (st.inputs || []).filter(i => i.id >= 1 && i.id <= 8);
    const bus = (label, cur, fn, cls) => h("div", { class: "bus" }, h("span", { class: "bus-l" }, label), ...ins.map(i => h("button", { class: "cam " + cls + (cur === i.id ? " on" : ""), title: i.long, onclick: () => fn(i.id) }, i.short || String(i.id))));
    atemBox.append(
      bus("PROGRAM", st.program, id => atemDo("program", id), "pgm"),
      bus("PREVIEW", st.preview, id => atemDo("preview", id), "pvw"),
      h("div", { class: "row" },
        h("button", { class: "btn", onclick: () => atemDo("cut") }, "CUT"),
        h("button", { class: "btn primary", onclick: () => atemDo("auto") }, "AUTO"),
        h("button", { class: "btn" + (st.pip ? " on" : ""), onclick: () => atemDo("pip", !st.pip) }, "Picture-in-picture"),
        h("button", { class: "btn" + (st.ftb ? " live" : ""), onclick: () => atemDo("ftb") }, "Fade to black"),
        h("span", { class: "dim", style: "margin-left:auto;font-size:11.5px" }, `${st.model || "ATEM"} · ${st.videoMode || ""} · ${st.ip}`)));
    if (st.videoMode && !/1080p60/.test(st.videoMode)) atemBox.append(h("div", { class: "warnline" }, `ATEM is at ${st.videoMode}. Set the cameras to 1080p60 first, then `, h("a", { href: "#", onclick: e => { e.preventDefault(); modal("Switch ATEM to 1080p60?", h("p", { class: "muted" }, "All HDMI cameras must also be set to 1080p60 or they will show black. The picture blinks for a second while the ATEM changes mode."), [{ label: "Cancel" }, { label: "Switch to 1080p60", cls: "primary", fn: () => atemDo("videoMode", "1080p60") }]); } }, "switch the ATEM to 1080p60"), "."));
  }
  async function renderCams() {
    camBox.innerHTML = "";
    if (!S.obs.connected) { camBox.append(h("span", { class: "muted" }, "Connect OBS first.")); return; }
    let mainDev = "", pipOn = false, pipExists = false;
    try { const r = await S.obs.call("GetInputSettings", { inputName: CAM_NAME }); mainDev = r.inputSettings.device_name || ""; } catch { }
    const sc = S.obsScenes.current;
    try { const { sceneItemId } = await S.obs.call("GetSceneItemId", { sceneName: sc, sourceName: PIP_NAME }); pipExists = true; pipOn = (await S.obs.call("GetSceneItemEnabled", { sceneName: sc, sceneItemId })).sceneItemEnabled; } catch { }
    const isAtem = /blackmagic|atem/i.test(mainDev), isBot = /obsbot/i.test(mainDev);
    const swap = async (re, label) => { const d = await pickDevice(CAM_NAME, re); toast(d ? "Main camera: " + d : label + " is not plugged in"); renderCams(); };
    camBox.append(h("span", { class: "muted", style: "font-size:12px" }, "Main picture:"),
      h("div", { class: "seg" }, h("button", { class: "btn sm" + (isAtem ? " on" : ""), onclick: () => swap(/blackmagic|atem/i, "ATEM") }, "ATEM"), h("button", { class: "btn sm" + (isBot ? " on" : ""), onclick: () => swap(/obsbot/i, "OBSBOT") }, "OBSBOT")),
      h("button", { class: "btn sm" + (pipOn ? " on" : ""), disabled: !pipExists, title: pipExists ? "" : "Only in the Worship and Sermon scenes", onclick: async () => { try { const { sceneItemId } = await S.obs.call("GetSceneItemId", { sceneName: sc, sourceName: PIP_NAME }); await S.obs.call("SetSceneItemEnabled", { sceneName: sc, sceneItemId, sceneItemEnabled: !pipOn }); renderCams(); } catch (e) { toast(e.message); } } }, pipOn ? "● OBSBOT corner" : "OBSBOT corner"));
  }

  // ===== split layout + auto-framing =====
  function renderSplit() {
    const b = S.settings.broadcast; splitBox.innerHTML = "";
    const layout = b.splitLayout || "landscape", side = b.splitSide || "left", zoom = b.frameZoom || "medium";
    const seg = (items, curv, fn) => h("div", { class: "seg" }, ...items.map(([k, v]) => h("button", { class: "btn sm" + (curv === k ? " on" : ""), onclick: () => fn(k) }, v)));
    const stText = layout !== "portrait" ? "" : b.autoFrame === false ? "Auto-framing off — centre of the stage" : ({ off: "Off", starting: "Loading face finder…", searching: "Looking for the speaker…", tracking: `Following the speaker${AF.faces > 1 ? ` (${AF.faces} people seen, keeping the main one)` : ""}`, error: "Auto-framing unavailable" }[AF.status] || "");
    splitBox.append(...[
      h("div", { class: "row" },
        h("button", { class: "btn primary", disabled: !S.obs.connected, onclick: () => setSplit({ splitLayout: layout === "portrait" ? "landscape" : "portrait" }) }, "⇄ Swap layout"),
        seg([["landscape", "Wide video"], ["portrait", "Tall video + big verse"]], layout, k => setSplit({ splitLayout: k })),
        seg([["left", "Video left"], ["right", "Video right"]], side, k => setSplit({ splitSide: k }))),
      layout === "portrait" ? h("div", { class: "row" },
        h("label", { class: "row", style: "gap:6px" }, h("input", { type: "checkbox", checked: b.autoFrame !== false, onchange: e => setSplit({ autoFrame: e.target.checked }) }), "Auto-frame the speaker"),
        seg([["wide", "Wide"], ["medium", "Medium"], ["close", "Close"]], zoom, k => setSplit({ frameZoom: k })),
        h("button", { class: "btn sm ghost", onclick: recentre }, "Re-centre")) : null,
      stText ? h("div", { class: "dim", style: "font-size:11.5px" }, (AF.status === "tracking" ? "● " : "") + stText) : null,
      h("div", { class: "dim", style: "font-size:11px" }, `Applies to ${SPLIT_SCENES.map(SHORT).join(" and ")}.`)].filter(Boolean));
  }

  // ===== speakers (from the church members list) =====
  let preacherList = [];
  function currentSpeaker() { const n = S.settings.broadcast.speaker; return preacherList.find(p => p.name === n || p.short === n); }
  async function renderSpeakers() {
    preacherList = await preachers();
    spkBox.innerHTML = "";
    const b = S.settings.broadcast;
    if (!preacherList.length) spkBox.append(h("div", { class: "dim" }, "No preachers yet — press Edit to add."));
    for (const sp of preacherList) {
      const on = b.speaker === sp.name || b.speaker === sp.short;
      spkBox.append(h("div", { class: "spk" + (on ? " on" : "") },
        sp.photo ? h("img", { src: photoUrl(sp), style: "width:34px;height:34px;border-radius:50%;object-fit:cover;object-position:top;background:#222;flex:0 0 auto" }) : null,
        h("div", { style: "flex:1;min-width:0" }, h("div", { style: "font-weight:650" }, sp.name), h("div", { class: "dim", style: "font-size:11.5px" }, [sp.role, sp.voice ? `voice preset (HPF ${sp.voice.hpf} Hz)` : ""].filter(Boolean).join(" · ") || "—")),
        h("button", { class: "btn sm" + (on ? " on" : ""), onclick: async () => {
          b.speaker = sp.name; b.speakerShort = sp.short || sp.name; await saveSettings();
          showLowerCard({ type: "name", name: sp.name, role: sp.details || sp.role || b.streamName });
          await speakerOn(sp);
          toast(`${sp.name}: name shown` + (sound.backend === "atem" && sp.voice ? " + voice preset on Mic 2" : sound.backend !== "none" ? " + preaching sound" : ""));
          renderSpeakers(); renderLower(); renderStream();
        } }, on ? "On now" : "Speaker on")));
    }
  }
  function editSpeakers() { openPeopleEditor(currentSpeaker()?.id); }

  // ===== stream =====
  async function refreshStatus(now) {
    if (now === true || typeof now === "object") { const { pollNow } = await import("../obs-health.js"); await pollNow(); }
    const o = S.obsStats || {};
    status = { stream: o.stream, tc: o.tc, rec: o.rec, rtc: o.rtc, drop: o.drop || 0, total: o.total || 0, cong: o.congestion || 0 };
    const sb = streamBox.querySelector("#p-stream"), rb = streamBox.querySelector("#p-rec"), hl = streamBox.querySelector("#p-health");
    if (sb) { sb.className = "btn " + (status.stream ? "live" : ""); sb.textContent = status.stream ? `■ LIVE ${status.tc || ""}` : "● Go live"; }
    if (rb) { rb.className = "btn " + (status.rec ? "live" : ""); rb.textContent = status.rec ? `■ REC ${status.rtc || ""}` : "● Record"; }
    if (hl) hl.textContent = status.stream ? `Dropped frames ${status.total ? (100 * status.drop / status.total).toFixed(1) : 0}% · network ${(status.cong * 100).toFixed(0)}% busy` : "Not streaming";
  }
  function renderStream() {
    streamBox.innerHTML = "";
    const b = S.settings.broadcast;
    const title = streamTitle();
    streamBox.append(
      h("div", { class: "row" },
        h("button", { class: "btn", id: "p-stream", disabled: !S.obs.connected, onclick: () => {
          if (status.stream) return modal("Stop the live stream?", h("p", { class: "muted" }, "Viewers will see the stream end."), [{ label: "Cancel" }, { label: "Stop stream", cls: "live", fn: () => S.obs.call("StopStream").then(() => refreshStatus(true)) }]);
          modal("Go live on YouTube?", h("div", { class: "col" }, h("p", { class: "muted" }, "Starts streaming with the stream key set in OBS → Settings → Stream."), h("div", { class: "copyable" }, title)), [{ label: "Cancel" }, { label: "Go live", cls: "live", fn: () => S.obs.call("StartStream").then(() => refreshStatus(true)).catch(e => toast(e.message)) }]);
        } }, "● Go live"),
        h("button", { class: "btn", id: "p-rec", disabled: !S.obs.connected, onclick: () => S.obs.call("ToggleRecord").then(() => refreshStatus(true)).catch(e => toast(e.message)) }, "● Record"),
        h("span", { class: "dim", id: "p-health", style: "font-size:11.5px" }, "")),
      h("div", { class: "ct2" }, "YouTube title"),
      h("div", { class: "row", style: "flex-wrap:nowrap" }, h("div", { class: "copyable", style: "flex:1" }, title), h("button", { class: "btn sm", onclick: async () => { await navigator.clipboard.writeText(title); toast("Title copied — paste it in YouTube Studio"); } }, "Copy")),
      h("div", { class: "row" },
        mini("Meeting", "meeting", "Sunday Service"), mini("Place", "place", "Mumbai"), mini("Night", "night", "1", "60px")),
      h("div", { class: "row" },
        h("button", { class: "btn", onclick: makeThumb }, "Make thumbnail"),
        h("button", { class: "btn", onclick: async (e) => { e.target.disabled = true; try { const q = await fetchQotd(true); if (q) { toast(`Quote of the Day: ${q.code} ${q.title}`); renderLower(); renderStream(); } else toast("Couldn’t reach branham.org"); } catch (er) { toast(er.message); } e.target.disabled = false; } }, b.qotd ? `QOTD ${b.qotd.code} ↻` : "Get Quote of the Day")));
    refreshStatus();
  }
  function mini(label, key, ph, w) {
    const b = S.settings.broadcast;
    return h("label", { class: "f", style: w ? `width:${w}` : "flex:1" }, label, h("input", { class: "input", value: b[key] || "", placeholder: ph, onchange: e => { b[key] = e.target.value.trim(); saveSettings(); renderStream(); } }));
  }
  async function makeThumb() {
    const b = S.settings.broadcast;
    const c = document.createElement("canvas"); c.width = 1280; c.height = 720; const g = c.getContext("2d");
    await document.fonts.load("700 80px Oswald"); await document.fonts.load("italic 500 40px Cormorant");
    let img = null;
    if (S.obs.connected) { try { const r = await S.obs.call("GetSourceScreenshot", { sourceName: CAM_NAME, imageFormat: "jpg", imageWidth: 1280 }); img = await loadImg(r.imageData); } catch { } }
    g.fillStyle = "#0a1430"; g.fillRect(0, 0, 1280, 720);
    if (img) { const sc = Math.max(1000 / img.width, 720 / img.height), w = img.width * sc, hh = img.height * sc; g.drawImage(img, 1280 - w + (w - 1000) / 2, (720 - hh) / 2, w, hh); }
    const gr = g.createLinearGradient(0, 0, 1280, 0); gr.addColorStop(0, "rgba(10,20,48,1)"); gr.addColorStop(.42, "rgba(10,20,48,.96)"); gr.addColorStop(.7, "rgba(10,20,48,.35)"); gr.addColorStop(1, "rgba(10,20,48,0)");
    g.fillStyle = gr; g.fillRect(0, 0, 1280, 720);
    g.fillStyle = "#d4a24c"; g.fillRect(70, 96, 90, 8);
    g.font = "600 30px Oswald"; g.fillStyle = "#d4a24c"; g.fillText(dateCode().toUpperCase() + "   ·   " + (b.streamName || "REVIVAL CHURCH MUMBAI").toUpperCase(), 70, 160);
    const t = (b.sermonTitle || b.meeting || b.serviceTitle || "Sunday Service").toUpperCase();
    let fs = 120; g.font = `700 ${fs}px Oswald`;
    const wrap = (txt, max) => { const w = txt.split(/\s+/), out = []; let l = ""; for (const x of w) { const tt = l ? l + " " + x : x; if (g.measureText(tt).width > max && l) { out.push(l); l = x; } else l = tt; } if (l) out.push(l); return out; };
    let L = wrap(t, 700); while ((L.length > 3 || L.some(x => g.measureText(x).width > 700)) && fs > 60) { fs -= 6; g.font = `700 ${fs}px Oswald`; L = wrap(t, 700); }
    g.fillStyle = "#ffffff"; L.forEach((l, i) => g.fillText(l, 66, 190 + fs * 0.95 * (i + 1)));
    const y = 190 + fs * 0.95 * L.length + 70;
    g.font = "italic 500 48px Cormorant"; g.fillStyle = "#f1d391"; if (b.speaker) g.fillText(b.speaker, 70, y);
    g.fillStyle = "#d4a24c"; g.fillRect(0, 660, 1280, 60); g.fillStyle = "#0a1430"; g.font = "600 28px Oswald";
    g.fillText(([b.meeting, [b.place, b.night].filter(Boolean).join(" - ")].filter(Boolean).join("  ·  ") || "LIVE").toUpperCase(), 70, 700);
    try { const logo = await loadImg("assets/img/logo.png"); g.save(); g.beginPath(); g.arc(1180, 100, 58, 0, Math.PI * 2); g.fillStyle = "#fff"; g.fill(); g.clip(); g.drawImage(logo, 1126, 46, 108, 108); g.restore(); } catch { }
    const url = c.toDataURL("image/jpeg", 0.92);
    const a = h("a", { href: url, download: `${dateCode().replace(" ", "")} thumbnail.jpg` });
    modal("YouTube thumbnail", h("div", { class: "col" }, h("img", { src: url, style: "width:100%;border-radius:8px" }), h("div", { class: "muted", style: "font-size:12px" }, img ? "Background is a still from the church camera right now." : "Connect OBS to use a camera still as the background.")), [{ label: "Close" }, { label: "Save image…", cls: "primary", fn: () => { a.click(); } }]);
  }
  const loadImg = (src) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });

  // ===== audio monitor =====
  const meter = h("canvas", { class: "meter", width: 360, height: 92 });
  const sugBox = h("div", { class: "col", style: "gap:6px" });
  const lufsLab = h("div", { class: "lufs" });
  let devSel = null, listenOn = false;
  async function renderAudio() {
    audioBox.innerHTML = "";
    const devs = await AudioMonitor.devices().catch(() => []);
    const saved = S.settings.audio.deviceId;
    const cur = devs.find(d => d.id === saved) ? saved : AudioMonitor.pickDefault(devs);
    devSel = h("select", { class: "input", style: "flex:1", onchange: e => { S.settings.audio.deviceId = e.target.value; saveSettings(); if (monitor.running) startMon(); } }, ...devs.map(d => h("option", { value: d.id, selected: d.id === cur }, d.label)));
    audioBox.append(soundBox,
      h("div", { class: "row", style: "flex-wrap:nowrap" }, devSel,
        h("button", { class: "btn" + (monitor.running ? " on" : ""), onclick: () => monitor.running ? (monitor.stop(), renderAudio()) : startMon() }, monitor.running ? "Stop" : "Start"),
        h("button", { class: "btn" + (listenOn ? " on" : ""), title: "Hear it in this Mac’s headphones", disabled: !monitor.running, onclick: () => { listenOn = !listenOn; monitor.listen(listenOn); renderAudio(); } }, "🎧")),
      lufsLab, meter, sugBox,
      h("div", { class: "dim", style: "font-size:11px" }, "Listens to the ATEM’s USB audio — the same sound that goes to YouTube. Aim: voice around −16 LUFS, peaks below −1 dB. Use headphones for 🎧."));
    if (!monitor.running) { lufsLab.textContent = "Press Start to listen"; drawMeter(null); }
    renderSound();
  }
  // ----- automatic sound helper (modes, auto level, alerts, stage messages) -----
  const soundBox = h("div", { class: "col", style: "gap:8px" });
  function renderSound() {
    const a = S.settings.audio || {};
    soundBox.innerHTML = "";
    const where = sound.backend === "atem" ? "ATEM Mic 2 (Fairlight)" : sound.backend === "obs" ? `OBS filters on “${sound.obsInput}”` : "advice only — connect the ATEM by Ethernet, or OBS";
    soundBox.append(
      h("div", { class: "row", style: "flex-wrap:nowrap;gap:6px" },
        h("div", { class: "seg", style: "flex:1" }, ...Object.entries(MODES).map(([k, m]) => h("button", { class: "btn sm" + (a.mode === k ? " on" : ""), title: m.hint, onclick: () => setMode(k) }, `${m.icon} ${m.label}`))),
        h("button", { class: "btn sm" + (a.auto ? " on" : ""), title: "Automatic level: keeps YouTube loudness steady (limited to −10 / +6 dB)", onclick: () => { a.auto = !a.auto; saveSettings(); if (a.auto) setMode(a.mode, "auto on"); renderSound(); } }, a.auto ? "Auto ✓" : "Auto")),
      h("div", { class: "dim", style: "font-size:11.5px" }, `${sound.status || ""} · ${where}`),
      ...(sound.alerts || []).map(x => h("div", { class: "sug " + x.level }, h("div", { style: "flex:1;min-width:0" }, h("div", { class: "st1" }, x.title), h("div", { class: "st2" }, x.detail)),
        x.action ? h("button", { class: "btn sm", onclick: async (e) => { e.target.disabled = true; try { await x.action.fn(); toast(x.action.label + " ✓"); } catch (er) { toast(er.message); } } }, x.action.label) : null,
        x.action2 ? h("button", { class: "btn sm ghost", onclick: () => x.action2.fn() }, x.action2.label) : null)),
      h("div", { class: "row", style: "gap:6px;flex-wrap:wrap" },
        h("span", { class: "dim", style: "font-size:11.5px" }, "Stage:"),
        h("button", { class: "btn sm", onclick: () => stageMsg("🎵 Music a little softer please") }, "🎵 Music softer"),
        h("button", { class: "btn sm", onclick: () => stageMsg("🎤 Closer to the mic please") }, "🎤 Closer to mic"),
        h("button", { class: "btn sm", onclick: () => stageMsg("🔊 Music can come up a little") }, "🔊 Music up"),
        S.stageMessage ? h("button", { class: "btn sm ghost", onclick: () => stageMsg("") }, "Clear") : null),
      h("div", { class: "row", style: "gap:12px;flex-wrap:wrap;font-size:11.5px" },
        h("label", { class: "row", style: "gap:4px" }, h("input", { type: "checkbox", checked: a.sceneModes !== false, onchange: e => { a.sceneModes = e.target.checked; saveSettings(); } }), "Change with the scene"),
        h("label", { class: "row", style: "gap:4px" }, h("input", { type: "checkbox", checked: !!a.autoTone, onchange: e => { a.autoTone = e.target.checked; saveSettings(); } }), "Lift buried singers automatically")),
      sound.log.length ? h("div", { class: "dim", style: "font-size:11px;line-height:1.5" }, sound.log.slice(0, 3).join("  ·  ")) : null);
  }
  let sndKey = "";
  onChange(w => { if (w !== "sound" || !root.classList.contains("on")) return; const k = JSON.stringify([sound.status, sound.backend, sound.alerts.map(x => x.title), sound.log[0], S.settings.audio?.mode, S.settings.audio?.auto, S.stageMessage]); if (k !== sndKey) { sndKey = k; renderSound(); } });
  async function startMon() {
    try { await monitor.start(devSel?.value || S.settings.audio.deviceId); renderAudio(); }
    catch (e) { toast("Microphone access: " + e.message); }
  }
  monitor.addEventListener("level", e => { if (root.classList.contains("on")) { drawMeter(e.detail); } });
  monitor.addEventListener("suggest", e => { if (root.classList.contains("on")) renderSuggest(e.detail); });
  function drawMeter(st) {
    const g = meter.getContext("2d"), W = meter.width, H = meter.height;
    g.clearRect(0, 0, W, H);
    const x = (db) => Math.max(0, Math.min(1, (db + 60) / 60)) * (W - 40);
    const track = cssVar("--raised2", "#1b202a"), labC = cssVar("--muted", "#8d96a6"), dimC = cssVar("--dim", "#5d6574");
    const bar = (y, val, label, color) => {
      g.fillStyle = track; g.fillRect(36, y, W - 40, 12);
      if (val != null && isFinite(val)) { g.fillStyle = color(val); g.fillRect(36, y, x(val), 12); }
      g.fillStyle = labC; g.font = "10px -apple-system"; g.fillText(label, 0, y + 10);
    };
    // target zone
    g.fillStyle = "rgba(48,164,108,.18)"; g.fillRect(36 + x(-18), 0, x(-14) - x(-18), 46);
    const lc = v => v > -10 ? "#e5484d" : v > -14 ? "#f0a020" : v > -20 ? "#30a46c" : "#3b82f6";
    bar(4, st?.momentary, "Now", lc);
    bar(20, st?.short, "3 sec", lc);
    bar(36, st?.peak, "Peak", v => v > -1 ? "#e5484d" : v > -6 ? "#f0a020" : "#30a46c");
    if (st?.bands) {
      const keys = ["low", "mud", "body", "mid", "pres", "harsh", "air"], names = ["Bass", "Mud", "Body", "Voice", "Clarity", "Sharp", "Air"];
      const ref = st.bands.mid;
      keys.forEach((k, i) => { const v = st.bands[k] - ref; const hh = Math.max(2, Math.min(30, 18 + v)); const bx = 36 + i * ((W - 40) / 7);
        g.fillStyle = document.documentElement.dataset.ui === "light" ? "#9fb3d6" : "#3b4a66"; g.fillRect(bx + 4, 86 - hh, (W - 40) / 7 - 8, hh); g.fillStyle = dimC; g.font = "9px -apple-system"; g.fillText(names[i], bx + 4, 92 + 0); });
      g.fillStyle = labC; g.font = "10px -apple-system"; g.fillText("Tone", 0, 78);
    }
    const atemL = ATEM.levels?.["1302"]?.l;
    lufsLab.innerHTML = "";
    if (st) lufsLab.append(h("b", {}, isFinite(st.short) ? st.short.toFixed(1) : "—"), " LUFS ", h("span", { class: "dim" }, `· peak ${isFinite(st.peak) ? st.peak.toFixed(1) : "—"} dB` + (atemL != null && ATEM.state.connected ? ` · ATEM Mic 2 ${atemL.toFixed(0)} dB` : "")));
  }
  function renderSuggest({ list, integrated }) {
    sugBox.innerHTML = "";
    for (const s of list) {
      const act = s.action && ATEM.state.connected ? h("button", { class: "btn sm", onclick: async (e) => { e.target.disabled = true; try { await atem("nudge", s.action.nudge); toast("Applied: " + s.action.label); } catch (er) { toast(er.message); } } }, s.action.label) : null;
      sugBox.append(h("div", { class: "sug " + s.level }, h("div", { style: "flex:1;min-width:0" }, h("div", { class: "st1" }, s.title), h("div", { class: "st2" }, s.detail + (s.action && !ATEM.state.connected ? " (Connect the ATEM by Ethernet for one-click fixes, or change it in ATEM Software Control → Audio → Mic 2.)" : ""))), act));
    }
    if (isFinite(integrated)) sugBox.append(h("div", { class: "dim", style: "font-size:11px" }, `Whole service so far: ${integrated.toFixed(1)} LUFS`));
  }

  // ---------- wiring ----------
  function renderAll() { renderService(); renderLive(); renderLang(); renderLower(); renderScenes(); renderAtem(); renderSplit(); renderCams(); renderSpeakers(); renderStream(); }
  // batch redraws: many changes in a row → one redraw per frame; camera info only when the scene changes
  const pending = new Set(); let raf = 0, lastScene = null;
  onChange(w => {
    if (!root.classList.contains("on")) return;
    pending.add(typeof w === "string" ? w : "other");
    if (!raf) raf = requestAnimationFrame(flush);
  });
  function flush() {
    raf = 0; const p = new Set(pending); pending.clear();
    if (p.has("live") || p.has("lower")) { renderLive(); renderService(); }
    else if (p.has("service")) renderService();
    if (p.has("obs")) {
      renderScenes(); renderStream();
      if (S.obsScenes.current !== lastScene) { lastScene = S.obsScenes.current; renderCams(); clearTimeout(progNext); refreshProgram(); }
    }
    if (p.has("obsstats")) refreshStatus();
    if (p.has("atem")) renderAtem();
    if (p.has("people")) renderSpeakers();
    if (p.has("autoframe")) renderSplit();
  }
  return {
    onShow() {
      renderAll(); renderAudio();
      lastScene = S.obsScenes.current; clearTimeout(progNext); refreshProgram(); refreshStatus();
      fetchQotd().then(q => { if (q) renderLower(); }).catch(() => { });
    },
  };
}
