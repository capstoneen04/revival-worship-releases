import { S, h, present, showLowerCard, addToService, toast, saveSettings } from "../core.js";
import { loadBible, parseRef, refLabel, getVerses, searchBible, setHindiNames, BOOKS_EN } from "../bible.js";

export function bibleView(root) {
  let kjv, hin, book = 43, chapter = 3, sel = new Set(), version = S.settings.bibleVersion || "both";
  const refIn = h("input", { class: "input", type: "search", placeholder: "Go to: jn 3 16 · rev 10 1-7 · यूहन्ना 3:16 — or search words", style: "flex:1;min-width:240px;height:34px;font-size:14px" });
  const verSel = h("select", { class: "input", style: "height:34px" }, h("option", { value: "both" }, "KJV + Hindi"), h("option", { value: "kjv" }, "KJV only"), h("option", { value: "hindi" }, "Hindi only"));
  verSel.value = version;
  const booksEl = h("div", { class: "book-grid" });
  const chEl = h("div", { class: "ch-grid" });
  const versesEl = h("div", { class: "verses" });
  const head = h("div", { style: "font-weight:650;font-size:16px;font-family:var(--lyric);flex:1" });
  const actions = h("div", { class: "row" });
  root.append(
    h("div", { class: "panel books" }, h("div", { class: "panel-h" }, h("h2", {}, "Books")), h("div", { class: "scroll" }, booksEl)),
    h("div", { style: "flex:1;display:flex;flex-direction:column;min-width:0" },
      h("div", { class: "panel-h", style: "background:var(--panel)" }, refIn, verSel),
      h("div", { class: "panel-h", style: "background:var(--panel)" }, head, actions),
      h("div", { class: "scroll" }, chEl, versesEl)));

  verSel.onchange = () => { version = verSel.value; S.settings.bibleVersion = version; saveSettings(); renderVerses(); };
  refIn.onkeydown = e => {
    if (e.key !== "Enter") return;
    const r = parseRef(refIn.value);
    if (r && kjv.text[r.book - 1]?.[r.chapter - 1]) {
      book = r.book; chapter = r.chapter; sel = new Set();
      if (r.verse) for (let v = r.verse; v <= (r.to || r.verse); v++) sel.add(v);
      renderAll();
      if (r.verse) versesEl.querySelector(`[data-v="${r.verse}"]`)?.scrollIntoView({ block: "center" });
      if (e.shiftKey && sel.size) goLive();
    } else doSearch(refIn.value);
  };

  function doSearch(q) {
    const hits = /[ऀ-ॿ]/.test(q) ? searchBible(hin, q, 150) : searchBible(kjv, q, 150);
    head.textContent = `${hits.length} verses containing “${q}”`; actions.innerHTML = ""; chEl.innerHTML = "";
    versesEl.innerHTML = "";
    hits.forEach(x => versesEl.appendChild(h("div", { class: "verse single", onclick: () => { book = x.book; chapter = x.chapter; sel = new Set([x.verse]); renderAll(); versesEl.querySelector(`[data-v="${x.verse}"]`)?.scrollIntoView({ block: "center" }); } },
      h("div", { class: "vn" }, ""), h("div", {}, h("div", { class: "dim", style: "font:600 11.5px var(--font)" }, refLabel(kjv, x) + " · " + refLabel(hin, x)), x.text))));
  }

  function currentRef() {
    const vs = [...sel].sort((a, b) => a - b);
    if (!vs.length) return { book, chapter, verse: null, to: null };
    return { book, chapter, verse: vs[0], to: vs[vs.length - 1] };
  }
  function item() { const r = currentRef(); return { type: "bible", ref: r, version, label: refLabel(kjv, r) }; }
  function goLive() { if (!sel.size) { toast("Select one or more verses first"); return; } present(item()); toast("Live: " + refLabel(kjv, currentRef())); }
  function lowerThird() {
    if (!sel.size) { toast("Select a verse first"); return; }
    const r = currentRef(); const en = getVerses(kjv, r).map(v => v.text).join(" "); const hi = getVerses(hin, r).map(v => v.text).join(" ");
    const ref = version === "hindi" ? refLabel(hin, r) : version === "both" ? `${refLabel(kjv, r)} · ${refLabel(hin, r)}` : refLabel(kjv, r);
    showLowerCard({ type: "bible", lines: [version === "hindi" ? hi : en], lines2: version === "both" ? [hi] : null, ref });
    toast("Verse sent to OBS lower third");
  }

  function renderBooks() {
    booksEl.innerHTML = "";
    BOOKS_EN.forEach((b, i) => booksEl.appendChild(h("button", { class: (i + 1 === book ? "on " : "") + (i >= 39 ? "nt" : ""), title: `${b} · ${hin.books[i]}`, onclick: () => { book = i + 1; chapter = 1; sel = new Set(); renderAll(); } }, short(b))));
  }
  function renderChapters() {
    chEl.innerHTML = "";
    const n = kjv.text[book - 1].length;
    for (let c = 1; c <= n; c++) chEl.appendChild(h("button", { class: c === chapter ? "on" : "", onclick: () => { chapter = c; sel = new Set(); renderAll(); } }, String(c)));
  }
  function renderVerses() {
    head.textContent = `${kjv.books[book - 1]} ${chapter} · ${hin.books[book - 1]} ${chapter}`;
    actions.innerHTML = "";
    actions.append(
      h("span", { class: "dim" }, sel.size ? `${sel.size} selected` : "Click verses (Shift-click for a range)"),
      h("button", { class: "btn live", onclick: goLive }, "▶ Project"),
      h("button", { class: "btn", onclick: lowerThird }, "Lower third"),
      h("button", { class: "btn", onclick: () => { if (!sel.size) return toast("Select verses first"); addToService(item()); } }, "+ Service"));
    versesEl.innerHTML = "";
    const en = kjv.text[book - 1][chapter - 1], hi = hin.text[book - 1][chapter - 1] || [];
    let last = null;
    en.forEach((t, i) => {
      const v = i + 1;
      const kids = [h("div", { class: "vn" }, String(v))];
      if (version !== "hindi") kids.push(h("div", {}, t));
      if (version !== "kjv") kids.push(h("div", {}, hi[i] || ""));
      versesEl.appendChild(h("div", { class: "verse" + (version === "both" ? "" : " single") + (sel.has(v) ? " sel" : ""), "data-v": v, onclick: (e) => {
        if (e.shiftKey && last) { const [a, b] = [Math.min(last, v), Math.max(last, v)]; for (let x = a; x <= b; x++) sel.add(x); }
        else if (e.metaKey || e.ctrlKey) { sel.has(v) ? sel.delete(v) : sel.add(v); }
        else { sel = new Set([v]); }
        last = v; renderVerses();
      }, ondblclick: () => { sel = new Set([v]); goLive(); } }, ...kids));
    });
  }
  function renderAll() { renderBooks(); renderChapters(); renderVerses(); }
  const short = b => b.replace("Song of Solomon", "Song").replace("Thessalonians", "Thess").replace("Corinthians", "Cor").replace("Chronicles", "Chron").replace("Philippians", "Phil").replace("Deuteronomy", "Deut").replace("Ecclesiastes", "Eccl").replace("Lamentations", "Lam").replace("Revelation", "Rev");
  (async () => {
    versesEl.textContent = "Loading Bibles…";
    [kjv, hin] = await Promise.all([loadBible("kjv"), loadBible("hindi")]);
    setHindiNames(hin.books);
    renderAll();
  })();
  return { onShow() { refIn.focus(); } };
}
