// Runs inside The Table window: adds a "Send to Revival" button that forwards the selected text.
const { ipcRenderer } = require("electron");

const CODE_RE = /\b(\d{2}-\d{4}[A-Z]?)\b/;

function guessSermon() {
  // Try common places the page shows the sermon title / date code; fall back to the window title.
  const cands = [];
  for (const sel of ["h1", "h2", "[class*=title]", "[class*=Title]", "[class*=sermon]", "[class*=Sermon]"]) {
    document.querySelectorAll(sel).forEach(el => { const t = (el.innerText || "").trim(); if (t && t.length < 140) cands.push(t); });
  }
  cands.push(document.title || "");
  const withCode = cands.find(t => CODE_RE.test(t));
  const title = (withCode || cands[0] || "").replace(/\s+/g, " ").trim();
  const code = (title.match(CODE_RE) || [])[1] || "";
  return { title: title.replace(CODE_RE, "").replace(/^[\s\-–|·]+|[\s\-–|·]+$/g, ""), code };
}

function paragraphNumber(sel) {
  try {
    let n = sel.anchorNode; for (let i = 0; i < 6 && n; i++) { const t = (n.innerText || n.textContent || "").trim(); const m = t.match(/^\[?(\d{1,4})\]?\s/); if (m) return m[1]; n = n.parentElement; }
  } catch { }
  return "";
}

window.addEventListener("DOMContentLoaded", () => {
  const btn = document.createElement("button");
  btn.textContent = "Send to Revival ➜";
  btn.style.cssText = "position:fixed;right:22px;bottom:22px;z-index:2147483647;background:#1f6fe0;color:#fff;border:0;border-radius:24px;padding:12px 20px;font:600 15px -apple-system,system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.35);cursor:pointer;opacity:.55;transition:opacity .15s";
  btn.onmouseenter = () => (btn.style.opacity = "1"); btn.onmouseleave = () => (btn.style.opacity = hasSel() ? "1" : ".55");
  const hasSel = () => (window.getSelection()?.toString() || "").trim().length > 0;
  document.addEventListener("selectionchange", () => { btn.style.opacity = hasSel() ? "1" : ".55"; });
  btn.onclick = () => {
    const s = window.getSelection();
    const text = (s?.toString() || "").trim();
    if (!text) { btn.textContent = "Select a paragraph first"; setTimeout(() => (btn.textContent = "Send to Revival ➜"), 1600); return; }
    const meta = guessSermon();
    ipcRenderer.send("quote", { text, title: meta.title, code: meta.code, para: paragraphNumber(s) });
    btn.textContent = "Sent ✓"; setTimeout(() => (btn.textContent = "Send to Revival ➜"), 1400);
  };
  document.body.appendChild(btn);
});
