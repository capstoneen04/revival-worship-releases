// Updates from GitHub Releases (public repo with installers + update files only).
// Each release carries latest.json:
//   { version, date, notes, minShell, url,
//     update:  { name, size, sha256 },              ← small zip of electron/ server/ web/ (+ seed additions)
//     library: { name, size, sha256, version },     ← locked songs + Hindi Bible (only when it changed)
//     installers: { mac: { name }, win: { name } } }
// Flow: check → download → verify sha256 → unpack into userData/updates/<version>/app → used on the next start.
// Never restarts by itself (the operator chooses "Restart now", and the app refuses while streaming).
const { app, net, shell } = require("electron");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFile } = require("child_process");

const DEFAULT_REPO = "capstoneen04/revival-worship-releases";
// Files are published as plain files in the public repo: latest.json + files/<name>
const BASE = (repo) => process.env.RW_UPDATE_BASE || `https://raw.githubusercontent.com/${repo}/main`;
const cmp = (a, b) => { const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };

function createUpdater({ RW, library, libraryPacks, onStatus, repo = DEFAULT_REPO }) {
  const dir = RW.updatesDir;
  const cfgFile = path.join(dir, "settings.json");
  const cfg = () => Object.assign({ auto: true, repo }, readJson(cfgFile, {}));
  let status = { state: "idle", running: RW.version, installed: RW.bundledVersion, fromUpdate: RW.fromUpdate, shell: RW.SHELL };
  let timer = null, busy = false;
  const set = (s) => { status = { ...status, ...s, checkedAt: s.checkedAt || status.checkedAt }; onStatus && onStatus(status); };

  async function getJson(url) {
    const r = await net.fetch(url, { headers: { "Accept": "application/vnd.github+json", "User-Agent": "RevivalWorship-Updater" }, cache: "no-store" });
    if (r.status === 404) { const e = new Error("No updates published yet"); e.code = 404; throw e; }
    if (!r.ok) throw new Error(`GitHub answered ${r.status}`);
    return r.json();
  }
  async function download(url, dest, size, sha, label) {
    const r = await net.fetch(url, { headers: { "User-Agent": "RevivalWorship-Updater", "Accept": "application/octet-stream" } });
    if (!r.ok) throw new Error(`Download failed (${r.status})`);
    const tmp = dest + ".part", out = fs.createWriteStream(tmp), hash = crypto.createHash("sha256");
    const reader = r.body.getReader(); let got = 0, lastPct = -1;
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      const b = Buffer.from(value); hash.update(b); got += b.length;
      if (!out.write(b)) await new Promise(res => out.once("drain", res));
      const pct = size ? Math.floor(got / size * 100) : 0; if (pct !== lastPct) { lastPct = pct; set({ state: "downloading", progress: pct, what: label }); }
    }
    await new Promise((res, rej) => out.end(err => err ? rej(err) : res()));
    const digest = hash.digest("hex");
    if (sha && digest !== sha) { fs.rmSync(tmp, { force: true }); throw new Error("Downloaded file is damaged (checksum differs) — try again"); }
    fs.renameSync(tmp, dest);
  }
  function unzip(zip, destDir) {
    fs.mkdirSync(destDir, { recursive: true });
    const [cmd, args] = process.platform === "darwin" ? ["/usr/bin/ditto", ["-x", "-k", zip, destDir]]
      : process.platform === "win32" ? [path.join(process.env.SystemRoot || "C:\\Windows", "System32", "tar.exe"), ["-xf", zip, "-C", destDir]]
      : ["unzip", ["-q", "-o", zip, "-d", destDir]];
    return new Promise((res, rej) => execFile(cmd, args, { maxBuffer: 1 << 24 }, (e, so, se) => e ? rej(new Error("Could not unpack the update: " + (se || e.message))) : res()));
  }
  function cleanup(keep) {
    // keep the running version, the newest download and the one before it (for "use previous version")
    try {
      const vers = fs.readdirSync(dir).filter(v => /^\d+\.\d+\.\d+$/.test(v)).sort(cmp).reverse();
      for (const v of vers.slice(3)) if (!keep.includes(v)) fs.rmSync(path.join(dir, v), { recursive: true, force: true });
      for (const f of fs.readdirSync(dir)) if (/\.(zip|part)$/.test(f)) fs.rmSync(path.join(dir, f), { force: true });
      const packs = fs.readdirSync(dir).filter(f => /^library-.*\.rwpack$/.test(f)).sort((a, b) => cmp(a.slice(8, -7), b.slice(8, -7))).reverse();
      for (const f of packs.slice(1)) fs.rmSync(path.join(dir, f), { force: true });
    } catch { }
  }

  const up = {
    status: () => status,
    config: cfg,
    setConfig(c) { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(cfgFile, JSON.stringify({ ...cfg(), ...c }, null, 1)); up.schedule(); return cfg(); },
    async check({ download: doDownload = cfg().auto } = {}) {
      if (busy) return status; busy = true;
      try {
        set({ state: "checking", error: null });
        const base0 = BASE(cfg().repo);
        const man = await getJson(`${base0}/latest.json?t=${Date.now()}`);
        const asset = (n) => n ? { name: n, browser_download_url: `${base0}/files/${encodeURIComponent(n)}` } : null;
        const rel = { html_url: `https://github.com/${cfg().repo}`, body: man.notes, published_at: man.date };
        const base = { latest: man.version, notes: man.notes || rel.body || "", url: rel.html_url, checkedAt: new Date().toISOString(), date: man.date || rel.published_at };
        const ready = fs.existsSync(path.join(dir, man.version, "update.json"));
        // library (songs / Hindi Bible) can change without a new app version
        let libNote = null;
        if (man.library && asset(man.library.name)) {
          const libStatus = library.status(libraryPacks());
          if (!libStatus.version || cmp(man.library.version, libStatus.version) > 0) {
            const dest = path.join(dir, `library-${man.library.version}.rwpack`);
            if (!fs.existsSync(dest) && doDownload) { fs.mkdirSync(dir, { recursive: true }); await download(asset(man.library.name).browser_download_url, dest, man.library.size, man.library.sha256, "song library"); }
            const r = library.autoUpdate(libraryPacks());
            if (r && !r.error) libNote = `Song library updated to ${r.version}`;
          }
        }
        if (cmp(man.version, RW.version) <= 0) { set({ state: "current", ...base, libNote }); return status; }
        if ((man.minShell || 0) > RW.SHELL) {
          const inst = process.platform === "win32" ? man.installers?.win?.name : man.installers?.mac?.name;
          set({ state: "installer", ...base, installer: `https://github.com/${cfg().repo}/releases/latest`, libNote }); return status;
        }
        if (ready && (RW.readState().bad || []).includes(man.version)) { set({ state: "failed", ...base, libNote }); return status; }
        if (ready) { set({ state: "ready", ...base, libNote }); return status; }
        if (!doDownload) { set({ state: "available", ...base, size: man.update?.size, libNote }); return status; }
        const u = man.update, ua = u && asset(u.name); if (!ua) throw new Error("Update file missing in the release");
        fs.mkdirSync(dir, { recursive: true });
        const zip = path.join(dir, `${man.version}.zip`);
        await download(ua.browser_download_url, zip, u.size, u.sha256, "update");
        set({ state: "installing" });
        const target = path.join(dir, man.version);
        fs.rmSync(target, { recursive: true, force: true });
        await unzip(zip, target);
        if (!fs.existsSync(path.join(target, "app", "electron", "main.js"))) throw new Error("The update is incomplete");
        fs.writeFileSync(path.join(target, "update.json"), JSON.stringify({ version: man.version, minShell: man.minShell || 0, sha256: u.sha256, downloaded: new Date().toISOString() }));
        const st = RW.readState(); st.bad = (st.bad || []).filter(v => v !== man.version); if (st.hold === man.version) st.hold = null; st.pinBundled = false; RW.writeState(st);
        cleanup([RW.version, man.version]);
        set({ state: "ready", ...base, libNote, progress: 100 });
      } catch (e) {
        set({ state: e.code === 404 ? "none" : "error", error: e.message, checkedAt: new Date().toISOString() });
      } finally { busy = false; }
      return status;
    },
    restart() { app.relaunch(); app.exit(0); },
    // go back: don't use the running update any more (falls back to the previous download or the installed copy)
    usePrevious() {
      const st = RW.readState();
      if (RW.fromUpdate) { st.bad = [...new Set([...(st.bad || []), RW.version])]; }
      else st.pinBundled = true;
      RW.writeState(st); app.relaunch(); app.exit(0);
    },
    useLatest() { const st = RW.readState(); st.bad = []; st.pinBundled = false; st.hold = null; RW.writeState(st); app.relaunch(); app.exit(0); },
    openRelease() { if (status.url) shell.openExternal(status.url); },
    schedule() {
      clearInterval(timer);
      if (!cfg().auto) return;
      timer = setInterval(() => up.check().catch(() => { }), 2 * 3600 * 1000);   // every 2 h (team songs reach other computers the same day)
    },
  };
  setTimeout(() => { up.schedule(); if (cfg().auto) up.check().catch(() => { }); }, +process.env.RW_UPDATE_DELAY || 60 * 1000);
  return up;
}

module.exports = { createUpdater, DEFAULT_REPO };
