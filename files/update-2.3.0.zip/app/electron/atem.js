// ATEM Mini Pro control (needs the ATEM on the same network by Ethernet — USB carries only video/audio)
const { execFile } = require("child_process");
let Atem = null, Commands = null, Enums = null;
try { ({ Atem, Commands, Enums } = require("atem-connection")); } catch (e) { console.error("atem-connection missing", e); }

const DEFAULT_IP = "192.168.10.240";
let atem = null, ip = null, send = () => { }, lastSummary = "", levelTimer = null;
const levels = {};   // "input:source" -> { l, r }  (dBFS)

function db(raw) { return raw == null ? null : raw / 100; }

function summary() {
  if (!atem || atem.status !== 2 || !atem.state) return { connected: false, ip, status: atem ? "connecting" : "off" };
  const s = atem.state, me = s.video.mixEffects[0] || {};
  const inputs = Object.values(s.inputs || {}).filter(i => i && i.internalPortType === 0).map(i => ({ id: i.inputId, short: i.shortName, long: i.longName }));
  const usk = me.upstreamKeyers?.[0];
  const fl = s.fairlight || {};
  const audio = {};
  for (const [id, inp] of Object.entries(fl.inputs || {})) {
    if (!inp) continue;
    const [srcId, src] = Object.entries(inp.sources || {})[0] || [];
    if (!src) continue;
    const p = src.properties || {}, eq = src.equalizer, dyn = src.dynamics || {};
    audio[id] = {
      source: srcId, gain: db(p.gain), fader: db(p.faderGain), mix: p.mixOption,
      eq: eq ? { enabled: eq.enabled, bands: (eq.bands || []).map(b => b && { on: b.bandEnabled, shape: b.shape, f: b.frequency, g: db(b.gain), q: db(b.qFactor) }) } : null,
      comp: dyn.compressor ? { on: dyn.compressor.compressorEnabled, th: db(dyn.compressor.threshold), ratio: db(dyn.compressor.ratio) } : null,
      gate: dyn.expander ? { on: dyn.expander.expanderEnabled, th: db(dyn.expander.threshold) } : null,
      makeup: db(dyn.makeUpGain),
    };
  }
  return {
    connected: true, ip, model: s.info?.productIdentifier || "ATEM", videoMode: atem.videoMode?.name || "",
    program: me.programInput, preview: me.previewInput, inTransition: !!me.transitionPosition?.inTransition,
    pip: !!usk?.onAir, ftb: !!me.fadeToBlack?.isFullyBlack, inputs, audio,
    master: { fader: db(fl.master?.properties?.faderGain) },
    streaming: s.streaming?.status?.state ?? null, recording: s.recordings?.status?.state ?? null,
  };
}
function push() { const sm = summary(); const j = JSON.stringify(sm); if (j !== lastSummary) { lastSummary = j; send("atem-state", sm); } }

async function connect(addr) {
  if (!Atem) throw new Error("ATEM control module is not available in this build");
  ip = addr || ip || DEFAULT_IP;
  if (atem) { try { await atem.disconnect(); atem.destroy?.(); } catch { } }
  atem = new Atem({ disableMultithreaded: true });
  atem.on("connected", async () => {
    push();
    try { await atem.startFairlightMixerSendLevels(); } catch { }
  });
  atem.on("disconnected", push);
  atem.on("stateChanged", push);
  atem.on("error", () => { });
  atem.on("levelChanged", (lv) => {
    if (lv.system !== "fairlight") return;
    if (lv.type === "source") levels[`${lv.index}`] = { l: db(lv.levels.leftLevel), r: db(lv.levels.rightLevel), in: db(lv.levels.inputLeftLevel) };
    if (lv.type === "master") levels.master = { l: db(lv.levels.leftLevel), r: db(lv.levels.rightLevel) };
  });
  clearInterval(levelTimer);
  levelTimer = setInterval(() => { if (atem?.status === 2) send("atem-levels", levels); }, 100);
  await atem.connect(ip);
  push();
  return { ok: true, ip };
}

// Find ATEMs on the network with macOS Bonjour (dns-sd)
function discover(timeout = 3500) {
  return new Promise((resolve) => {
    if (process.platform !== "darwin") return resolve([DEFAULT_IP]);
    const p = execFile("dns-sd", ["-B", "_blackmagic._tcp", "local."]);
    const names = new Set(); let out = "";
    p.stdout.on("data", d => { out += d; for (const line of out.split("\n")) { const m = line.match(/\sAdd\s.*_blackmagic\._tcp\.\s+(.+)$/); if (m) names.add(m[1].trim()); } });
    setTimeout(async () => {
      p.kill();
      const ips = [];
      for (const n of names) {
        const host = await new Promise(r => { const q = execFile("dns-sd", ["-L", n, "_blackmagic._tcp", "local."]); let o = ""; q.stdout.on("data", d => { o += d; const m = o.match(/can be reached at ([^\s:]+?)\.?:\d+/); if (m) { q.kill(); r(m[1]); } }); setTimeout(() => { q.kill(); r(null); }, 2000); });
        if (!host) continue;
        const addr = await new Promise(r => { const q = execFile("dns-sd", ["-G", "v4", host]); let o = ""; q.stdout.on("data", d => { o += d; const m = o.match(/\s(\d+\.\d+\.\d+\.\d+)\s/); if (m) { q.kill(); r(m[1]); } }); setTimeout(() => { q.kill(); r(null); }, 2000); });
        if (addr) ips.push({ ip: addr, name: n });
      }
      resolve(ips);
    }, timeout);
  });
}

// --- speaker / voice presets -------------------------------------------------
// preset: { input: 1302, gain, fader, hpf, mudF, mudG, presF, presG, airG, gateTh, compTh, ratio, makeup, inputLevel }
async function applyVoice(p) {
  if (!atem || atem.status !== 2) throw new Error("ATEM not connected");
  const input = p.input || 1302;
  const inp = atem.state.fairlight?.inputs?.[input];
  const source = Object.keys(inp?.sources || {})[0] || "-65280";
  const bands = inp?.sources?.[source]?.equalizer?.bands || [];
  const x = (v) => Math.round(v * 100);
  const props = {};
  if (p.gain != null) props.gain = x(p.gain);
  if (p.fader != null) props.faderGain = x(p.fader);
  if (p.mixOn) props.mixOption = 2;  // FairlightAudioMixOption.On
  if (p.makeup != null) props.makeUpGain = x(p.makeup);
  props.equalizerEnabled = true; props.equalizerGain = 0;
  await atem.setFairlightAudioMixerSourceProps(input, source, props);
  const eq = [
    { band: 0, bandEnabled: true, frequency: p.hpf ?? 90, gain: 0, qFactor: 71 },
    { band: 1, bandEnabled: false },
    { band: 2, bandEnabled: true, frequencyRange: 2, frequency: p.mudF ?? 250, gain: x(p.mudG ?? -3), qFactor: 140 },
    { band: 3, bandEnabled: true, frequencyRange: 4, frequency: p.presF ?? 3500, gain: x(p.presG ?? 3), qFactor: 140 },
    { band: 4, bandEnabled: true, frequencyRange: 8, frequency: 10000, gain: x(p.airG ?? 2), qFactor: 100 },
    { band: 5, bandEnabled: false },
  ];
  for (const b of eq) {
    const { band, ...rest } = b;
    const o = { ...rest };
    if (o.frequencyRange && !(bands[band]?.supportedFrequencyRanges || []).includes(o.frequencyRange)) delete o.frequencyRange;
    try { await atem.setFairlightAudioMixerSourceEqualizerBandProps(input, source, band, o); } catch (e) { }
  }
  try {
    if (p.gateOff) await atem.setFairlightAudioMixerSourceExpanderProps(input, source, { expanderEnabled: false });   // music: never gate
    else await atem.setFairlightAudioMixerSourceExpanderProps(input, source, { expanderEnabled: true, gateEnabled: false, threshold: x(p.gateTh ?? -48), range: x(10), ratio: x(1.5), attack: x(1.4), hold: 0, release: x(150) });
  } catch { }
  try { await atem.setFairlightAudioMixerSourceCompressorProps(input, source, { compressorEnabled: true, threshold: x(p.compTh ?? -22), ratio: x(p.ratio ?? 3), attack: x(p.compAttack ?? 5), hold: 0, release: x(p.compRelease ?? 150) }); } catch { }
  try { await atem.setFairlightAudioMixerSourceLimiterProps(input, source, { limiterEnabled: true, threshold: x(p.limTh ?? -3), attack: x(0.7), hold: 0, release: x(93) }); } catch { }
  if (p.cameraAudioOff) {
    for (const i of [1, 2, 3, 4]) { const s = Object.keys(atem.state.fairlight?.inputs?.[i]?.sources || {})[0]; if (s) try { await atem.setFairlightAudioMixerSourceProps(i, s, { mixOption: 0 }); } catch { } }
  }
  if (p.masterSafe) {
    try { await atem.setFairlightAudioMixerMasterProps({ faderGain: 0 }); } catch { }
    try { await atem.setFairlightAudioMixerMasterLimiterProps({ limiterEnabled: true, threshold: x(-1), attack: x(0.7), hold: 0, release: x(93) }); } catch { }
    for (let b = 0; b < 6; b++) try { await atem.setFairlightAudioMixerMasterEqualizerBandProps(b, { gain: 0 }); } catch { }
  }
  push();
  return { ok: true };
}
// small live adjustments from the audio monitor: { input, faderDelta, gainDelta, band, bandProps }
async function nudge(a) {
  if (!atem || atem.status !== 2) throw new Error("ATEM not connected");
  const input = a.input || 1302;
  const inp = atem.state.fairlight?.inputs?.[input];
  const source = Object.keys(inp?.sources || {})[0];
  const src = inp?.sources?.[source];
  if (!src) throw new Error("No audio input " + input);
  if (a.mixOn) await atem.setFairlightAudioMixerSourceProps(input, source, { mixOption: 2 });
  if (a.faderDelta) await atem.setFairlightAudioMixerSourceProps(input, source, { faderGain: Math.min(1000, Math.round((src.properties.faderGain || 0) + a.faderDelta * 100)) });
  if (a.gainDelta) await atem.setFairlightAudioMixerSourceProps(input, source, { gain: Math.round((src.properties.gain || 0) + a.gainDelta * 100) });
  if (a.band != null) {
    const cur = src.equalizer?.bands?.[a.band] || {};
    const o = { bandEnabled: true };
    if (a.freq) o.frequency = a.freq;
    if (a.gainDb != null) o.gain = Math.round(a.gainDb * 100);
    if (a.gainAdd != null) o.gain = Math.max(-2000, Math.min(2000, (cur.gain || 0) + Math.round(a.gainAdd * 100)));
    await atem.setFairlightAudioMixerSourceEqualizerBandProps(input, source, a.band, o);
  }
  if (a.compressor) await atem.setFairlightAudioMixerSourceCompressorProps(input, source, { compressorEnabled: true, threshold: Math.round((a.compressor.th ?? -22) * 100), ratio: Math.round((a.compressor.ratio ?? 3) * 100) });
  if (a.gate) await atem.setFairlightAudioMixerSourceExpanderProps(input, source, { expanderEnabled: true, threshold: Math.round(a.gate.th * 100) });
  if (a.masterLimiter) await atem.setFairlightAudioMixerMasterLimiterProps({ limiterEnabled: true, threshold: -100 });
  if (a.fader != null) await atem.setFairlightAudioMixerSourceProps(input, source, { faderGain: Math.max(-6000, Math.min(1000, Math.round(a.fader * 100))) });   // absolute fader (dB)
  push(); return { ok: true };
}

async function cmd(c, ...a) {
  if (c === "connect") return connect(a[0]);
  if (c === "discover") return discover();
  if (c === "state") return summary();
  if (c === "disconnect") { if (atem) { await atem.disconnect().catch(() => { }); atem = null; } push(); return { ok: true }; }
  if (!atem || atem.status !== 2) throw new Error("ATEM not connected");
  switch (c) {
    case "program": return atem.changeProgramInput(a[0]);
    case "preview": return atem.changePreviewInput(a[0]);
    case "cut": return atem.cut();
    case "auto": return atem.autoTransition();
    case "pip": return atem.setUpstreamKeyerOnAir(!!a[0], 0, 0);
    case "ftb": return atem.fadeToBlack();
    case "voice": return applyVoice(a[0]);
    case "nudge": return nudge(a[0]);
    case "videoMode": return atem.sendCommand(new Commands.VideoModeCommand(a[0] === "1080p50" ? Enums.VideoMode.P1080p50 : a[0] === "1080p30" ? Enums.VideoMode.N1080p30 : Enums.VideoMode.N1080p60));
    case "saveStartup": return atem.saveStartupState();
  }
  throw new Error("Unknown ATEM command " + c);
}

module.exports = { init: (sender) => { send = sender; }, cmd, DEFAULT_IP };
