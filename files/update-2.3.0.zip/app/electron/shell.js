// Revival Worship — stable shell (Electron entry point).
// Picks which copy of the app code to run: the newest update downloaded from GitHub (userData/updates/<version>/app)
// or the copy bundled in the installer. If an update fails to start, the next launch falls back automatically.
// Only this file and the Electron runtime need a full reinstall; everything else updates in the background.
const { app } = require("electron");
const path = require("path");
const fs = require("fs");
const Module = require("module");

const SHELL = 2;                                           // bump only when the shell / native modules change
const bundled = path.join(__dirname, "..");                // <app>/  (electron/, server/, web/)
const updatesDir = path.join(app.getPath("userData"), "updates");
const stateFile = path.join(updatesDir, "state.json");

const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };
const cmp = (a, b) => { const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };
const verOf = (root) => readJson(path.join(root, "web", "version.json"), {}).version || "0";

function pickRoot() {
  const st = readJson(stateFile, { bad: [] }); st.bad ||= [];
  // an update that was starting but never reported "ready" twice in a row → don't use it again
  st.fails ||= {};
  if (st.booting) { st.fails[st.booting] = (st.fails[st.booting] || 0) + 1; if (st.fails[st.booting] >= 2 && !st.bad.includes(st.booting)) st.bad.push(st.booting); st.booting = null; }
  const bundledVer = verOf(bundled);
  let best = null;
  try {
    for (const v of fs.readdirSync(updatesDir)) {
      const root = path.join(updatesDir, v, "app");
      if (st.bad.includes(v) || st.hold === v) continue;
      const man = readJson(path.join(updatesDir, v, "update.json"), null);
      if (!man || !fs.existsSync(path.join(root, "electron", "main.js")) || (man.minShell || 0) > SHELL) continue;
      if (cmp(v, bundledVer) <= 0) continue;
      if (!best || cmp(v, best.v) > 0) best = { v, root };
    }
  } catch { }
  if (st.pinBundled) best = null;                          // "use the installed version" chosen in Settings
  if (best) st.booting = best.v;
  try { fs.mkdirSync(updatesDir, { recursive: true }); fs.writeFileSync(stateFile, JSON.stringify(st, null, 1)); } catch { }
  return best ? { root: best.root, version: best.v, fromUpdate: true } : { root: bundled, version: bundledVer, fromUpdate: false };
}

const pick = pickRoot();
// let code inside an update folder find the modules shipped with the installer (ws, atem-connection)
process.env.NODE_PATH = [path.join(bundled, "node_modules"), process.env.NODE_PATH].filter(Boolean).join(path.delimiter);
Module._initPaths();

global.RW = {
  SHELL, bundled, updatesDir, stateFile, codeRoot: pick.root, version: pick.version, fromUpdate: pick.fromUpdate, bundledVersion: verOf(bundled),
  resources: app.isPackaged ? process.resourcesPath : path.join(bundled, "dist-resources"),
  markGood() { const st = readJson(stateFile, { bad: [] }); if (st.booting || st.fails?.[pick.version]) { st.booting = null; st.good = pick.version; if (st.fails) delete st.fails[pick.version]; try { fs.writeFileSync(stateFile, JSON.stringify(st, null, 1)); } catch { } } },
  readState: () => readJson(stateFile, { bad: [] }),
  writeState(st) { try { fs.mkdirSync(updatesDir, { recursive: true }); fs.writeFileSync(stateFile, JSON.stringify(st, null, 1)); } catch { } },
};

try { require(path.join(pick.root, "electron", "main.js")); }
catch (e) {
  // the update itself is broken → mark it bad and start the installed copy instead
  if (pick.fromUpdate) {
    const st = global.RW.readState(); st.bad = [...new Set([...(st.bad || []), pick.version])]; st.booting = null; global.RW.writeState(st);
    app.relaunch(); app.exit(0);
  } else throw e;
}
