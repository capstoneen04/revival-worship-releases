// Church library pack: song lyrics, Hindi Bible, church database and members' photos travel inside public
// downloads locked with the church library password (AES-256-GCM, key from scrypt). Each computer asks for the
// password once, keeps the derived key (encrypted with the OS keychain when available) and unlocks updates by itself.
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");
const crypto = require("crypto");

const MAGIC = "RWPACK1\n";
const KDF = { N: 1 << 15, r: 8, p: 1, maxmem: 96 * 1024 * 1024 };

function deriveKey(password, saltB64) { return crypto.scryptSync(String(password).normalize("NFC"), Buffer.from(saltB64, "base64"), 32, KDF); }

// ---------- build side (tools/release.js) ----------
function buildPack({ srcDir, out, password, key: givenKey, salt, version, files: givenFiles }) {
  const files = givenFiles ? { ...givenFiles } : {};
  const walk = (rel) => {
    for (const e of fs.readdirSync(path.join(srcDir, rel), { withFileTypes: true })) {
      if (e.name.startsWith(".")) continue;
      const r = rel ? rel + "/" + e.name : e.name;
      if (e.isDirectory()) walk(r); else files[r] = fs.readFileSync(path.join(srcDir, r)).toString("base64");
    }
  };
  if (!givenFiles) walk("");
  const plain = zlib.gzipSync(Buffer.from(JSON.stringify({ version, created: new Date().toISOString(), files })), { level: 9 });
  const key = givenKey || deriveKey(password, salt), iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([c.update(plain), c.final()]);
  const header = { version, salt, iv: iv.toString("base64"), tag: c.getAuthTag().toString("base64"), kdf: "scrypt-32768-8-1", files: Object.keys(files).length };
  const buf = Buffer.concat([Buffer.from(MAGIC + JSON.stringify(header) + "\n"), enc]);
  if (out) fs.writeFileSync(out, buf);
  return out ? header : { header, buf };
}

// ---------- app side ----------
function readHeader(file) {
  const buf = fs.readFileSync(file);
  if (buf.slice(0, MAGIC.length).toString() !== MAGIC) throw new Error("Not a church library file");
  const nl = buf.indexOf(10, MAGIC.length);
  return { header: JSON.parse(buf.slice(MAGIC.length, nl).toString()), body: buf.slice(nl + 1) };
}
function decryptPack(file, key) {
  const { header, body } = readHeader(file);
  const d = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(header.iv, "base64"));
  d.setAuthTag(Buffer.from(header.tag, "base64"));
  let plain;
  try { plain = Buffer.concat([d.update(body), d.final()]); } catch { const e = new Error("Wrong password"); e.code = "WRONG_PASSWORD"; throw e; }
  return { header, data: JSON.parse(zlib.gunzipSync(plain).toString()) };
}

function createLibrary({ userData, appDir, safeStorage }) {
  const dir = path.join(userData, "library");
  const keyFile = path.join(dir, ".key");
  const infoFile = path.join(dir, "library.json");
  const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };
  const cmp = (a, b) => { const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };

  function saveKey(key) {
    fs.mkdirSync(dir, { recursive: true });
    const enc = safeStorage?.isEncryptionAvailable?.() ? "k1:" + safeStorage.encryptString(key.toString("base64")).toString("base64") : "k0:" + key.toString("base64");
    fs.writeFileSync(keyFile, enc, { mode: 0o600 });
  }
  function loadKey() {
    try {
      const s = fs.readFileSync(keyFile, "utf8");
      if (s.startsWith("k1:")) return Buffer.from(safeStorage.decryptString(Buffer.from(s.slice(3), "base64")), "base64");
      if (s.startsWith("k0:")) return Buffer.from(s.slice(3), "base64");
    } catch { }
    return null;
  }
  function install(data, header) {
    fs.mkdirSync(dir, { recursive: true });
    let n = 0;
    for (const [rel, b64] of Object.entries(data.files)) {
      if (rel.includes("..")) continue;
      const buf = Buffer.from(b64, "base64");
      if (rel.startsWith("files/")) {                       // e.g. files/Media/People/x.png → the church folder, only if missing
        const dest = path.join(appDir, rel.slice(6));
        if (!fs.existsSync(dest)) { fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, buf); }
      } else { const dest = path.join(dir, rel); fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest + ".tmp", buf); fs.renameSync(dest + ".tmp", dest); }
      n++;
    }
    fs.writeFileSync(infoFile, JSON.stringify({ version: header.version, installed: new Date().toISOString(), files: n }));
    return n;
  }
  const lib = {
    dir,
    status(packs) {
      const info = readJson(infoFile, null), best = lib.bestPack(packs);
      return { unlocked: !!info && fs.existsSync(path.join(dir, "songs.json")), version: info?.version || null, pack: best ? { version: best.version } : null, hasKey: !!loadKey() };
    },
    bestPack(packs) {                                         // newest readable pack among the candidates
      let best = null;
      for (const f of packs) { try { if (!fs.existsSync(f)) continue; const { header } = readHeader(f); if (!best || cmp(header.version, best.version) > 0) best = { file: f, version: header.version, salt: header.salt }; } catch { } }
      return best;
    },
    unlock(password, packs) {
      const best = lib.bestPack(packs); if (!best) throw new Error("No church library file found");
      const key = deriveKey(password, best.salt);
      const { data, header } = decryptPack(best.file, key);
      saveKey(key);
      return { version: header.version, files: install(data, header) };
    },
    // newer pack arrived (update) and this computer already knows the key → install silently
    autoUpdate(packs) {
      const key = loadKey(); if (!key) return null;
      const best = lib.bestPack(packs); if (!best) return null;
      const info = readJson(infoFile, null);
      if (info && cmp(best.version, info.version) <= 0) return null;
      try { const { data, header } = decryptPack(best.file, key); return { version: header.version, files: install(data, header) }; }
      catch (e) { return { error: e.message }; }
    },
    key: () => loadKey(),
    readInstalled() { try { return { version: readJson(infoFile, {}).version, songs: fs.readFileSync(path.join(dir, "songs.json")), files: Object.fromEntries(fs.readdirSync(dir).filter(f => !f.startsWith(".") && f !== "library.json" && fs.statSync(path.join(dir, f)).isFile()).map(f => [f, fs.readFileSync(path.join(dir, f)).toString("base64")])) }; } catch { return null; } },
    forget() { try { fs.unlinkSync(keyFile); } catch { } },
  };
  return lib;
}

module.exports = { buildPack, decryptPack, readHeader, deriveKey, createLibrary };
