// Message bus between operator, projector/stage outputs, OBS overlays and phone remote.
// Uses BroadcastChannel (same browser) + WebSocket relay at /bus when served by the Revival app server.
export function createBus(role = "client") {
  const listeners = new Set();
  const bc = "BroadcastChannel" in self ? new BroadcastChannel("revival-worship") : null;
  let ws = null, wsOpen = false, retry = 0;
  const queue = [];
  const deliver = (msg) => {
    // health check: every overlay / output page answers so the app knows which ones loaded fine
    if (msg && msg.type === "tpl-ping" && role !== "operator") { try { api.send({ type: "tpl-pong", href: location.pathname + location.search, role, obs: !!self.obsstudio }); } catch { } }
    listeners.forEach(fn => { try { fn(msg); } catch (e) { console.error(e); } });
  };
  if (bc) bc.onmessage = (e) => deliver(e.data);

  function wsUrl() {
    const p = new URLSearchParams(location.search);
    if (p.get("bus")) return p.get("bus");
    if (location.protocol === "http:" || location.protocol === "https:") {
      return (location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/bus";
    }
    return "ws://localhost:7777/bus";
  }
  function connect() {
    try { ws = new WebSocket(wsUrl()); } catch { ws = null; return; }
    ws.onopen = () => { wsOpen = true; retry = 0; ws.send(JSON.stringify({ type: "hello", role })); while (queue.length) ws.send(queue.shift()); deliver({ type: "_bus", connected: true }); };
    ws.onmessage = (e) => { try { const m = JSON.parse(e.data); if (m._from !== myId) deliver(m); } catch { } };
    ws.onclose = () => { wsOpen = false; deliver({ type: "_bus", connected: false }); setTimeout(connect, Math.min(5000, 500 * ++retry)); };
    ws.onerror = () => { };
  }
  const myId = Math.random().toString(36).slice(2);
  connect();
  const api = {
    send(msg) {
      msg = { ...msg, _from: myId };
      if (bc) bc.postMessage(msg);
      const s = JSON.stringify(msg);
      if (wsOpen) ws.send(s); else if (queue.length < 20) queue.push(s);
    },
    on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    get connected() { return wsOpen; },
  };
  return api;
}
