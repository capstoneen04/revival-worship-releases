// Broadcast control: OBS scene board with live thumbnails, stream/record, Revival scene builder, countdown, service info
import { S, h, obsConnect, saveSettings, toast, modal, onChange, emit, native } from "../core.js";

export const TEMPLATES = [
  ["starting", "Starting Soon", "Countdown, verse of the day, rotating announcements, ticker"],
  ["welcome", "Welcome", "Full-screen welcome title with today’s date"],
  ["bug", "Logo bug + LIVE", "Corner logo, service title, LIVE badge and clock — goes over the camera"],
  ["lower-third", "Lower third", "Lyrics, scripture, Message quotes, name and title cards"],
  ["split.html?view=worship", "Split · Worship", "Camera left, live lyrics right, song title strip"],
  ["split.html?view=sermon", "Split · Sermon", "Camera left, scripture / quote right, sermon title strip"],
  ["scripture", "Scripture card", "Full-screen designed card for verses, quotes or lyrics"],
  ["prayer", "Prayer / Be right back", "Calm prayer screen"],
  ["ending", "Ending", "God bless you, next service, address, social"],
  ["ticker", "Ticker", "Scrolling announcements bar"],
];
const tplUrl = (base, t) => `${base}/obs/${t.includes(".html") ? t : t + ".html"}`;

const SCENES = (base) => {
  const B = (name, t, opts = {}) => ({ type: "browser", name, url: tplUrl(base, t), ...opts });
  const CAM = (layout) => ({ type: "camera", layout });
  const PIP = { type: "pip" };
  return [
    { name: "Revival · 1 Starting Soon", items: [B("RW Starting Soon", "starting", { audio: true })] },
    { name: "Revival · 2 Welcome", items: [B("RW Welcome", "welcome")] },
    { name: "Revival · 3 Worship", items: [CAM("full"), PIP, B("RW Logo Bug", "bug"), B("RW Lower Third", "lower-third")] },
    { name: "Revival · 4 Worship Split", items: [CAM("split"), B("RW Split Worship", "split.html?view=worship")] },
    { name: "Revival · 5 Sermon", items: [CAM("full"), PIP, B("RW Logo Bug", "bug"), B("RW Lower Third", "lower-third"), B("RW Ticker", "ticker", { hidden: true })] },
    { name: "Revival · 6 Sermon Split", items: [CAM("split"), B("RW Split Sermon", "split.html?view=sermon")] },
    { name: "Revival · 7 Scripture", items: [B("RW Scripture Card", "scripture")] },
    { name: "Revival · 8 Projector Feed", items: [{ type: "browser", name: "RW Projector Feed", url: `${base}/output.html?mode=projector` }] },
    { name: "Revival · 9 Prayer", items: [B("RW Prayer", "prayer")] },
    { name: "Revival · 10 Ending", items: [B("RW Ending", "ending", { audio: true })] },
  ];
};

export const CAM_NAME = "RW Church Camera", PIP_NAME = "RW OBSBOT";
// pick a capture device by name: ATEM ("Blackmagic Design") for the main camera, OBSBOT for the second
export async function pickDevice(inputName, re) {
  try {
    // macOS: property "device"; Windows (DirectShow): "video_device_id"
    const win = (await S.obs.call("GetInputSettings", { inputName }).then(r => r.inputKind).catch(() => "")) === "dshow_input";
    const prop = win ? "video_device_id" : "device";
    const { propertyItems } = await S.obs.call("GetInputPropertiesListPropertyItems", { inputName, propertyName: prop });
    const items = (propertyItems || []).filter(p => p.itemEnabled !== false && p.itemValue);
    const dev = items.find(p => re.test(p.itemName)) || null;
    if (!dev) return null;
    const settings = win ? { video_device_id: dev.itemValue, device_name: dev.itemName, res_type: 1, resolution: "1920x1080" }
      : { device: dev.itemValue, device_name: dev.itemName, use_preset: true, preset: "AVCaptureSessionPreset1920x1080" };
    await S.obs.call("SetInputSettings", { inputName, inputSettings: settings });
    return dev.itemName;
  } catch { return null; }
}
export async function buildRevivalScenes(log = () => { }, { setCanvas = true } = {}) {
  const obs = S.obs; const base = location.protocol.startsWith("http") ? location.origin : "http://localhost:7777";
  let vs = await obs.call("GetVideoSettings");
  if (setCanvas && (vs.baseWidth !== 1920 || vs.baseHeight !== 1080 || vs.fpsNumerator / vs.fpsDenominator !== 60)) {
    try { await obs.call("SetVideoSettings", { baseWidth: 1920, baseHeight: 1080, outputWidth: 1920, outputHeight: 1080, fpsNumerator: 60, fpsDenominator: 1 }); vs = await obs.call("GetVideoSettings"); log("Video set to 1920 × 1080 at 60 fps"); }
    catch (e) { log("Couldn’t change canvas (stop streaming/recording first): " + e.message); }
  }
  const W = vs.baseWidth, H = vs.baseHeight, k = W / 1920;
  const { inputKinds } = await obs.call("GetInputKindList", { unversioned: false });
  const camKind = ["av_capture_input_v2", "av_capture_input", "macos-avcapture", "dshow_input", "v4l2_input"].find(x => inputKinds.includes(x));
  const { inputs } = await obs.call("GetInputList");
  const have = new Set(inputs.map(i => i.inputName));
  const { scenes } = await obs.call("GetSceneList");
  const haveScene = new Set(scenes.map(s => s.sceneName));

  async function place(scene, source, t) {
    const { sceneItemId } = await obs.call("GetSceneItemId", { sceneName: scene, sourceName: source });
    await obs.call("SetSceneItemTransform", { sceneName: scene, sceneItemId, sceneItemTransform: t });
    return sceneItemId;
  }
  for (const sc of SCENES(base)) {
    if (!haveScene.has(sc.name)) { await obs.call("CreateScene", { sceneName: sc.name }); log("Created scene " + sc.name); }
    else log("Updating scene " + sc.name);
    const { sceneItems } = await obs.call("GetSceneItemList", { sceneName: sc.name });
    const inScene = new Set(sceneItems.map(i => i.sourceName));
    for (const it of sc.items) {
      let src, transform;
      if (it.type === "camera") {
        src = CAM_NAME;
        if (!have.has(src)) {
          if (camKind) {
            await obs.call("CreateInput", { sceneName: sc.name, inputName: src, inputKind: camKind, inputSettings: {} });
            const d = await pickDevice(src, /blackmagic|atem/i) || await pickDevice(src, /./);
            if (d) log("Main camera: " + d);
          } else {
            await obs.call("CreateInput", { sceneName: sc.name, inputName: src, inputKind: "color_source_v3", inputSettings: { color: 0xff3a2a1a, width: 1920, height: 1080 } });
          }
          have.add(src); inScene.add(src);
        }
        transform = it.layout === "split"
          ? { positionX: 60 * k, positionY: 60 * k, boundsType: "OBS_BOUNDS_SCALE_OUTER", boundsWidth: 1200 * k, boundsHeight: 675 * k, boundsAlignment: 0, alignment: 5 }
          : { positionX: 0, positionY: 0, boundsType: "OBS_BOUNDS_SCALE_OUTER", boundsWidth: W, boundsHeight: H, boundsAlignment: 0, alignment: 5 };
      } else if (it.type === "pip") {
        src = PIP_NAME;
        if (!camKind) continue;
        if (!have.has(src)) {
          await obs.call("CreateInput", { sceneName: sc.name, inputName: src, inputKind: camKind, inputSettings: {}, sceneItemEnabled: false });
          const d = await pickDevice(src, /obsbot/i);
          log(d ? "Second camera (corner): " + d : "OBSBOT not plugged in — the corner camera is ready for when it is");
          have.add(src); inScene.add(src);
        }
        it.hidden = true;
        transform = { positionX: 1490 * k, positionY: 60 * k, boundsType: "OBS_BOUNDS_SCALE_OUTER", boundsWidth: 384 * k, boundsHeight: 216 * k, boundsAlignment: 0, alignment: 5, cropLeft: 0 };
      } else {
        src = it.name;
        const settings = { url: it.url, width: 1920, height: 1080, fps: 30, reroute_audio: !!it.audio, shutdown: false, restart_when_active: false, css: "body{background-color:rgba(0,0,0,0);margin:0;overflow:hidden}" };
        if (!have.has(src)) { await obs.call("CreateInput", { sceneName: sc.name, inputName: src, inputKind: "browser_source", inputSettings: settings }); have.add(src); inScene.add(src); }
        else await obs.call("SetInputSettings", { inputName: src, inputSettings: settings });
        transform = { positionX: 0, positionY: 0, boundsType: "OBS_BOUNDS_STRETCH", boundsWidth: W, boundsHeight: H, boundsAlignment: 0, alignment: 5 };
      }
      if (!inScene.has(src)) { await obs.call("CreateSceneItem", { sceneName: sc.name, sourceName: src, sceneItemEnabled: !it.hidden }); inScene.add(src); }
      const id = await place(sc.name, src, transform);
      if (it.hidden) await obs.call("SetSceneItemEnabled", { sceneName: sc.name, sceneItemId: id, sceneItemEnabled: false });
    }
    // keep stacking order: camera at the bottom, overlays above in the listed order
    let idx = 0;
    for (const it of sc.items) { const src = it.type === "camera" ? CAM_NAME : it.type === "pip" ? PIP_NAME : it.name; if (it.type === "pip" && !camKind) continue; try { const { sceneItemId } = await obs.call("GetSceneItemId", { sceneName: sc.name, sourceName: src }); await obs.call("SetSceneItemIndex", { sceneName: sc.name, sceneItemId, sceneItemIndex: idx++ }); } catch { } }
  }
  try { await obs.call("SetCurrentSceneTransition", { transitionName: "Fade" }); await obs.call("SetCurrentSceneTransitionDuration", { transitionDuration: 400 }); } catch { }
  // sensible automatic switching in Revival Worship
  const a = S.settings.obs.autoScenes;
  if (!a.song) a.song = "Revival · 3 Worship";
  if (!a.bible) a.bible = "Revival · 6 Sermon Split";
  if (!a.message) a.message = "Revival · 6 Sermon Split";
  await saveSettings();
  S.obsScenes = await S.obs.scenes();
  emit("obs");
  try { const af = await import("../autoframe.js"); await af.applySplitLayout(); const r = await af.refreshOverlays({ all: true }); log(`Reloaded ${r.reloaded} overlays`); } catch { }
  log("Done — 10 Revival scenes are ready in OBS (1080p60).");
}

export function broadcastView(root) {
  const page = h("div", { class: "pagepad", style: "display:flex;flex-direction:column;gap:14px" });
  root.appendChild(page);
  const thumbs = new Map();
  let thumbTimer = null, statusTimer = null, status = {};

  // Scene thumbnails: every snapshot costs OBS a GPU read-back, so take each scene once (one at a time),
  // then refresh only the scene that is on air — and nothing extra while streaming/recording.
  let thumbRound = 0;
  async function snap(name, w = 320) {
    try { const r = await S.obs.call("GetSourceScreenshot", { sourceName: name, imageFormat: "jpg", imageWidth: w, imageCompressionQuality: 50 }); thumbs.set(name, r.imageData); const img = page.querySelector(`img[data-scene="${CSS.escape(name)}"]`); if (img) img.src = r.imageData; } catch { }
  }
  async function refreshThumbs() {
    if (!S.obs.connected || !root.classList.contains("on") || document.hidden) return;
    const live = !!S.obsStats?.live;
    if (thumbRound++ === 0 && !live) { for (const name of S.obsScenes.list) { if (!root.classList.contains("on")) return; if (!thumbs.has(name)) { await snap(name); await new Promise(r => setTimeout(r, 400)); } } }
    if (!live || thumbRound % 2 === 0) await snap(S.obsScenes.current);
  }
  async function refreshStatus() {
    if (!S.obs.connected || !root.classList.contains("on")) return;
    try {
      const [st, rec, vc] = await Promise.all([S.obs.call("GetStreamStatus"), S.obs.call("GetRecordStatus"), S.obs.call("GetVirtualCamStatus").catch(() => ({}))]);
      status = { stream: st.outputActive, streamTc: st.outputTimecode, rec: rec.outputActive, recTc: rec.outputTimecode, vcam: vc.outputActive };
      const set = (id, on, label) => { const b = page.querySelector("#" + id); if (b) { b.classList.toggle("live", !!on); b.textContent = label; } };
      set("b-stream", status.stream, status.stream ? `■ Stop stream · ${(status.streamTc || "").slice(0, 8)}` : "● Go live (stream)");
      set("b-rec", status.rec, status.rec ? `■ Stop recording · ${(status.recTc || "").slice(0, 8)}` : "● Record");
      set("b-vcam", status.vcam, status.vcam ? "Virtual camera on" : "Virtual camera");
    } catch { }
  }

  function field(label, key, opts = {}) {
    const b = S.settings.broadcast;
    const el = opts.area ? h("textarea", { class: "input", rows: opts.rows || 3 }) : h("input", { class: "input" });
    el.value = opts.get ? opts.get(b) : (b[key] || "");
    el.onchange = () => { if (opts.set) opts.set(b, el.value); else b[key] = el.value; saveSettings(); };
    return h("label", { class: "f", style: opts.style || "" }, label, el);
  }

  async function render() {
    page.innerHTML = "";
    const base = location.protocol.startsWith("http") ? location.origin : "http://localhost:7777";
    const b = S.settings.broadcast;
    if (!S.obs.connected) {
      page.append(h("div", { class: "card col" },
        h("div", { style: "font-weight:650;font-size:15px" }, "Connect to OBS"),
        h("div", { class: "muted" }, native?.obsLocalConfig ? "Revival Worship reads OBS’s WebSocket settings on this Mac automatically. Make sure OBS is open and Tools → WebSocket Server Settings → “Enable WebSocket server” is ticked." : "Enter the OBS WebSocket address and password on the OBS page."),
        h("div", { class: "row" }, h("button", { class: "btn primary", onclick: async () => { if (await obsConnect()) render(); } }, "Connect to OBS"), h("button", { class: "btn ghost", onclick: () => window.rwShow("obs") }, "OBS settings…"))));
    } else {
      // Scene board
      const grid = h("div", { style: "display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px" });
      for (const name of S.obsScenes.list) {
        const on = name === S.obsScenes.current;
        grid.appendChild(h("div", { class: "thumb" + (on ? " live" : ""), style: "padding:0;background:#000", onclick: async () => { try { await S.obs.setScene(name); } catch (e) { toast(e.message); } } },
          h("img", { "data-scene": name, src: thumbs.get(name) || "", style: "width:100%;height:100%;object-fit:cover;position:absolute;inset:0" }),
          h("div", { class: "lab" }, h("span", {}, name.replace(/^Revival · /, "")), h("span", { class: "k" }, on ? "ON AIR" : ""))));
      }
      page.append(h("div", { class: "card col" },
        h("div", { class: "row" }, h("div", { style: "font-weight:650;font-size:15px;flex:1" }, "OBS scenes — click to switch"),
          h("button", { class: "btn", id: "b-vcam", onclick: () => S.obs.call("ToggleVirtualCam").then(refreshStatus).catch(e => toast(e.message)) }, "Virtual camera"),
          h("button", { class: "btn", id: "b-rec", onclick: () => S.obs.call("ToggleRecord").then(refreshStatus).catch(e => toast(e.message)) }, "● Record"),
          h("button", { class: "btn", id: "b-stream", onclick: () => {
            if (status.stream) return modal("Stop the live stream?", h("p", { class: "muted" }, "Viewers will see the stream end."), [{ label: "Cancel" }, { label: "Stop stream", cls: "live", fn: () => S.obs.call("StopStream").then(refreshStatus) }]);
            modal("Go live?", h("p", { class: "muted" }, "Starts streaming with the stream key set in OBS → Settings → Stream."), [{ label: "Cancel" }, { label: "Go live", cls: "live", fn: () => S.obs.call("StartStream").then(refreshStatus).catch(e => toast(e.message)) }]);
          } }, "● Go live (stream)")),
        grid,
        S.obsScenes.list.some(n => n.startsWith("Revival · ")) ? null : h("div", { class: "muted" }, "No Revival scenes yet — use “Build Revival scenes” below.")));
    }

    // Builder + countdown
    const log = h("div", { class: "copyable", style: "max-height:150px;overflow:auto;white-space:pre-wrap;display:none" });
    const canvasCb = h("input", { type: "checkbox", checked: true });
    const mins = (m) => { b.countdownTo = Date.now() + m * 60000; saveSettings(); toast(`Countdown: ${m} minutes`); };
    const at = h("input", { class: "input", type: "time", style: "width:120px" });
    at.onchange = () => { if (!at.value) return; const [hh, mm] = at.value.split(":").map(Number); const d = new Date(); d.setHours(hh, mm, 0, 0); if (d < new Date()) d.setDate(d.getDate() + 1); b.countdownTo = d.getTime(); saveSettings(); toast("Countdown to " + at.value); };
    page.append(h("div", { class: "two" },
      h("div", { class: "card col" },
        h("div", { style: "font-weight:650;font-size:15px" }, "Build Revival scenes in OBS"),
        h("div", { class: "muted", style: "font-size:12.5px" }, "Creates 10 ready-made scenes — Starting Soon, Welcome, Worship, Worship Split, Sermon, Sermon Split, Scripture, Projector Feed, Prayer, Ending — with the church camera, logo bug, lyrics and scripture overlays. Safe to run again: it updates existing Revival scenes and leaves your other scenes alone."),
        h("label", { class: "row", style: "gap:6px" }, canvasCb, "Set OBS canvas to 1920 × 1080 (recommended)"),
        h("div", { class: "row" }, h("button", { class: "btn primary", disabled: !S.obs.connected, onclick: async (e) => {
          e.target.disabled = true; log.style.display = "block"; log.textContent = "";
          try { await buildRevivalScenes(m => { log.textContent += m + "\n"; log.scrollTop = 1e6; }, { setCanvas: canvasCb.checked }); toast("Revival scenes ready in OBS"); setTimeout(render, 600); }
          catch (err) { log.textContent += "Error: " + err.message + "\n"; }
          e.target.disabled = false;
        } }, "Build Revival scenes")), log),
      h("div", { class: "card col" },
        h("div", { style: "font-weight:650;font-size:15px" }, "Countdown (Starting Soon screen)"),
        h("div", { class: "row" }, ...[2, 5, 10, 15, 30].map(m => h("button", { class: "btn", onclick: () => mins(m) }, m + " min")), h("span", { class: "dim" }, "or at"), at, h("button", { class: "btn ghost", onclick: () => { b.countdownTo = 0; saveSettings(); } }, "Clear")),
        field("Line above the countdown", "startLabel"),
        h("div", { class: "row" }, h("button", { class: "btn", disabled: !S.obs.connected, onclick: () => S.obs.setScene("Revival · 1 Starting Soon").catch(e => toast(e.message)) }, "Show Starting Soon"),
          h("button", { class: "btn", disabled: !S.obs.connected, onclick: () => S.obs.setScene("Revival · 9 Prayer").catch(e => toast(e.message)) }, "Prayer screen"),
          h("button", { class: "btn", disabled: !S.obs.connected, onclick: () => S.obs.setScene("Revival · 10 Ending").catch(e => toast(e.message)) }, "Ending screen")))));

    // Service info
    page.append(h("div", { class: "card col" },
      h("div", { style: "font-weight:650;font-size:15px" }, "Today’s service — shown on all templates"),
      h("div", { class: "row", style: "align-items:flex-end" }, field("Service", "serviceTitle", { style: "flex:1" }), field("Sermon title", "sermonTitle", { style: "flex:1" }), field("Speaker", "speaker", { style: "flex:1" })),
      h("div", { class: "row", style: "align-items:flex-end" }, field("Name on screen", "streamName", { style: "flex:1" }), field("Meeting / series", "meeting", { style: "flex:1" }), field("Place", "place", { style: "flex:1" }), field("Night / part", "night", { style: "width:110px" }), field("Date code (blank = automatic)", "serviceCode", { style: "width:190px" })),
      h("div", { class: "row", style: "align-items:flex-end" }, field("Verse of the day", "", { style: "flex:2", get: b => b.verse.text, set: (b, v) => (b.verse.text = v) }), field("Reference", "", { style: "flex:1", get: b => b.verse.ref, set: (b, v) => (b.verse.ref = v) })),
      h("div", { class: "row", style: "align-items:flex-start" }, field("Announcements (one per line, they rotate)", "", { area: true, rows: 4, style: "flex:1", get: b => (b.announcements || []).join("\n"), set: (b, v) => (b.announcements = v.split("\n").map(x => x.trim()).filter(Boolean)) }),
        field("Ticker text", "ticker", { area: true, rows: 4, style: "flex:1" })),
      h("div", { class: "row", style: "align-items:flex-end" }, field("Prayer screen title", "brbTitle", { style: "flex:1" }), field("Prayer screen line", "brbText", { style: "flex:1" }), field("Ending title", "endTitle", { style: "flex:1" }), field("Ending line", "endText", { style: "flex:1" })),
      h("div", { class: "row", style: "align-items:flex-end" }, field("Next service", "nextService", { style: "flex:1" }), field("Address", "address", { style: "flex:2" }), field("Social / YouTube", "social", { style: "flex:1" }))));

    // Template gallery
    const gal = h("div", { style: "display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px" });
    for (const [t, name, desc] of TEMPLATES) {
      const url = tplUrl(base, t) + (t.startsWith("split") ? "&ph=1" : "");
      // a still picture (live previews of 10 templates would cost a lot of CPU); click for a live look
      const key = t.replace(/\.html.*$/, "").replace(/[^a-z-]/g, "") + (t.includes("view=") ? "-" + t.split("view=")[1] : "");
      const box = h("div", { class: "screen", style: "background:repeating-conic-gradient(#1a1d24 0 25%, #14161b 0 50%) 0 0/20px 20px;cursor:zoom-in", title: "Click for a live preview",
        onclick: () => { const f = h("iframe", { src: url, tabindex: "-1" }); const bx = h("div", { class: "screen", style: "width:min(1100px,90vw);background:#111" }, f); const m = modal(name, bx, [{ label: "Close" }]); m.querySelector(".modal").style.width = "min(1140px,94vw)"; requestAnimationFrame(() => f.style.transform = `scale(${bx.clientWidth / 1920})`); } },
        h("img", { src: `assets/previews/${key}.jpg`, alt: "", style: "position:absolute;inset:0;width:100%;height:100%;object-fit:cover" }));
      gal.appendChild(h("div", { class: "col", style: "gap:6px" }, box, h("div", { style: "font-weight:600" }, name), h("div", { class: "dim", style: "font-size:12px" }, desc),
        h("div", { class: "row" }, h("button", { class: "btn sm", onclick: async () => { await navigator.clipboard.writeText(tplUrl(base, t)); toast("URL copied"); } }, "Copy URL"),
          h("button", { class: "btn sm", disabled: !S.obs.connected, onclick: async () => { try { await S.obs.addBrowserSource(S.obsScenes.current, "RW " + name, tplUrl(base, t)); toast("Added to " + S.obsScenes.current); } catch (e) { toast(e.message); } } }, "Add to current scene"))));
    }
    page.append(h("div", { class: "card col" }, h("div", { style: "font-weight:650;font-size:15px" }, "Revival OBS templates"), h("div", { class: "muted", style: "font-size:12.5px" }, "All templates are 1920 × 1080 browser sources and update live from this app."), gal));
    refreshThumbs(); refreshStatus();
  }
  let sig = "";
  onChange(w => {
    if (w !== "obs" || !root.classList.contains("on")) return;
    const ns = S.obs.connected + "|" + S.obsScenes.list.join(",");
    if (ns !== sig) { sig = ns; render(); return; }
    page.querySelectorAll("img[data-scene]").forEach(img => { const t = img.parentElement, on = img.dataset.scene === S.obsScenes.current; t.classList.toggle("live", on); t.querySelector(".k").textContent = on ? "ON AIR" : ""; });
  });
  return {
    onShow() {
      sig = S.obs.connected + "|" + S.obsScenes.list.join(","); render();
      clearInterval(thumbTimer); clearInterval(statusTimer);
      thumbRound = 0; thumbTimer = setInterval(refreshThumbs, 4000); statusTimer = setInterval(refreshStatus, 2000); refreshThumbs();
    },
  };
}
