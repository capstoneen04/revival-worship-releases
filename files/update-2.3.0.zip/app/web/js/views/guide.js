// Guide: what to use when — the Sunday workflow, a tick-list, and which page does what.
import { S, h, onChange } from "../core.js";

const go = (v) => () => window.rwShow(v);
const STAGES = [
  { k: "week", t: "During the week", sub: "Prepare — 15 minutes", c: "#3b82f6", steps: [
    ["Paste the pastor’s message", "Sermon page → paste → Read details → check the English and Hindi → Use for this service.", "sermon"],
    ["YouTube title & thumbnail", "Same page: copy the title and description; pick the colour, Save thumbnail (or Copy image into Figma).", "sermon"],
    ["Plan the songs", "Service page: add songs, verses, Message quotes in order. Songs/Bible/Message pages are for finding things to add.", "service"],
    ["Convention or event?", "Produce → Start & End screens → Theme: pick or load the event theme (pictures, headline, music).", "production"],
  ] },
  { k: "before", t: "Sunday — 45 min before", sub: "Set up — 10 minutes", c: "#30a46c", steps: [
    ["Open OBS first, then Revival Worship", "The app connects to OBS by itself. Top bar must show OBS green and a health pill like “60 fps · 2 ms”.", null],
    ["Produce page", "This is the only page you need during the service. Check Speaker, Service order, Stream language.", "production"],
    ["Cameras", "ATEM inputs: 1 Panasonic (wide), 2 Tail Air (preacher, tracking), 3 Blackmagic (events), 4 laptop/spare. Event? Plug in the Tiny 2 (USB) — it is the picture-in-picture camera in OBS.", "production"],
    ["Sound", "Produce → Sound: it starts listening by itself (Blackmagic/ATEM input). Auto ✓ on, mode 🎵 Worship. Ask a singer and the pulpit mic to test: no red warnings.", "production"],
    ["Starting Soon", "Press the Starting Soon scene, set the countdown (Broadcast page or 10 min). Hymns start playing on their own.", "production"],
    ["Go live", "Stream card → Go live (asks to confirm). YouTube title is ready to copy in the same card.", "production"],
  ] },
  { k: "live", t: "During the service", sub: "Run — Produce page only", c: "#e5484d", steps: [
    ["Worship", "Click a song in Service order → it goes to the projector; Next ▶ / Space moves on. “Show lyrics on stream” (T) puts the words on YouTube. Sound switches to 🎵 Worship with the Worship scene; if the band overplays the app turns the stream down and offers “🎵 Tell band”.", "production"],
    ["Preacher comes up", "Speaker card → Speaker on (shows his name and sets his microphone if the ATEM is connected).", "production"],
    ["He reads the Title, Subject, Inspiration", "Sermon points → press Title, then Subject, then Inspiration as he speaks them. Hide from stream when done.", "production"],
    ["Scriptures", "Click the verse in Service order — it appears in English + Hindi. Sermon Split shows it big beside the preacher.", "production"],
    ["Scenes", "Sermon (full camera) or Sermon Split. ⇄ Swap layout gives the tall video that follows the preacher.", "production"],
  ] },
  { k: "after", t: "After the service", sub: "Close — 5 minutes", c: "#9b6bff", steps: [
    ["Ending", "Press the Ending scene (hymns play). After a minute: Stream card → Stop.", "production"],
    ["YouTube", "Paste the title and description, upload the thumbnail from Media/Thumbnails.", "sermon"],
    ["Back-up", "Automatic every 30 minutes into Revival Worship App › Backup (Settings → Back up now for an extra copy).", "settings"],
  ] },
];
const PAGES = [
  ["Produce", "production", "Running the service: scenes, cameras, lyrics/verses on stream, speaker, sermon points, stream, sound.", "Sunday — keep this open"],
  ["Sermon", "sermon", "Paste the pastor’s message; YouTube title, description and thumbnail.", "During the week"],
  ["Service", "service", "The order of songs, verses and quotes for the day.", "During the week"],
  ["Songs · Bible · Message", "songs", "Finding a song, verse or Message quote to add to the service.", "During the week"],
  ["Live", "live", "Big projector view (slide grid) — for a second operator on the projector only.", "Optional"],
  ["Image → Text", "ocr", "Turn a photo of a song sheet into text.", "When needed"],
  ["Broadcast", "broadcast", "One-time setup: Build Revival scenes, countdown, service info, template previews. Avoid during a stream.", "Setup"],
  ["OBS", "obs", "OBS connection, lower-third style, name cards.", "Setup"],
  ["Settings", "settings", "Projector, phone remote, backup.", "Setup"],
];

const NEW = [
  ["Import songs", "songs", "Songs → Import…: VerseVIEW, OpenLyrics, OpenSong, ChordPro, FreeShow or plain text files. New songs are marked “review”."],
  ["Song details", "songs", "Category, key, lyrics-by, notes and a song order like “V1 C V2 C B C”. Chords written as [G]Amazing [C]grace; transpose with − / +."],
  ["Coloured sections", "live", "Verse blue, chorus red, bridge purple — in the slide grid and the song view."],
  ["Headings & print", "service", "Service → + Heading (Worship, Word, Offering…), + Picture/Video, and Print for the band’s order of service."],
  ["Sermon timer", "live", "Live or Produce: start a 45-minute timer; the stage screen shows it big and turns red when time is over."],
  ["Audience message", "live", "Live → Audience message: a banner on the projector (e.g. “Please park on the left”)."],
  ["Recent", "live", "Live → Recent: put the last songs/verses back up with one click."],
  ["Screens", "settings", "Settings → Screens: languages stacked or side by side, second-language size, swap; stage layouts for musicians (chords) and the preacher (timer)."],
  ["Camera on projector", "production", "Produce → Camera → projector shows the live camera on the big screen."],
  ["Moving backgrounds", "settings", "Settings → Projector look → 🎬: choose a looping video (Media › Backgrounds) behind the lyrics."],
  ["Bible versions", "settings", "Settings → Bible versions: add any Bible from a Zefania/OSIS/USFX file (e.g. Marathi IRV) and choose the main and second Bible."],
  ["Stream Deck", "settings", "Settings → Stream Deck: button links for Bitfocus Companion (next, previous, blank, timer, scenes…)."],
  ["Phone songbook", "settings", "Members can open the songbook on Android or iPhone (install from the browser) and read it offline."],
  ["Team songbook (2.2)", "songs", "Testers add songs on their phones (typed or photo → text) or correct them; they arrive in Songs → Inbox here to approve."],
  ["Song inbox check (2.3)", "songs", "Every song sent from a phone is compared with the whole songbook; if it is already there (e.g. RH 257) you can compare side by side, keep the old one or use the new words."],
  ["Live on phones (2.3)", "settings", "Settings → Live song on phones: Church Wi-Fi (QR code) or Anywhere — the phone songbook’s ● Live button follows the projector."],
  ["Publish library (2.2)", "settings", "Settings → Team songbook → Publish: the approved songs go (locked) to GitHub; every computer and phone gets them by itself."],
];

export function guideView(root) {
  const page = h("div", { class: "pagepad guide" });
  root.appendChild(page);
  const key = () => "rw-check-" + new Date().toISOString().slice(0, 10);
  const done = () => { try { return new Set(JSON.parse(localStorage.getItem(key()) || "[]")); } catch { return new Set(); } };
  const toggle = (id) => { const d = done(); d.has(id) ? d.delete(id) : d.add(id); try { localStorage.setItem(key(), JSON.stringify([...d])); } catch { } render(); };

  function render() {
    page.innerHTML = "";
    const d = done();
    page.append(h("div", { class: "g-head" },
      h("div", {}, h("h2", {}, "How to run a service"), h("div", { class: "muted" }, "Four stages. On Sunday you only need the Produce page — everything else is preparation or one-time setup.")),
      h("button", { class: "btn ghost", onclick: () => { try { localStorage.removeItem(key()); } catch { } render(); } }, "Clear today’s ticks")));
    page.append(h("div", { class: "g-stages" }, ...STAGES.map((st, si) => h("div", { class: "g-stage", style: `--c:${st.c}` },
      h("div", { class: "g-num" }, String(si + 1)), h("div", { class: "g-t" }, st.t), h("div", { class: "g-sub" }, st.sub),
      h("div", { class: "g-steps" }, ...st.steps.map(([t, x, v], i) => {
        const id = st.k + i, on = d.has(id);
        return h("div", { class: "g-step" + (on ? " done" : "") },
          h("button", { class: "g-tick", title: "Tick when done", onclick: () => toggle(id) }, on ? "✓" : ""),
          h("div", { style: "flex:1;min-width:0" }, h("div", { class: "g-st" }, t), h("div", { class: "g-sx" }, x)),
          v ? h("button", { class: "btn sm ghost", onclick: go(v) }, "Open") : null);
      }))))));
    page.append(h("div", { class: "card col", style: "margin-top:16px" }, h("div", { class: "ct" }, "New in 2.1 – 2.3"),
      h("table", { class: "g-table" }, h("tbody", {}, ...NEW.map(([n, v, what]) => h("tr", {}, h("td", {}, h("a", { href: "#", onclick: (e) => { e.preventDefault(); go(v)(); } }, n)), h("td", {}, what)))))));
    page.append(h("div", { class: "card col", style: "margin-top:16px" }, h("div", { class: "ct" }, "Which page is for what"),
      h("table", { class: "g-table" }, h("tbody", {}, ...PAGES.map(([n, v, what, when]) => h("tr", {}, h("td", {}, h("a", { href: "#", onclick: (e) => { e.preventDefault(); go(v)(); } }, n)), h("td", {}, what), h("td", { class: "dim" }, when)))))));
    page.append(h("div", { class: "two", style: "margin-top:16px" },
      h("div", { class: "card col" }, h("div", { class: "ct" }, "Our setup"),
        h("ul", { class: "g-tips" },
          h("li", {}, "ATEM Mini Pro → MacBook by USB-C (picture + sound into OBS) and by Ethernet (so the app can switch cameras and control the sound)."),
          h("li", {}, "HDMI 1 Panasonic · 2 OBSBOT Tail Air 2 · 3 Blackmagic (events) · 4 spare. All cameras and the ATEM on the same format (1080p60, or 1080p50 if lights flicker). Camera on-screen info off."),
          h("li", {}, "OBSBOT Tiny 2 (events) → MacBook USB-C → OBS picture-in-picture “RW OBSBOT”. Its microphone stays off."),
          h("li", {}, "Mixer stream output (AUX) → ATEM Mic 2 — the only sound for YouTube. Camera audio off in the ATEM; in OBS only the ATEM audio."),
          h("li", {}, "OBSBOT cameras: aim and zoom with the remote or OBSBOT Center, then close OBSBOT Center during the stream."))),
      h("div", { class: "card col" }, h("div", { class: "ct" }, "Sound setup on the mixer (once)"),
        h("ul", { class: "g-tips" },
          h("li", {}, "Use a spare AUX (post-fader) as the “Stream” mix instead of Main L: pulpit mic and singers a little higher than in the room, band a little lower."),
          h("li", {}, "Feed the ATEM with an XLR → 3.5 mm cable that has an attenuator (or a small DI box); ATEM Mic 2 set to Line."),
          h("li", {}, "Loudest worship song: turn the AUX down until the ATEM Mic 2 meter peaks around −10 dB with the ATEM gain near 0. Then leave the AUX alone — the app does the rest."),
          h("li", {}, "If the app keeps showing “band much louder than usual”, the musicians are overplaying: press “🎵 Tell band” (shows on the stage display) or turn the AUX down 3 dB."),
          h("li", {}, "Open the stage display on a tablet/phone near the musicians: http://<this Mac>:7777/output.html?mode=stage (Settings shows the address).")))));
    page.append(h("div", { class: "two", style: "margin-top:16px" },
      h("div", { class: "card col" }, h("div", { class: "ct" }, "Keyboard (when not typing)"),
        h("div", { class: "g-keys" }, ...[["→ / Space", "next slide"], ["←", "previous"], ["B", "black screen"], ["L", "logo"], ["Esc", "clear text"], ["T", "lyrics/verses on stream"], ["1–9 / C", "jump to verse / chorus"], ["⌘0", "Produce page"]].map(([k, v]) => h("div", {}, h("span", { class: "kbd" }, k), " ", v)))),
      h("div", { class: "card col" }, h("div", { class: "ct" }, "Keep the stream smooth"),
        h("ul", { class: "g-tips" },
          h("li", {}, "Watch the health pill in the top bar: green is good. Amber/red means OBS is struggling — turn the program monitor off (button on the monitor) and close other apps."),
          h("li", {}, "Overlays that are not on screen pause themselves, so having many scenes is fine."),
          h("li", {}, "Don’t press “Reload all” overlays or “Build Revival scenes” during a stream — use “Fix blank ones”."),
          h("li", {}, "Open OBS before the app; if OBS restarts, the app reconnects by itself and only fixes overlays that are blank."),
          h("li", {}, "Use a wired network for the stream and the ATEM.")))));
  }
  render();
  return { onShow: render };
}
