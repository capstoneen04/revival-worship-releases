import { S, h, toast, modal, saveSong, uid, LANGS, present, showLowerCard } from "../core.js";
import { krutiToUnicode, looksLikeKruti } from "../krutidev.js";
import { romanize, capitalizeLines } from "../translit.js";
import { textToSections, sectionsToText } from "./songs.js";

import { OCR_LANGS, getWorker, prepCanvas, cleanOcr, smartMarkup } from "../ocr-core.js";
export { cleanOcr, smartMarkup } from "../ocr-core.js";

export function ocrView(root) {
  const langBoxes = Object.entries(OCR_LANGS).map(([k, v]) => { const cb = h("input", { type: "checkbox", value: k }); if (k === "hin" || k === "eng") cb.checked = true; return h("label", { class: "row", style: "gap:5px;cursor:pointer" }, cb, v); });
  const enhance = h("input", { type: "checkbox", checked: true });
  let rotate = 0;
  const fileIn = h("input", { type: "file", accept: "image/*", multiple: true, style: "display:none" });
  const drop = h("div", { class: "drop" }, h("div", { style: "font-size:15px;color:var(--text);margin-bottom:4px" }, "Drop photos of song pages here"), "or click to choose · JPG, PNG, HEIC screenshots · several at once is fine · you can also paste an image (⌘V)");
  const imgs = h("div", { class: "col" });
  const prog = h("div", { class: "progress" }, h("div", {}));
  const status = h("div", { class: "muted", style: "font-size:12px;min-height:18px" });
  const out = h("textarea", { class: "input", rows: 22, style: "font-family:var(--lyric);font-size:15px;width:100%", placeholder: "Recognised text appears here. You can edit it, or paste old Kruti Dev text and press “Fix Kruti Dev”." });
  let files = [];

  root.append(h("div", { class: "pagepad" }, h("div", { class: "two" },
    h("div", { class: "col" },
      h("div", { class: "card col" },
        h("div", { style: "font-weight:650;font-size:14px" }, "1 · Choose images"),
        drop, fileIn,
        h("div", { class: "row" }, h("span", { class: "muted" }, "Languages on the page:"), ...langBoxes),
        h("div", { class: "row" }, h("label", { class: "row", style: "gap:5px" }, enhance, "Improve contrast"), h("button", { class: "btn sm", onclick: () => { rotate = (rotate + 90) % 360; renderImgs(); } }, "Rotate ↻"), h("button", { class: "btn sm ghost", onclick: () => { files = []; renderImgs(); } }, "Remove images")),
        imgs),
      h("div", { class: "card col" }, h("div", { style: "font-weight:650;font-size:14px" }, "Tips"),
        h("div", { class: "muted", style: "font-size:12.5px;line-height:1.6" }, "Printed pages read well; handwriting less so — always check the result. Photograph straight-on in good light. Tick only the languages actually on the page: Hindi + English is the usual pair. Marathi uses the same script as Hindi, so tick Marathi for Marathi songs."))),
    h("div", { class: "col" },
      h("div", { class: "card col" },
        h("div", { class: "row" }, h("div", { style: "font-weight:650;font-size:14px;flex:1" }, "2 · Read and correct"), h("button", { class: "btn primary", id: "ocr-go", onclick: run }, "Read text from images")),
        prog, status, out,
        h("div", { class: "row" },
          h("button", { class: "btn sm", onclick: () => { out.value = krutiToUnicode(out.value); toast("Converted Kruti Dev → Unicode Hindi"); } }, "Fix Kruti Dev"),
          h("button", { class: "btn sm", onclick: () => { out.value = smartMarkup(out.value); } }, "Mark verses & chorus"),
          h("button", { class: "btn sm", onclick: () => { out.value = capitalizeLines(romanize(out.value)); } }, "Convert to Hinglish"),
          h("button", { class: "btn sm", onclick: async () => { await navigator.clipboard.writeText(out.value); toast("Copied"); } }, "Copy")),
        h("hr", { class: "sep" }),
        h("div", { style: "font-weight:650;font-size:14px" }, "3 · Use it"),
        h("div", { class: "row" },
          h("button", { class: "btn primary", onclick: saveAsSong }, "Save as new song"),
          h("button", { class: "btn", onclick: addToExisting }, "Add as language to a song"),
          h("button", { class: "btn live", onclick: () => { if (out.value.trim()) present({ type: "text", title: "", text: out.value.replace(/^\[.*\]$/gm, "") }); } }, "▶ Project as text"),
          h("button", { class: "btn", onclick: () => { const t = out.value.trim(); if (t) showLowerCard({ type: "text", lines: t.split("\n").filter(l => l && !/^\[/.test(l)).slice(0, 4) }); } }, "Lower third")))))));

  drop.onclick = () => fileIn.click();
  fileIn.onchange = () => addFiles([...fileIn.files]);
  drop.ondragover = e => { e.preventDefault(); drop.classList.add("over"); };
  drop.ondragleave = () => drop.classList.remove("over");
  drop.ondrop = e => { e.preventDefault(); drop.classList.remove("over"); addFiles([...e.dataTransfer.files].filter(f => f.type.startsWith("image/"))); };
  document.addEventListener("paste", e => {
    if (!root.classList.contains("on")) return;
    const items = [...(e.clipboardData?.items || [])].filter(i => i.type.startsWith("image/"));
    if (items.length) { e.preventDefault(); addFiles(items.map(i => i.getAsFile())); }
  });
  function addFiles(fs) { for (const f of fs) files.push({ file: f, url: URL.createObjectURL(f) }); renderImgs(); }
  function renderImgs() {
    imgs.innerHTML = "";
    files.forEach((f, i) => imgs.appendChild(h("div", { style: "position:relative" }, h("img", { class: "ocr-img", src: f.url, style: `transform:rotate(${rotate}deg)` }),
      h("button", { class: "btn sm", style: "position:absolute;top:6px;right:6px", onclick: () => { files.splice(i, 1); renderImgs(); } }, "✕"))));
  }
  async function run() {
    if (!files.length) { toast("Add an image first"); return; }
    const langs = langBoxes.map(l => l.querySelector("input")).filter(c => c.checked).map(c => c.value);
    if (!langs.length) { toast("Tick at least one language"); return; }
    const btn = root.querySelector("#ocr-go"); btn.disabled = true;
    const bar = prog.firstChild;
    try {
      status.textContent = "Loading OCR engine and language data…";
      const w = await getWorker(langs, m => { if (m.status) status.textContent = m.status.replace(/^./, c => c.toUpperCase()) + (m.progress ? ` ${Math.round(m.progress * 100)}%` : ""); if (m.status === "recognizing text") bar.style.width = Math.round(m.progress * 100) + "%"; });
      const texts = [];
      for (let i = 0; i < files.length; i++) {
        status.textContent = `Reading image ${i + 1} of ${files.length}…`;
        const img = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = files[i].url; });
        const canvas = prepCanvas(img, { enhance: enhance.checked, rotate });
        const { data } = await w.recognize(canvas);
        texts.push(cleanOcr(data.text, langs.includes("hin") || langs.includes("mar")));
      }
      let txt = texts.join("\n\n");
      if (looksLikeKruti(txt)) txt = krutiToUnicode(txt);
      out.value = txt; bar.style.width = "100%";
      status.textContent = `Done — ${txt.split("\n").filter(Boolean).length} lines. Check the text, then save it.`;
    } catch (e) { console.error(e); status.textContent = "OCR failed: " + e.message; }
    btn.disabled = false;
  }
  function detectLang(t) { if (/[ऀ-ॿ]/.test(t)) return langBoxes[2].querySelector("input").checked && !langBoxes[0].querySelector("input").checked ? "mr" : "hi"; if (/\b(não|você|coração|meu|minha|Senhor)\b/i.test(t)) return "pt"; if (/\b(el|los|mi|Señor|corazón|Dios)\b/.test(t)) return "es"; return "en"; }
  function saveAsSong() {
    const t = out.value.trim(); if (!t) { toast("Nothing to save"); return; }
    const markup = /^\[/m.test(t) ? t : smartMarkup(t);
    const firstLine = markup.split("\n").find(l => l && !/^\[/.test(l)) || "New song";
    const title = h("input", { class: "input", value: firstLine.replace(/[,।.]+$/, "") });
    const lang = h("select", { class: "input" }, ...Object.entries(LANGS).map(([k, v]) => h("option", { value: k }, v))); lang.value = detectLang(t);
    const book = h("input", { class: "input", placeholder: "Book & number, e.g. RH 97 (optional)" });
    const hl = h("input", { type: "checkbox", checked: true });
    modal("Save as new song", h("div", { class: "col" }, h("label", { class: "f" }, "Title", title), h("label", { class: "f" }, "Language", lang), h("label", { class: "f" }, "Book number", book), h("label", { class: "row", style: "gap:6px" }, hl, "Also create a Hinglish version (Hindi only)")),
      [{ label: "Cancel" }, { label: "Save", cls: "primary", fn: async () => {
        const secs = textToSections(markup);
        const song = { id: uid("s"), title: title.value.trim() || firstLine, lang: lang.value, key: "", tags: [], status: "review", source: "Image to text", books: [], versions: { [lang.value]: { title: title.value.trim() || firstLine, sections: secs } } };
        const bm = book.value.trim().match(/^([A-Za-z0-9]+)\s+(\d+)$/); if (bm) song.books.push({ book: bm[1].toUpperCase(), num: +bm[2] });
        if (lang.value === "hi" && hl.checked) song.versions["hi-Latn"] = { title: capitalizeLines(romanize(song.title)), auto: true, sections: secs.map(s => ({ label: s.label, lines: s.lines.map(l => capitalizeLines(romanize(l))) })) };
        await saveSong(song);
        toast("Song saved to the library");
        window.rwShow("songs"); window.rwViews?.songs?.select(song);
      } }]);
  }
  function addToExisting() {
    const t = out.value.trim(); if (!t) { toast("Nothing to add"); return; }
    const q = h("input", { class: "input", type: "search", placeholder: "Find the song…" });
    const res = h("div", { class: "list", style: "max-height:260px;overflow:auto;border:1px solid var(--line);border-radius:8px" });
    const lang = h("select", { class: "input" }, ...Object.entries(LANGS).map(([k, v]) => h("option", { value: k }, v))); lang.value = detectLang(t);
    let picked = null;
    q.oninput = () => { res.innerHTML = ""; S.index.search(q.value, { limit: 20 }).forEach(r => res.appendChild(h("div", { class: "item", onclick: (e) => { picked = r.song; res.querySelectorAll(".item").forEach(x => x.classList.remove("sel")); e.currentTarget.classList.add("sel"); } }, h("div", { class: "t" }, r.song.title)))); };
    modal("Add as a language version", h("div", { class: "col" }, q, res, h("label", { class: "f" }, "This text is in", lang)), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: async () => {
      if (!picked) { toast("Pick a song"); return false; }
      const markup = /^\[/m.test(t) ? t : smartMarkup(t);
      picked.versions[lang.value] = { title: picked.title, sections: textToSections(markup) };
      await saveSong(picked); toast(`${LANGS[lang.value]} added to “${picked.title}”`);
      window.rwShow("songs"); window.rwViews?.songs?.select(picked);
    } }]);
  }
  return {};
}
