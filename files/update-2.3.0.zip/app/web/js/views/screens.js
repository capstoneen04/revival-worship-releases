// "Start & End screens" — pick / upload the picture, place it, and control the background hymns.
import { S, h, saveSettings, toast, bus, native, DEFAULT_SETTINGS, modal } from "../core.js";
import { listPacks, packToTheme, themeToPack } from "../theme-packs.js";

const PRESETS = [
  { src: "assets/img/backgrounds/eagle.jpg", name: "Eagle", start: { zoom: 0.78, dx: -0.24, dy: 0.12 } },
  { src: "assets/img/backgrounds/cloud.jpg", name: "The Cloud", start: { zoom: 0.86, dx: -0.06, dy: 0.28 } },
  { src: "assets/img/backgrounds/pillar-of-fire.jpg", name: "Pillar of Fire", start: { zoom: 0.9, dx: 0, dy: 0.06 } },
];
const status = { start: {}, end: {} };
bus.on(m => { if (m.type === "music-status") { status[m.screen] = m; document.querySelectorAll(`[data-np="${m.screen}"]`).forEach(el => el.textContent = m.playing ? "♪ " + m.title : m.count ? "Music paused / waiting for the screen to go live" : "No music files yet"); } });

const THEME_KEYS = ["headline", "brandGold", "startPicture", "endPicture", "music", "endTitle", "endText", "meeting", "ticker", "startLabel", "themeThumb"];
export function snapshotTheme(name) { const b = S.settings.broadcast, t = { id: "th" + Date.now(), name }; for (const k of THEME_KEYS) t[k] = structuredClone(b[k] ?? null); return t; }
export async function applyTheme(t) { const b = S.settings.broadcast; for (const k of THEME_KEYS) if (t[k] !== undefined && t[k] !== null) b[k] = structuredClone(t[k]); else if (k === "brandGold") b[k] = ""; else if (k === "themeThumb") b[k] = { background: "", mood: "" }; S.settings.activeTheme = t.id; await saveSettings(); bus.send({ type: "music", cmd: "reload" }); }

export function screensCard() {
  let tab = "start";
  const body = h("div", { class: "col", style: "gap:10px" });
  const themeBox = h("div", { class: "col", style: "gap:8px" });
  const card = h("div", { class: "card col", style: "gap:8px" },
    h("div", { class: "row", style: "justify-content:space-between" }, h("div", { class: "ct" }, "Start & End screens"),
      h("div", { class: "seg" }, ...["start", "end"].map(k => h("button", { class: "btn sm", "data-tab": k, onclick: () => { tab = k; render(); } }, k === "start" ? "Starting Soon" : "Ending")))),
    themeBox, body);

  // ---------- themes: Sunday / conventions / events ----------
  let packs = [];
  async function loadPacks() { packs = (await listPacks()).map(({ dir, pack }) => packToTheme(dir, pack)); renderThemes(); }
  function renderThemes() {
    const st = S.settings, b = st.broadcast;
    st.themes ||= [];
    if (!st.themes.length) { const t = snapshotTheme("Sunday (regular)"); t.id = "sunday"; st.themes.push(t); st.activeTheme = "sunday"; saveSettings(); }
    themeBox.innerHTML = "";
    const all = [...st.themes, ...packs];
    const active = all.find(x => x.id === st.activeTheme);
    const sel = h("select", { class: "input", style: "flex:1;min-width:0", onchange: async e => { const t = all.find(x => x.id === e.target.value); if (t) { await applyTheme(t); toast("Theme: " + t.name); renderThemes(); render(); } } },
      h("optgroup", { label: "Saved in the app" }, ...st.themes.map(t => h("option", { value: t.id, selected: t.id === st.activeTheme }, t.name))),
      packs.length ? h("optgroup", { label: "Theme packs (Media/Themes)" }, ...packs.map(t => h("option", { value: t.id, selected: t.id === st.activeTheme }, "📦 " + t.name))) : null);
    const hl = b.headline ||= { a: "the", b: "EAGLES", c: "gathering", d: "TOGETHER" };
    const hin = (k, ph, w) => h("input", { class: "input", value: hl[k] || "", placeholder: ph, style: `width:${w}`, oninput: e => { hl[k] = e.target.value; save(); } });
    const color = h("input", { type: "color", value: b.brandGold || "#d4a24c", style: "width:44px;height:30px;border:0;background:none;padding:0", oninput: e => { b.brandGold = e.target.value; save(); } });
    const askName = (title, ph, cb) => { const n = h("input", { class: "input", placeholder: ph }); modal(title, h("div", { class: "col" }, n), [{ label: "Cancel" }, { label: "Save", cls: "primary", fn: async () => { if (!n.value.trim()) return false; await cb(n.value.trim()); } }]); };
    themeBox.append(
      h("div", { class: "ct2" }, "Theme — Sunday, convention or event"),
      h("div", { class: "row", style: "flex-wrap:nowrap" }, sel,
        h("button", { class: "btn sm ghost", title: "Look again for theme packs in Media/Themes", onclick: () => loadPacks().then(() => toast(`${packs.length} theme pack(s) found`)) }, "↻")),
      h("div", { class: "row" },
        h("button", { class: "btn sm", title: "Save the current pictures, headline, colour, music and ending text as a theme", onclick: () => askName("Save as a new theme", "e.g. Punjab Meetings 2026", async (nm) => { const t = snapshotTheme(nm); st.themes.push(t); st.activeTheme = t.id; await saveSettings(); renderThemes(); toast("Theme saved"); }) }, "Save as new…"),
        h("button", { class: "btn sm", disabled: !active || active.pack, title: active?.pack ? "Theme packs are edited as files — use Save as new to keep your changes" : "Update the selected theme with the current look", onclick: async () => { const i = st.themes.findIndex(x => x.id === st.activeTheme); if (i < 0) return; const t = snapshotTheme(st.themes[i].name); t.id = st.themes[i].id; st.themes[i] = t; await saveSettings(); toast("Theme updated"); } }, "Update"),
        h("button", { class: "btn sm ghost", title: "Write the current look as a theme pack (Media/Themes) — to share, back up or edit with the theme builder", onclick: () => askName("Export as a theme pack", "e.g. Punjab Meetings 2026", async (nm) => {
          const dir = nm.replace(/[^\w .()-]+/g, "_"), json = JSON.stringify(themeToPack(nm, S.settings.broadcast), null, 2);
          const r = await fetch(`/api/upload?path=${encodeURIComponent("Themes/" + dir + "/theme.json")}`, { method: "POST", body: new Blob([json], { type: "application/json" }) });
          toast(r.ok ? `Saved Media/Themes/${dir}` : "Export failed"); loadPacks();
        }) }, "Export pack…"),
        native?.openMediaFolder ? h("button", { class: "btn sm ghost", onclick: () => native.openMediaFolder("Themes") }, "Packs folder") : null,
        h("button", { class: "btn sm ghost", disabled: !active || active.pack || st.themes.length < 2, onclick: () => { const t = st.themes.find(x => x.id === st.activeTheme); if (!t) return;
          modal(`Delete theme “${t.name}”?`, h("p", { class: "muted" }, "Pictures and music files stay in the Media folder."), [{ label: "Cancel" }, { label: "Delete", cls: "live", fn: async () => { st.themes = st.themes.filter(x => x !== t); await applyTheme(st.themes[0]); renderThemes(); render(); } }]); } }, "Delete")),
      h("div", { class: "row", style: "flex-wrap:nowrap;gap:6px" }, hin("a", "the", "64px"), hin("b", "EAGLES", "120px"), hin("c", "gathering", "100px"), hin("d", "TOGETHER", "120px"), color),
      h("div", { class: "dim", style: "font-size:11px" }, "Starting Soon headline (small · BIG · small · BIG) and accent colour. For conventions, e.g. “the · PUNJAB · meetings · 2026”."));
  }
  loadPacks();
  renderThemes();

  const pkey = () => tab === "start" ? "startPicture" : "endPicture";
  const pic = () => (S.settings.broadcast[pkey()] ||= structuredClone(DEFAULT_SETTINGS.broadcast[pkey()]));
  const mus = () => { const b = S.settings.broadcast; b.music ||= structuredClone(DEFAULT_SETTINGS.broadcast.music); return (b.music[tab] ||= structuredClone(DEFAULT_SETTINGS.broadcast.music[tab])); };
  let saveT = null; const save = (fast) => { clearTimeout(saveT); saveT = setTimeout(saveSettings, fast ? 0 : 120); };

  async function render() {
    card.querySelectorAll("[data-tab]").forEach(b => b.classList.toggle("on", b.dataset.tab === tab));
    body.innerHTML = "";
    const p = pic(), m = mus();
    // --- picture ---
    let uploads = [];
    try { uploads = (await fetch("/api/media?dir=Pictures").then(r => r.json())).files; } catch { }
    const all = [...PRESETS, ...uploads.map(f => ({ src: f.url.replace(/^\//, ""), name: f.name.replace(/\.[^.]+$/, ""), mine: true }))];
    const strip = h("div", { class: "pics" });
    for (const it of all) {
      const on = p.src === it.src;
      strip.append(h("button", { class: "pic" + (on ? " on" : ""), title: it.name, onclick: () => { Object.assign(p, { src: it.src, zoom: it.start?.zoom ?? 1, dx: it.start?.dx ?? 0, dy: it.start?.dy ?? 0 }); save(true); render(); } },
        h("img", { src: "/" + it.src.replace(/^\//, ""), alt: "" }), h("span", {}, it.name)));
    }
    strip.append(h("button", { class: "pic" + (!p.src ? " on" : ""), onclick: () => { p.src = ""; save(true); render(); } }, h("div", { class: "none" }, "No picture"), h("span", {}, "None")));
    const file = h("input", { type: "file", accept: "image/*", style: "display:none", onchange: async e => {
      const f = e.target.files[0]; if (!f) return;
      const name = f.name.replace(/[^\w .()-]+/g, "_");
      try {
        const r = await fetch(`/api/upload?path=${encodeURIComponent("Pictures/" + name)}`, { method: "POST", body: f }).then(r => r.json());
        Object.assign(p, { src: r.url.replace(/^\//, ""), zoom: 1, dx: 0, dy: 0, layout: p.layout || "left" }); await saveSettings(); toast("Picture added"); render();
      } catch (er) { toast("Upload failed: " + er.message); }
    } });
    const slider = (label, key, min, max, step) => {
      const val = h("span", { class: "dim", style: "width:38px;text-align:right" }, String(p[key] ?? 0));
      const r = h("input", { type: "range", min, max, step, value: p[key] ?? (key === "zoom" ? 1 : 0), style: "flex:1", oninput: e => { p[key] = +e.target.value; val.textContent = e.target.value; save(); } });
      return h("label", { class: "row", style: "gap:8px;flex-wrap:nowrap" }, h("span", { class: "muted", style: "width:64px;font-size:12px" }, label), r, val);
    };
    body.append(
      h("div", { class: "ct2" }, "Picture"), strip,
      h("div", { class: "row" }, h("button", { class: "btn sm", onclick: () => file.click() }, "Upload picture…"), file,
        h("div", { class: "seg" }, ...[["left", "Left side"], ["full", "Full screen"]].map(([k, v]) => h("button", { class: "btn sm" + ((p.layout || "left") === k ? " on" : ""), onclick: () => { p.layout = k; save(true); render(); } }, v))),
        h("button", { class: "btn sm ghost", onclick: () => { const d = DEFAULT_SETTINGS.broadcast[pkey()]; Object.assign(p, structuredClone(d)); save(true); render(); } }, "Reset")),
      slider("Size", "zoom", 0.4, 1.8, 0.01), slider("Move ↔", "dx", -0.7, 0.7, 0.01), slider("Move ↕", "dy", -0.7, 0.7, 0.01), slider("Darken", "dim", 0, 0.7, 0.01));

    // --- music ---
    const vol = h("input", { type: "range", min: 0, max: 1, step: 0.01, value: m.volume ?? 0.55, style: "flex:1", oninput: e => { m.volume = +e.target.value; save(); } });
    const cmd = (c) => bus.send({ type: "music", screen: tab, cmd: c });
    let tracks = [];
    try { tracks = (await fetch(`/api/media?dir=${encodeURIComponent(m.dir || (tab === "end" ? "Music/End" : "Music/Start"))}`).then(r => r.json())).files.filter(f => /\.(mp3|m4a|aac|wav|ogg)$/i.test(f.name)); } catch { }
    const mfile = h("input", { type: "file", accept: "audio/*", multiple: true, style: "display:none", onchange: async e => {
      const dir = m.dir || (tab === "end" ? "Music/End" : "Music/Start");
      for (const f of e.target.files) { try { await fetch(`/api/upload?path=${encodeURIComponent(dir + "/" + f.name.replace(/[^\w .()'-]+/g, "_"))}`, { method: "POST", body: f }); } catch { } }
      toast(`${e.target.files.length} song(s) added`); cmd("reload"); render();
    } });
    let mdirs = [];
    try { mdirs = (await fetch("/api/media?dir=Music").then(r => r.json())).dirs; } catch { }
    const curDir = (m.dir || (tab === "end" ? "Music/End" : "Music/Start")).replace(/^Music\//, "");
    if (!mdirs.includes(curDir)) mdirs.push(curDir);
    const dirSel = h("select", { class: "input", style: "flex:1", onchange: e => {
      if (e.target.value === "__new") {
        const n = h("input", { class: "input", placeholder: "e.g. Punjab Meetings" });
        modal("New music folder", n, [{ label: "Cancel", fn: () => render() }, { label: "Create", cls: "primary", fn: () => { if (!n.value.trim()) return false; m.dir = "Music/" + n.value.trim().replace(/[^\w .()-]+/g, "_"); save(true); toast("Folder ready — now press Add songs…"); render(); } }]);
        return;
      }
      m.dir = "Music/" + e.target.value; save(true); setTimeout(() => { cmd("reload"); render(); }, 200);
    } }, ...mdirs.map(d => h("option", { value: d, selected: d === curDir }, "Music / " + d)), h("option", { value: "__new" }, "+ New folder…"));
    const np = h("div", { class: "dim", "data-np": tab, style: "font-size:12px" }, status[tab].playing ? "♪ " + status[tab].title : `${tracks.length} hymns ready — they play while this screen is on air in OBS`);
    body.append(
      h("div", { class: "ct2", style: "margin-top:6px" }, "Background hymns"),
      h("div", { class: "row" },
        h("label", { class: "row", style: "gap:6px" }, h("input", { type: "checkbox", checked: m.on !== false, onchange: e => { m.on = e.target.checked; save(true); } }), "Play music"),
        h("label", { class: "row", style: "gap:6px" }, h("input", { type: "checkbox", checked: m.shuffle !== false, onchange: e => { m.shuffle = e.target.checked; save(true); } }), "Shuffle"),
        h("label", { class: "row", style: "gap:6px" }, h("input", { type: "checkbox", checked: m.title !== false, onchange: e => { m.title = e.target.checked; save(true); } }), "Show song name")),
      h("label", { class: "row", style: "gap:8px;flex-wrap:nowrap" }, h("span", { class: "muted", style: "width:64px;font-size:12px" }, "Folder"), dirSel),
      h("label", { class: "row", style: "gap:8px;flex-wrap:nowrap" }, h("span", { class: "muted", style: "width:64px;font-size:12px" }, "Volume"), vol),
      h("div", { class: "row" },
        h("button", { class: "btn sm", onclick: () => cmd("pause") }, "❚❚ Pause"), h("button", { class: "btn sm", onclick: () => cmd("play") }, "▶ Play"), h("button", { class: "btn sm", onclick: () => cmd("next") }, "⏭ Next"),
        h("button", { class: "btn sm", onclick: () => mfile.click() }, "Add songs…"), mfile,
        native?.openMediaFolder ? h("button", { class: "btn sm ghost", onclick: () => native.openMediaFolder(m.dir || (tab === "end" ? "Music/End" : "Music/Start")) }, "Open folder") : null),
      np,
      h("details", {}, h("summary", { class: "dim", style: "font-size:12px;cursor:pointer" }, `Song list (${tracks.length})`),
        h("div", { class: "col", style: "gap:2px;margin-top:6px;max-height:160px;overflow:auto" }, ...tracks.map(t => h("div", { class: "row", style: "justify-content:space-between;font-size:12px" }, h("span", {}, t.name.replace(/\.[^.]+$/, "")),
          h("button", { class: "btn sm ghost", title: "Move to Media/Removed", onclick: async () => { await fetch(`/api/media-remove?path=${encodeURIComponent(decodeURI(t.url.replace(/^\/media\//, "")))}`, { method: "POST" }); cmd("reload"); render(); } }, "Remove"))))),
      h("div", { class: "dim", style: "font-size:11px" }, "The hymns provided are public-domain tunes we recorded ourselves (piano & strings), so YouTube won’t flag them. You can add your own MP3s, e.g. from the YouTube Audio Library."));
    bus.send({ type: "music", screen: tab, cmd: "status" });
  }
  render();
  return card;
}
