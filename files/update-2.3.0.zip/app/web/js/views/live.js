import { S, h, db, buildSlides, present, go, next, prev, toggleOverride, toggleLowerFollow, showLowerCard, hideLower, broadcast, itemTitle, songById, saveService, onChange, openOutput, LANGS, uid, toast, timerStart, timerPause, timerReset, timerText } from "../core.js";
import { transposeKey, songHasChords } from "../chords.js";
import { itemSub, ICON, quickSongSearch, promptBible, promptCard } from "./service.js";

export function liveView(root) {
  let selItem = null, selSlides = [];
  const itemsEl = h("div", { class: "scroll" });
  const grid = h("div", { class: "slide-grid" });
  const slidesHead = h("div", { class: "panel-h", style: "background:var(--panel)" });
  const previewFrame = h("iframe", { src: "output.html?mode=preview", tabindex: "-1" });
  const lowerFrame = h("iframe", { src: "obs/lower-third.html", tabindex: "-1" });
  const screen1 = h("div", { class: "screen" }, h("span", { class: "badge pill live" }, h("span", { class: "dot" }), "PROJECTOR"), previewFrame);
  const screen2 = h("div", { class: "screen", style: "background:repeating-conic-gradient(#1a1d24 0 25%, #14161b 0 50%) 0 0/24px 24px" }, h("span", { class: "badge pill" }, h("span", { class: "dot" }), "OBS LOWER THIRD"), lowerFrame);
  const ctl = h("div", { class: "ctl-grid" });
  const people = h("div", { class: "row", style: "gap:6px" });
  const stageMsg = h("input", { class: "input", placeholder: "Message to stage display…", style: "flex:1" });
  const audMsg = h("input", { class: "input", placeholder: "e.g. Parking car MH05 AB 1234 please move", style: "flex:1" });
  const recentEl = h("div", { class: "row", style: "gap:4px" });
  const timerBox = h("div", { class: "row", style: "gap:6px" });
  const mins = h("input", { class: "input", type: "number", min: 1, max: 240, value: S.settings.timers?.sermonMinutes || 45, style: "width:70px;height:28px" });
  const tLab = h("b", { style: "font-variant-numeric:tabular-nums;min-width:64px" }, "");
  timerBox.append(mins, h("span", { class: "dim" }, "min"),
    h("button", { class: "btn sm", onclick: () => { S.settings.timers = { ...(S.settings.timers || {}), sermonMinutes: +mins.value || 45 }; timerStart(S.timer && !S.timer.running ? null : +mins.value); } }, "▶ Start"),
    h("button", { class: "btn sm", onclick: () => timerPause() }, "Pause"), h("button", { class: "btn sm ghost", onclick: () => timerReset() }, "Reset"), tLab);
  setInterval(() => { tLab.textContent = timerText(); }, 1000);
  function renderRecent() {
    recentEl.innerHTML = "";
    const r = (S.settings.recent || []).slice(0, 12);
    if (!r.length) { recentEl.append(h("span", { class: "dim", style: "font-size:11.5px" }, "Songs and verses you show appear here.")); return; }
    for (const x of r) { const it = x.item; const t = it.type === "song" ? (songById(it.songId)?.title || "song") : (it.label || "verse");
      recentEl.append(h("button", { class: "btn sm", title: "Show again", onclick: () => { present({ ...it, id: uid("rc") }); } }, (it.type === "song" ? "♪ " : "B ") + t.slice(0, 28))); }
  }
  root.append(
    h("div", { class: "panel items" },
      h("div", { class: "panel-h" }, h("h2", { style: "flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" }, S.service?.name || "Service"), h("button", { class: "btn sm ghost", onclick: () => window.rwShow("service") }, "Edit")),
      h("div", { style: "padding:8px 10px;border-bottom:1px solid var(--line)" }, quickSongSearch(s => { const it = { id: uid("it"), type: "song", songId: s.id }; S.service.items.push(it); saveService(); selectItem(it); }, "Quick add song…"),
        h("div", { class: "row", style: "margin-top:6px;gap:4px" },
          h("button", { class: "btn sm", onclick: () => promptBible(it => { it.id = uid("it"); S.service.items.push(it); saveService(); selectItem(it); }) }, "+ Verse"),
          h("button", { class: "btn sm", onclick: () => promptCard("message", it => { it.id = uid("it"); S.service.items.push(it); saveService(); selectItem(it); }) }, "+ Quote"),
          h("button", { class: "btn sm", onclick: () => promptCard("text", it => { it.id = uid("it"); S.service.items.push(it); saveService(); selectItem(it); }) }, "+ Text"))),
      itemsEl),
    h("div", { class: "slides" }, slidesHead, h("div", { class: "scroll" }, grid)),
    h("div", { class: "panel monitor" },
      h("div", { class: "scroll", style: "padding:12px;display:flex;flex-direction:column;gap:12px" },
        screen1,
        ctl,
        screen2,
        h("div", { class: "row", style: "gap:6px" },
          h("button", { class: "btn sm", id: "lt-follow", onclick: () => toggleLowerFollow() }, "Lyrics & verses → OBS"),
          h("button", { class: "btn sm", onclick: () => hideLower() }, "Hide lower third")),
        h("div", { class: "section-title", style: "margin:4px 0 0" }, "Name cards"), people,
        h("div", { class: "section-title", style: "margin:4px 0 0" }, "Sermon timer (stage display)"), timerBox,
        h("div", { class: "section-title", style: "margin:4px 0 0" }, "Message on the projector (audience)"),
        h("div", { class: "row", style: "flex-wrap:nowrap" }, audMsg, h("button", { class: "btn sm", onclick: () => { S.audienceMessage = audMsg.value; broadcast(); } }, "Show"), h("button", { class: "btn sm ghost", onclick: () => { audMsg.value = ""; S.audienceMessage = ""; broadcast(); } }, "Hide")),
        h("div", { class: "section-title", style: "margin:4px 0 0" }, "Recent songs & verses"), recentEl,
        h("div", { class: "section-title", style: "margin:4px 0 0" }, "Stage display message"),
        h("div", { class: "row", style: "flex-wrap:nowrap" }, stageMsg, h("button", { class: "btn sm", onclick: () => { S.stageMessage = stageMsg.value; broadcast(); } }, "Send"), h("button", { class: "btn sm ghost", onclick: () => { stageMsg.value = ""; S.stageMessage = ""; broadcast(); } }, "Clear")),
        h("div", { class: "row", style: "gap:6px" }, h("button", { class: "btn sm", onclick: () => openOutput("projector") }, "Open projector"), h("button", { class: "btn sm", onclick: () => openOutput("stage") }, "Open stage display")),
        h("div", { class: "dim", style: "font-size:11.5px" }, h("span", { class: "kbd" }, "→"), " next  ", h("span", { class: "kbd" }, "←"), " back  ", h("span", { class: "kbd" }, "B"), " blank  ", h("span", { class: "kbd" }, "L"), " logo  ", h("span", { class: "kbd" }, "Esc"), " clear  ", h("span", { class: "kbd" }, "C"), " chorus  ", h("span", { class: "kbd" }, "1-9"), " verse  ", h("span", { class: "kbd" }, "T"), " lower third"))));

  const scaleFrames = () => { for (const s of [screen1, screen2]) { const f = s.querySelector("iframe"); f.style.transform = `scale(${s.clientWidth / 1920})`; } };
  new ResizeObserver(scaleFrames).observe(screen1);

  const ctlBtns = {};
  [["prev", "◀ Back", () => prev()], ["next", "Next ▶", () => next(), "primary"], ["blank", "Blank", () => toggleOverride("blank")], ["logo", "Logo", () => toggleOverride("logo")], ["clear", "Clear", () => toggleOverride("clear")], ["camera", "Camera", () => toggleOverride("camera")]].forEach(([k, label, fn, cls]) => {
    ctlBtns[k] = h("button", { class: "btn " + (cls || ""), onclick: fn }, label); ctl.appendChild(ctlBtns[k]);
  });
  ctlBtns.next.style.gridColumn = "span 2";

  let peopleTok = 0;
  async function renderPeople() {
    const tok = ++peopleTok;
    const ps = await (await import("../people.js")).people();
    if (tok !== peopleTok) return;
    people.innerHTML = "";
    ps.forEach(p => people.appendChild(h("button", { class: "btn sm", title: p.role, onclick: () => showLowerCard({ type: "name", name: p.name, role: p.details || p.role }) }, p.name)));
    people.appendChild(h("button", { class: "btn sm ghost", onclick: async () => (await import("../people.js")).openPeopleEditor() }, "Manage…"));
  }

  function renderItems() {
    itemsEl.innerHTML = "";
    const items = S.service?.items || [];
    if (!items.length) itemsEl.appendChild(h("div", { class: "empty" }, "No items yet. Use quick add above or plan the service first."));
    items.forEach((it, i) => it.type === "header" ? itemsEl.appendChild(h("div", { class: "svc-head mini" }, it.title)) : itemsEl.appendChild(h("div", {
      class: "svc-item" + (selItem && selItem.id === it.id ? " sel" : "") + (S.live.key === it.id ? " onair" : ""),
      onclick: () => selectItem(it), ondblclick: () => { present(it, 0, { fromService: true }); },
    }, h("div", { class: "ic " + it.type }, ICON[it.type]), h("div", { style: "min-width:0;flex:1" }, h("div", { class: "tt" }, itemTitle(it)), h("div", { class: "st" }, itemSub(it))),
      S.live.key === it.id ? h("span", { class: "pill live", style: "height:18px" }, "LIVE") : null)));
  }

  async function selectItem(it) {
    selItem = it;
    if (it.type === "name" || it.type === "title") { selSlides = []; showLowerCard(it); }
    else selSlides = await buildSlides(it);
    renderItems(); renderSlides();
  }

  function renderSlides() {
    slidesHead.innerHTML = ""; grid.innerHTML = "";
    if (!selItem) { slidesHead.appendChild(h("span", { class: "muted" }, "Pick an item on the left. Click a slide to put it on screen.")); return; }
    slidesHead.appendChild(h("div", { style: "font-family:var(--lyric);font-weight:650;font-size:15px;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" }, itemTitle(selItem)));
    if (selItem.type === "song") {
      const song = songById(selItem.songId);
      if (song) {
        const mk = (key, none) => { const sel = h("select", { class: "input", style: "height:28px" }, none ? h("option", { value: "" }, "— single language —") : null, ...Object.keys(song.versions).map(l => h("option", { value: l }, LANGS[l] || l))); sel.value = selItem[key] ?? (key === "lang1" ? Object.keys(song.versions)[0] : ""); sel.onchange = async () => { selItem[key] = sel.value; saveService(); selSlides = await buildSlides(selItem); renderSlides(); if (S.live.key === selItem.id) present(selItem, Math.min(S.live.index, selSlides.length - 1), { fromService: S.live.fromService }); }; return sel; };
        slidesHead.append(h("span", { class: "dim" }, "Language"), mk("lang1"), h("span", { class: "dim" }, "+"), mk("lang2", true));
        const lps = h("select", { class: "input", style: "height:28px;width:70px", title: "Lines per slide" }, ...[2, 3, 4, 5, 6, 8].map(n => h("option", { value: n }, n + " ln")));
        lps.value = selItem.linesPerSlide || S.settings.linesPerSlide;
        lps.onchange = async () => { selItem.linesPerSlide = +lps.value; saveService(); selSlides = await buildSlides(selItem); renderSlides(); };
        const ac = h("button", { class: "btn sm" + ((selItem.autoChorus ?? S.settings.autoChorus) ? " on" : ""), title: "Repeat the chorus after every verse", onclick: async () => { selItem.autoChorus = !(selItem.autoChorus ?? S.settings.autoChorus); saveService(); selSlides = await buildSlides(selItem); renderSlides(); } }, "Repeat chorus");
        slidesHead.append(lps, ac);
        if (songHasChords(song) || song.key) {
          const tr = selItem.transpose || 0;
          const setTr = (d) => { selItem.transpose = (selItem.transpose || 0) + d; saveService(); broadcast(); renderSlides(); };
          slidesHead.append(h("span", { class: "dim", title: "Key for the musicians' stage display" }, "Key"), h("button", { class: "btn sm", onclick: () => setTr(-1) }, "−"), h("b", {}, transposeKey(song.key || "", tr) || (tr ? (tr > 0 ? "+" : "") + tr : "—")), h("button", { class: "btn sm", onclick: () => setTr(1) }, "+"));
        }
      }
    }
    slidesHead.append(h("button", { class: "btn live sm", onclick: () => present(selItem, 0, { fromService: true }) }, "▶ Go live"));
    const isLiveItem = S.live.key === selItem.id;
    selSlides.forEach((sl, i) => {
      const live = isLiveItem && !S.live.override && S.live.index === i;
      const nxt = isLiveItem && S.live.index + 1 === i;
      grid.appendChild(h("div", { class: "thumb" + (live ? " live" : "") + (nxt ? " next" : ""), style: sl.color ? `--sc:${sl.color}` : "", onclick: () => { if (isLiveItem) go(i); else present(selItem, i, { fromService: true }); } },
        h("div", {}, ...(sl.lines || []).map(l => h("div", { class: "tl" }, l)), ...(sl.lines2 || []).map(l => h("div", { class: "tl2" }, l))),
        h("div", { class: "lab" }, h("span", { class: sl.color ? "sec" : "" }, sl.label || ""), h("span", { class: "k" }, String(i + 1)))));
    });
    if (!selSlides.length) grid.appendChild(h("div", { class: "empty" }, selItem.type === "name" || selItem.type === "title" ? "Shown as an OBS lower third." : "Nothing to show."));
    grid.querySelector(".thumb.live")?.scrollIntoView({ block: "nearest" });
  }

  let lastLiveKey = null;
  function syncLive(what) {
    for (const k of ["blank", "logo", "clear", "camera"]) ctlBtns[k].classList.toggle("on", S.live.override === k);
    root.querySelector("#lt-follow").classList.toggle("on", S.lowerFollow);
    if (what === "live" && S.live.item && S.live.key !== lastLiveKey) { selItem = S.live.item; selSlides = S.live.slides; }
    lastLiveKey = S.live.key;
    if (selItem && S.live.key === selItem.id) selSlides = S.live.slides;
    renderItems(); renderSlides();
  }
  onChange(w => { if (w === "live" || w === "lower") { syncLive(w); if (w === "live") renderRecent(); } if (w === "service") renderItems(); });
  renderRecent();
  renderItems(); renderSlides(); renderPeople();
  return { onShow() { renderItems(); renderPeople(); setTimeout(scaleFrames, 30); if (!selItem && S.live.item) { selItem = S.live.item; selSlides = S.live.slides; renderSlides(); } } };
}
