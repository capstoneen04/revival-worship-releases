import { S, h, db, uid, saveService, switchService, newService, itemTitle, songById, present, toast, modal, LANGS, onChange, addToService } from "../core.js";
import { parseRef, refLabel, loadBible, setHindiNames, bibleName } from "../bible.js";

export function itemSub(it) {
  if (it.type === "song") { const s = songById(it.songId); const b = s?.books?.[0]; return [b ? `${b.book} ${b.num}` : "", it.lang1 ? LANGS[it.lang1] : "", it.lang2 ? "+ " + LANGS[it.lang2] : ""].filter(Boolean).join(" · ") || "Song"; }
  if (it.type === "bible") return "Scripture · " + bibleName(it.version || S.settings.bibleVersion || "both");
  if (it.type === "message") return [it.code, it.para ? "¶" + it.para : ""].filter(Boolean).join(" ") || "Quote";
  if (it.type === "name") return "Name card · " + (it.role || "");
  if (it.type === "title") return "Title card";
  if (it.type === "text") return "Text / announcement";
  if (it.type === "sermon") return "Title · Subject · Inspiration · Scripture (EN + हिंदी)";
  if (it.type === "media") return it.video ? "Video on the projector" + (it.loop ? " · loop" : "") : "Picture on the projector";
  if (it.type === "header") return "Section";
  return "";
}
export const ICON = { song: "♪", bible: "B", message: "M", name: "N", title: "T", text: "Aa", sermon: "S", media: "▣", header: "§" };

export function quickSongSearch(onPick, placeholder = "Add a song: number, title or any line…") {
  const wrap = h("div", { style: "position:relative" });
  const input = h("input", { class: "input", type: "search", placeholder, style: "width:100%" });
  let box = null, hits = [], hl = 0;
  const close = () => { box?.remove(); box = null; };
  const render = () => {
    close(); if (!input.value.trim()) return;
    hits = S.index.search(input.value, { limit: 12 });
    box = h("div", { class: "quick-results", style: "top:36px;left:0;right:0" }, ...hits.map((r, i) => h("div", { class: "item" + (i === hl ? " hl" : ""), onmousedown: e => { e.preventDefault(); pick(r.song); } },
      h("div", { style: "font-family:var(--lyric);font-weight:550" }, r.song.title), h("div", { class: "dim", style: "font-size:11.5px" }, (r.song.books || []).slice(0, 3).map(b => `${b.book} ${b.num}`).join(" · ")))));
    if (!hits.length) box.appendChild(h("div", { class: "item dim" }, "No match"));
    wrap.appendChild(box);
  };
  const pick = (s) => { onPick(s); input.value = ""; close(); };
  input.oninput = () => { hl = 0; render(); };
  input.onblur = () => setTimeout(close, 150);
  input.onkeydown = e => {
    if (e.key === "ArrowDown") { e.preventDefault(); hl = Math.min(hits.length - 1, hl + 1); render(); }
    if (e.key === "ArrowUp") { e.preventDefault(); hl = Math.max(0, hl - 1); render(); }
    if (e.key === "Enter" && hits[hl]) pick(hits[hl].song);
    if (e.key === "Escape") { input.value = ""; close(); }
  };
  wrap.appendChild(input);
  return wrap;
}

export async function promptBible(onDone) {
  const kjv = await loadBible("kjv"); const hin = await loadBible("hindi"); setHindiNames(hin.books);
  const inp = h("input", { class: "input", placeholder: "e.g. jn 3 16  ·  Rev 10 1-7  ·  रोमियों 8:28" });
  const ver = h("select", { class: "input" }, h("option", { value: "both" }, bibleName("both")), h("option", { value: "kjv" }, bibleName("kjv")), h("option", { value: "hindi" }, bibleName("hindi")));
  ver.value = S.settings.bibleVersion;
  const prevw = h("div", { class: "muted", style: "min-height:20px" });
  inp.oninput = () => { const r = parseRef(inp.value); prevw.textContent = r ? refLabel(kjv, r) + " · " + refLabel(hin, r) : "…"; };
  modal("Add scripture", h("div", { class: "col" }, h("label", { class: "f" }, "Reference", inp), prevw, h("label", { class: "f" }, "Version", ver)),
    [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { const r = parseRef(inp.value); if (!r) { toast("Couldn't read that reference"); return false; } onDone({ type: "bible", ref: r, version: ver.value, label: refLabel(kjv, r) }); } }]);
  setTimeout(() => inp.focus(), 50);
}

export function promptCard(type, onDone) {
  if (type === "name") {
    const sel = h("select", { class: "input" }, h("option", { value: "" }, "— choose a saved person —"));
    db.all("people").then(ps => ps.forEach(p => sel.appendChild(h("option", { value: p.id }, `${p.name} — ${p.role}`))));
    const n = h("input", { class: "input", placeholder: "Name" }), r = h("input", { class: "input", placeholder: "Role (Song Leader, Pastor…)" });
    sel.onchange = async () => { const p = await db.get("people", sel.value); if (p) { n.value = p.name; r.value = p.role; } };
    modal("Name card (lower third)", h("div", { class: "col" }, sel, n, r), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!n.value) return false; onDone({ type: "name", name: n.value, role: r.value }); } }]);
  } else if (type === "title") {
    const t = h("input", { class: "input", placeholder: "Sermon or meeting title" }), s = h("input", { class: "input", placeholder: "Speaker / subtitle (optional)" });
    modal("Title card (lower third)", h("div", { class: "col" }, t, s), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!t.value) return false; onDone({ type: "title", title: t.value, subtitle: s.value }); } }]);
  } else if (type === "text") {
    const t = h("input", { class: "input", placeholder: "Heading (optional)" }), x = h("textarea", { class: "input", rows: 8, placeholder: "Announcement or any text. Blank line = new slide." });
    modal("Text slide", h("div", { class: "col" }, t, x), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!x.value.trim()) return false; onDone({ type: "text", title: t.value, text: x.value }); } }]);
  } else if (type === "message") {
    const x = h("textarea", { class: "input", rows: 7, placeholder: "Paste the quote" }), t = h("input", { class: "input", placeholder: "Sermon title" }), c = h("input", { class: "input", placeholder: "Date code e.g. 65-1127B", style: "width:180px" }), p = h("input", { class: "input", placeholder: "¶", style: "width:70px" });
    modal("Message quote", h("div", { class: "col" }, x, t, h("div", { class: "row" }, c, p)), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!x.value.trim()) return false; onDone({ type: "message", text: x.value.trim(), title: t.value, code: c.value, para: p.value }); } }]);
  }
}

export function promptHeader(onDone) {
  const t = h("input", { class: "input", placeholder: "e.g. Music Set 1 · Sermon · Music Set 2 · Announcements" });
  modal("Heading", h("div", { class: "col" }, t), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { if (!t.value.trim()) return false; onDone({ type: "header", title: t.value.trim() }); } }]);
  setTimeout(() => t.focus(), 50);
}
export async function promptMedia(onDone) {
  const pics = await fetch("/api/media?dir=Pictures").then(r => r.json()).catch(() => ({ files: [] }));
  const vids = await fetch("/api/media?dir=Videos").then(r => r.json()).catch(() => ({ files: [] }));
  const all = [...(vids.files || []).map(f => ({ ...f, video: true })), ...(pics.files || []).map(f => ({ ...f, video: false }))];
  const sel = h("select", { class: "input" }, ...all.map((f, i) => h("option", { value: i }, (f.video ? "🎬 " : "🖼 ") + f.name)));
  const loop = h("input", { type: "checkbox" });
  const body = h("div", { class: "col" },
    all.length ? sel : h("div", { class: "warnline" }, "No pictures or videos yet. Put them in Documents › Revival Church › Revival Worship App › Media › Pictures or Videos."),
    h("label", { class: "row", style: "gap:6px" }, loop, "Loop the video (e.g. a countdown or announcement loop)"),
    h("div", { class: "muted", style: "font-size:12px" }, "Videos play with sound through this computer's audio (send it to the mixer if needed)."),
    h("button", { class: "btn ghost sm", onclick: () => window.revival?.openMediaFolder?.("Videos") }, "Open Videos folder"));
  modal("Picture or video", body, [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: () => { const f = all[+sel.value]; if (!f) return false; onDone({ type: "media", src: f.url, title: f.name.replace(/\.[^.]+$/, ""), video: f.video, loop: loop.checked }); } }]);
}
export function printService() {
  const esc = (x) => String(x ?? "").replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  let n = 0;
  const rows = S.service.items.map(it => {
    if (it.type === "header") return `<tr class="hd"><td colspan="4">${esc(it.title)}</td></tr>`;
    const s = it.type === "song" ? songById(it.songId) : null;
    const b = s?.books?.[0];
    return `<tr><td>${++n}</td><td><b>${esc(itemTitle(it))}</b>${s?.author ? `<div class="m">${esc(s.author)}</div>` : ""}</td><td>${esc(s ? [b ? b.book + " " + b.num : "", s.key ? "Key " + s.key : "", it.order || s.order || ""].filter(Boolean).join(" · ") : itemSub(it))}</td><td>${esc(s?.notes || "")}</td></tr>`;
  }).join("");
  const w = window.open("", "_blank", "width=900,height=1000");
  if (!w) { toast("Allow pop-ups to print"); return; }
  w.document.write(`<!doctype html><meta charset="utf-8"><title>${esc(S.service.name)}</title><style>body{font:14px/1.45 -apple-system,'Noto Sans Devanagari',sans-serif;margin:28px;color:#111}h1{margin:0;font-size:22px}.d{color:#555;margin:2px 0 16px}table{width:100%;border-collapse:collapse}td{border-bottom:1px solid #ddd;padding:7px 6px;vertical-align:top}td:first-child{width:28px;color:#777}.hd td{background:#f1efe8;font-weight:700;letter-spacing:.04em;text-transform:uppercase;font-size:12px}.m{color:#666;font-size:12px}@media print{button{display:none}}</style>
    <h1>${esc(S.service.name)}</h1><div class="d">${esc(S.service.date || "")} · ${esc(S.settings.churchName || "")}</div><table>${rows}</table><p><button onclick="print()">Print / Save as PDF</button></p>`);
  w.document.close();
}

export function serviceView(root) {
  const svcList = h("div", { class: "scroll list" });
  const items = h("div", { class: "scroll" });
  const nameIn = h("input", { class: "input", style: "font-weight:600;font-size:15px;flex:1" });
  const dateIn = h("input", { class: "input", type: "date" });
  nameIn.onchange = () => { S.service.name = nameIn.value; saveService(); renderSvcs(); };
  dateIn.onchange = () => { S.service.date = dateIn.value; saveService(); renderSvcs(); };
  const add = (it) => { it.id = uid("it"); S.service.items.push(it); saveService(); renderItems(); };
  root.append(
    h("div", { class: "panel", style: "width:280px;flex:0 0 280px" },
      h("div", { class: "panel-h" }, h("h2", {}, "Services"), h("span", { style: "flex:1" }), h("button", { class: "btn sm", onclick: async () => { const s = newService("New service"); await db.put("services", s); await switchService(s); renderAll(); } }, "+ New")),
      svcList),
    h("div", { style: "flex:1;display:flex;flex-direction:column;min-width:0" },
      h("div", { class: "panel-h", style: "background:var(--panel)" }, nameIn, dateIn,
        h("button", { class: "btn", onclick: async () => { const c = structuredClone(S.service); c.id = uid("svc"); c.name += " (copy)"; c.items.forEach(i => (i.id = uid("it"))); await db.put("services", c); await switchService(c); renderAll(); } }, "Duplicate"),
        h("button", { class: "btn ghost", onclick: () => modal("Delete this service?", h("p", { class: "muted" }, S.service.name), [{ label: "Cancel" }, { label: "Delete", cls: "live", fn: async () => { await db.del("services", S.service.id); const all = await db.all("services"); await switchService(all[0] || newService()); if (!all.length) await db.put("services", S.service); renderAll(); } }]) }, "Delete"),
        h("button", { class: "btn primary", onclick: () => { window.rwShow("live"); } }, "Present ▶")),
      h("div", { class: "panel-h", style: "background:var(--panel)" },
        h("div", { style: "flex:1;min-width:260px" }, quickSongSearch(s => add({ type: "song", songId: s.id }))),
        h("button", { class: "btn", onclick: () => promptBible(add) }, "+ Scripture"),
        h("button", { class: "btn", onclick: () => promptCard("message", add) }, "+ Quote"),
        h("button", { class: "btn", onclick: () => promptCard("name", add) }, "+ Name card"),
        h("button", { class: "btn", onclick: () => promptCard("title", add) }, "+ Title card"),
        h("button", { class: "btn", onclick: () => promptCard("text", add) }, "+ Text"),
        h("button", { class: "btn", onclick: () => promptMedia(add) }, "+ Picture/Video"),
        h("button", { class: "btn", title: "Group heading, e.g. Music Set 1, Sermon", onclick: () => promptHeader(add) }, "+ Heading"),
        h("button", { class: "btn ghost", title: "Print or save as PDF for the team", onclick: () => printService() }, "Print")),
      items));

  async function renderSvcs() {
    const all = (await db.all("services")).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    svcList.innerHTML = "";
    for (const s of all) svcList.appendChild(h("div", { class: "item" + (s.id === S.service.id ? " sel" : ""), onclick: async () => { await switchService(s); renderAll(); } },
      h("div", { style: "flex:1;min-width:0" }, h("div", { style: "font-weight:600" }, s.name), h("div", { class: "s" }, `${s.date || ""} · ${s.items.length} items`))));
  }
  function renderItems() {
    nameIn.value = S.service.name; dateIn.value = S.service.date || "";
    items.innerHTML = "";
    if (!S.service.items.length) { items.appendChild(h("div", { class: "empty" }, "Empty service. Add songs with the search box above, then scripture, quotes and name cards.")); return; }
    S.service.items.forEach((it, i) => {
      const song = it.type === "song" ? songById(it.songId) : null;
      if (it.type === "header") {
        items.appendChild(h("div", { class: "svc-head" }, h("span", { style: "flex:1" }, it.title),
          h("button", { class: "btn sm ghost", onclick: () => { const t = prompt("Heading", it.title); if (t) { it.title = t; saveService(); renderItems(); } } }, "Rename"),
          h("button", { class: "btn sm ghost", title: "Move up", onclick: () => { if (i > 0) { const a = S.service.items; [a[i - 1], a[i]] = [a[i], a[i - 1]]; saveService(); renderItems(); } } }, "↑"),
          h("button", { class: "btn sm ghost", title: "Move down", onclick: () => { const a = S.service.items; if (i < a.length - 1) { [a[i + 1], a[i]] = [a[i], a[i + 1]]; saveService(); renderItems(); } } }, "↓"),
          h("button", { class: "btn sm ghost", title: "Remove", onclick: () => { S.service.items.splice(i, 1); saveService(); renderItems(); } }, "✕")));
        return;
      }
      const langSel = (key) => { const sel = h("select", { class: "input", style: "height:26px;font-size:12px", onclick: e => e.stopPropagation() }, key === "lang2" ? h("option", { value: "" }, "— none —") : h("option", { value: "" }, "Default"), ...Object.keys(song.versions).map(l => h("option", { value: l }, LANGS[l] || l))); sel.value = it[key] || ""; sel.onchange = () => { it[key] = sel.value || undefined; saveService(); renderItems(); }; return sel; };
      items.appendChild(h("div", { class: "svc-item", style: "padding:10px 16px" },
        h("div", { class: "dim", style: "width:22px;text-align:right" }, String(i + 1)),
        h("div", { class: "ic " + it.type }, ICON[it.type]),
        h("div", { style: "min-width:0;flex:1" }, h("div", { class: "tt" }, itemTitle(it)), h("div", { class: "st" }, itemSub(it))),
        song ? h("div", { class: "row", style: "flex-wrap:nowrap" }, h("span", { class: "dim" }, "Show"), langSel("lang1"), h("span", { class: "dim" }, "with"), langSel("lang2"),
          h("input", { class: "input", style: "height:26px;width:120px;font-size:12px", placeholder: song.order || "Order", title: "Song order for this service, e.g. V1 C V2 C B C", value: it.order || "", onclick: e => e.stopPropagation(), onchange: e => { it.order = e.target.value.trim() || undefined; saveService(); } })) : null,
        h("div", { class: "row", style: "flex-wrap:nowrap;gap:2px" },
          h("button", { class: "btn sm ghost", title: "Move up", onclick: () => { if (i > 0) { const a = S.service.items; [a[i - 1], a[i]] = [a[i], a[i - 1]]; saveService(); renderItems(); } } }, "↑"),
          h("button", { class: "btn sm ghost", title: "Move down", onclick: () => { const a = S.service.items; if (i < a.length - 1) { [a[i + 1], a[i]] = [a[i], a[i + 1]]; saveService(); renderItems(); } } }, "↓"),
          h("button", { class: "btn sm ghost", title: "Present now", onclick: () => present(it, 0, { fromService: true }) }, "▶"),
          h("button", { class: "btn sm ghost", title: "Remove", onclick: () => { S.service.items.splice(i, 1); saveService(); renderItems(); } }, "✕"))));
    });
  }
  function renderAll() { renderSvcs(); renderItems(); }
  onChange(w => { if (w === "service") renderItems(); });
  renderAll();
  return { onShow: renderAll };
}
