// Team songbook on the desktop: approve songs sent from the team phones, publish the church library to GitHub.
import { S, h, toast, modal, saveSong, native } from "../core.js";
import { stripChords } from "../chords.js";
import { sectionsToText } from "../song-text.js";

const T = () => native?.team;
const ago = (iso) => { const d = (Date.now() - new Date(iso)) / 60000; return d < 60 ? `${Math.max(1, Math.round(d))} min ago` : d < 1440 ? `${Math.round(d / 60)} h ago` : new Date(iso).toLocaleDateString(); };
// ---- is this song already in the songbook? compare the words (3-letter pieces), so photo/typing mistakes still match ----
const clean = (t) => (t || "").replace(/\[[^\]]*\]/g, " ").replace(/\(x\d+\)|\.{2,}\s*\d/g, " ").replace(/^\s*[\d१-९]+[.)]?\s+/gm, "").replace(/[^\p{L}\p{M}]+/gu, "").toLowerCase();
const grams = (t) => { const c = clean(t), g = new Set(); for (let i = 0; i + 3 <= c.length; i++) g.add(c.slice(i, i + 3)); return g; };
const songWords = (s) => Object.values(s.versions || {}).filter(v => !v.auto).map(v => [v.title, ...(v.sections || []).flatMap(x => x.lines)].join("\n")).join("\n");
let gramIndex = null, gramFor = 0;
export function findMatches(song, limit = 2) {
  if (!gramIndex || gramFor !== S.songs.length) { gramIndex = S.songs.map(s => ({ s, g: grams(songWords(s)) })); gramFor = S.songs.length; }
  const q = grams(songWords(song)); if (q.size < 12) return [];
  const out = [];
  for (const x of gramIndex) { if (x.s.id === song.id) continue; let n = 0; for (const t of q) if (x.g.has(t)) n++; const score = n / q.size; if (score >= 0.55) out.push({ song: x.s, score }); }
  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}
const bookOf = (s) => (s.books || []).map(b => b.book + " " + b.num).join(", ");
const preview = (song) => { const v = song?.versions?.[song.lang] || Object.values(song?.versions || {})[0]; return (v?.sections || []).slice(0, 2).map(s => `[${s.label}]\n` + s.lines.slice(0, 4).map(stripChords).join("\n")).join("\n\n"); };

export async function inboxCount() { if (!T()) return 0; const st = await T().status(); if (!st.hasToken) return 0; const r = await T().inbox(); return r.ok ? r.items.length : 0; }

export async function openInbox(onSelect, onChange) {
  if (!T()) return toast("The song inbox works in the desktop app");
  const st = await T().status(); if (!st.hasToken) return modal("Song inbox", h("p", { class: "muted" }, "Add the GitHub team key in Settings → Team songbook first."), [{ label: "OK" }]);
  const body = h("div", { class: "col", style: "max-height:66vh;overflow:auto;padding-right:4px" }, h("div", { class: "muted" }, "Loading songs from the team phones…"));
  const close = modal("Song inbox — from the team phones", body, [{ label: "Close" }]); close.firstChild.style.width = "min(760px, 92vw)";
  const r = await T().inbox();
  body.innerHTML = "";
  if (!r.ok) { body.append(h("div", { class: "muted" }, r.error)); return; }
  if (!r.items.length) { body.append(h("div", { class: "muted" }, "Nothing waiting. New songs from the team phones appear here.")); return; }
  for (const it of r.items) {
    const song = it.song || {}; const exists = S.songs.find(s => s.id === song.id);
    const matches = exists ? [] : findMatches(song); const dup = matches[0]?.song;
    const row = h("div", { class: "card col", style: "gap:6px" },
      h("div", { class: "row" }, h("b", { style: "flex:1" }, song.title || "Untitled"),
        h("span", { class: "chip" }, it.kind === "edit" || exists ? "Correction" : "New song"),
        h("span", { class: "dim", style: "font-size:12px" }, `${it.by || "Team"} · ${ago(it.at)}`)),
      it.note ? h("div", { class: "muted", style: "font-size:12.5px" }, "Note: " + it.note) : null,
      exists ? h("div", { class: "muted", style: "font-size:12.5px" }, `Correction to ${bookOf(exists)} “${exists.title}”.`)
        : matches.length ? h("div", { style: "font-size:12.5px;color:#d97706;display:flex;flex-direction:column;gap:4px" }, ...matches.map(m => h("div", {}, `⚠ ${Math.round(m.score * 100)}% the same as ${bookOf(m.song)} “${m.song.title}” — already in the songbook.`)))
        : h("div", { style: "font-size:12.5px;color:#16a34a" }, `✓ Checked all ${S.songs.length.toLocaleString()} songs — not in the songbook yet.`),
      h("pre", { style: "white-space:pre-wrap;font:inherit;font-size:13px;margin:0;max-height:180px;overflow:auto;background:var(--bg2,rgba(0,0,0,.04));padding:8px;border-radius:8px" }, preview(song)),
      h("div", { class: "row", style: "flex-wrap:wrap" },
        ...(dup ? [
          h("button", { class: "btn sm primary", onclick: () => compare(dup) }, `Compare with ${bookOf(dup) || "it"}`),
          h("button", { class: "btn sm", onclick: reject }, `Keep ${bookOf(dup) || "the old one"}, discard this`),
          h("button", { class: "btn sm ghost", onclick: () => approve(true) }, "It's a different song"),
        ] : [
          h("button", { class: "btn sm primary", onclick: () => approve(false) }, exists ? "Accept correction" : "Add to songs"),
          h("button", { class: "btn sm", onclick: () => approve(true) }, exists ? "Accept and edit" : "Add and edit"),
        ]),
        h("span", { style: "flex:1" }),
        dup ? null : h("button", { class: "btn sm ghost", onclick: reject }, "Reject")));
    async function approve(edit) {
      const s = { ...(exists || {}), ...song, status: song.status === "fix" ? "fix" : "ok", source: song.source || "team:" + (it.by || "phone") };
      delete s._score; await saveSong(s);
      const d = await T().remove(it.path, it.sha, "approved", { songId: s.id, book: bookOf(s), title: s.title }); if (!d.ok) toast(d.error);
      row.remove(); onChange?.(); toast(`“${s.title}” saved as ${bookOf(s)} — Publish library to send it to everyone`);
      if (edit) { close.remove(); onSelect?.(s.id, true); }
    }
    // the sent words replace the old song's words in the same language; number, other languages and notes stay
    // side by side: what the songbook has | what the phone sent
    function compare(old) {
      const col = (head, sg) => h("div", { class: "col", style: "flex:1;min-width:0;gap:4px" }, h("b", { style: "font-size:13px" }, head),
        h("pre", { style: "white-space:pre-wrap;font:inherit;font-size:13px;margin:0;max-height:52vh;overflow:auto;background:var(--bg2,rgba(0,0,0,.04));padding:8px;border-radius:8px" }, sectionsToText((sg.versions[sg.lang] || Object.values(sg.versions)[0]).sections)));
      const m = modal(`${bookOf(old)} “${old.title}” — songbook vs. sent`, h("div", { class: "row", style: "align-items:flex-start;gap:10px" }, col(`In the songbook (${bookOf(old)})`, old), col(`Sent by ${it.by || "the team"}`, song)), [
        { label: `Keep ${bookOf(old)} as it is`, fn: () => { reject(); } },
        { label: `Edit ${bookOf(old)}`, fn: () => { reject(); close.remove(); onSelect?.(old.id, true); } },
        { label: "Use the sent words", cls: "primary", fn: () => mergeInto(old, true) }]);
      m.firstChild.style.width = "min(980px, 94vw)";
    }
    async function mergeInto(old, edit) {
      const s = JSON.parse(JSON.stringify(old));      // number, title, other languages and notes stay; only the words change
      for (const [l, v] of Object.entries(song.versions || {})) { if (v.auto && s.versions[l] && !s.versions[l].auto) continue; s.versions[l] = { ...v, title: s.versions[l]?.title || s.title }; }
      if (song.key && !s.key) s.key = song.key;
      s.status = "ok"; await saveSong(s);
      const d = await T().remove(it.path, it.sha, "merged", { songId: s.id, book: bookOf(s), title: s.title }); if (!d.ok) toast(d.error);
      row.remove(); onChange?.(); toast(`${bookOf(s)} “${s.title}” updated — Publish library to send it to everyone`);
      close.remove(); onSelect?.(s.id, edit);
    }
    async function reject() { const d = await T().remove(it.path, it.sha, "rejected", dup ? { songId: dup.id, book: bookOf(dup), title: dup.title, reason: "already in the songbook" } : {}); if (!d.ok) return toast(d.error); row.remove(); onChange?.(); toast("Rejected"); }
    body.append(row);
  }
}

export async function publishLibrary(btn, out) {
  if (!T()) return;
  const by = S.settings.team?.name || "";
  if (btn) btn.disabled = true;
  T().onStep?.((t) => { if (out) out.textContent = t; });
  const songs = S.songs.filter(s => s.status !== "draft");
  const r = await T().publish(JSON.parse(JSON.stringify(songs)), by, { ...(S.settings.deletedSongs || {}) });
  if (btn) btn.disabled = false;
  const msg = !r.ok ? "Could not publish: " + r.error : r.nothing ? "Nothing new to publish — the library is up to date." : `Published library ${r.version}: ${r.added} new, ${r.changed} changed, ${r.removed || 0} removed (${r.total.toLocaleString()} songs). Other computers get it within 2 hours, phones when they open the songbook.`;
  if (out) out.textContent = msg; toast(msg.split(".")[0]);
  return r;
}

export function teamCard() {
  const box = h("div", { class: "card col" });
  if (!T()) return box;
  const render = async () => {
    const st = await T().status(); S.settings.team ||= {};
    const tok = h("input", { class: "input", type: "password", placeholder: st.hasToken ? "•••••••• (saved — paste a new one to replace)" : "Paste the GitHub key (github_pat_…)", autocomplete: "off" });
    const inbox = h("input", { class: "input", value: st.inbox });
    const name = h("input", { class: "input", value: S.settings.team.name || "", placeholder: "e.g. Media desk" });
    const books = Object.keys(S.books || {}).length ? S.books : { RH: "Revival Hindi Songbook" };
    const newBook = h("select", { class: "input" }, ...Object.entries(books).map(([k, v]) => h("option", { value: k, selected: k === (S.settings.team.newBook || "RH") }, `${k} — ${v}`)));
    newBook.onchange = async () => { S.settings.team.newBook = newBook.value; (await import("../core.js")).saveSettings(); const { nextBookNumber } = await import("../core.js"); toast(`New songs will be numbered from ${newBook.value} ${nextBookNumber().num}`); };
    const out = h("div", { class: "muted", style: "font-size:12.5px;min-height:18px" }, st.lastPublish ? `Last published: library ${st.lastPublish.version} · ${new Date(st.lastPublish.at).toLocaleString()} · ${st.lastPublish.added} new, ${st.lastPublish.changed} changed` : "");
    const pub = h("button", { class: "btn primary", disabled: !st.hasToken, onclick: () => publishLibrary(pub, out) }, "Publish library to everyone");
    box.innerHTML = "";
    box.append(h("div", { style: "font-weight:650;font-size:14px" }, "Team songbook & publishing"),
      h("div", { class: "muted", style: "font-size:12.5px" }, "Songs added on the team phones wait in Songs → Inbox. After approving, Publish sends the locked library to GitHub; every computer and phone then gets the new songs."),
      h("div", { class: "row" }, h("label", { class: "f", style: "flex:2" }, "GitHub key", tok), h("label", { class: "f", style: "flex:2" }, "Inbox repository", inbox), h("label", { class: "f", style: "flex:1" }, "This desk's name", name)),
      h("div", { class: "row" },
        h("button", { class: "btn", onclick: async () => { S.settings.team.name = name.value.trim(); const { saveSettings } = await import("../core.js"); saveSettings(); await T().set(tok.value || null, inbox.value); const c = await T().check(); toast(c.ok ? "Team key works ✓" : c.error); render(); } }, "Save & test"),
        st.hasToken ? h("button", { class: "btn ghost", onclick: async () => { await T().set("", null); render(); } }, "Remove key") : null,
        h("button", { class: "btn", onclick: () => openInbox() }, "Open inbox"), pub),
      h("label", { class: "f" }, "New songs get the next number in", newBook),
      out,
      h("div", { class: "dim", style: "font-size:11.5px" }, "Key: github.com → Settings → Developer settings → Fine-grained tokens → only the repositories “revival-song-inbox” and “revival-worship-releases”, permission Contents: Read and write. It stays on this computer."));
  };
  render();
  return box;
}
