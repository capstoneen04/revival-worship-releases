// Shared slide renderer for projector, stage, previews
export const BACKGROUNDS = {
  navy: "radial-gradient(ellipse at 50% 30%, #1d3a6b 0%, #0b1730 55%, #050a17 100%)",
  black: "#000",
  dawn: "linear-gradient(160deg, #2b1d3a 0%, #5a2f3e 45%, #c06c3e 100%)",
  forest: "radial-gradient(ellipse at 50% 20%, #1f4a3a 0%, #0c2019 60%, #050d0a 100%)",
  royal: "linear-gradient(135deg, #0d2b6b 0%, #1a56c4 50%, #0d2b6b 100%)",
  slate: "linear-gradient(180deg, #2a2f38 0%, #14171c 100%)",
};

export const DEFAULT_THEME = { bg: "navy", bgImage: "", dim: 0.35, font: "sans", scale: 1, color: "#ffffff", color2: "#ffd98a", shadow: true, align: "center", footer: true, uppercase: false };

const isDeva = s => /[ऀ-ॿ]/.test(s || "");

export function applyBackground(el, theme, transparent = false) {
  if (transparent) { el.style.background = "transparent"; return; }
  // moving background: the <video> sits behind the stage (output.html); here only the darkening layer
  if (theme.bg === "video" && theme.bgVideo) { el.style.background = `rgba(0,0,0,${theme.dim ?? 0.35})`; return; }
  if (theme.bg === "image" && theme.bgImage) {
    el.style.background = `linear-gradient(rgba(0,0,0,${theme.dim}), rgba(0,0,0,${theme.dim})), url("${theme.bgImage}") center/cover no-repeat, #000`;
  } else el.style.background = BACKGROUNDS[theme.bg] || BACKGROUNDS.navy;
}

// Render a slide into `stage` (a 1920x1080 logical box)
export function renderSlide(stage, slide, theme = DEFAULT_THEME, { transparent = false, mode = "projector", layout = null } = {}) {
  theme = { ...DEFAULT_THEME, ...(theme || {}) };
  // projector language layout: stacked (default) or side by side; second language size; swap; first language only
  const L = { layout: "stacked", split: 0.82, swap: false, showSecond: true, ...(layout || {}) };
  if (slide && slide.lines2 && slide.lines2.length) {
    if (!L.showSecond) slide = { ...slide, lines2: null };
    else if (L.swap) slide = { ...slide, lines: slide.lines2, lines2: slide.lines };
  }
  if (slide && slide.kind === "media") { applyBackground(stage, { bg: "black" }); stage.innerHTML = ""; return; }   // media layer is drawn by output.html
  applyBackground(stage, theme, transparent);
  stage.innerHTML = "";
  const wrap = document.createElement("div");
  wrap.className = "rw-slide";
  wrap.style.cssText = `position:absolute;inset:0;display:flex;flex-direction:column;align-items:${theme.align === "left" ? "flex-start" : "center"};justify-content:center;padding:70px 110px;box-sizing:border-box;color:${theme.color};text-align:${theme.align};`;
  if (!slide || slide.kind === "blank" || slide.kind === "clear") { stage.appendChild(wrap); if (slide && slide.kind === "blank") stage.style.background = "#000"; return; }
  if (slide.kind === "logo") {
    const img = document.createElement("img");
    img.src = theme.logo || "assets/img/logo.png";
    img.style.cssText = "max-width:42%;max-height:70%;filter:drop-shadow(0 10px 40px rgba(0,0,0,.5))";
    wrap.appendChild(img);
    if (theme.churchName) { const t = document.createElement("div"); t.textContent = theme.churchName; t.style.cssText = "margin-top:40px;font:600 64px/1.1 var(--rw-font);letter-spacing:.06em"; wrap.appendChild(t); }
    stage.appendChild(wrap); return;
  }
  const body = document.createElement("div");
  body.className = "rw-body";
  const fontFam = theme.font === "serif" ? "'Noto Serif Devanagari', Georgia, 'Times New Roman', serif" : "'Noto Sans Devanagari', 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif";
  body.style.cssText = `font-family:${fontFam};font-weight:600;line-height:1.28;max-width:100%;width:max-content;${theme.shadow ? "text-shadow:0 3px 12px rgba(0,0,0,.75),0 1px 2px rgba(0,0,0,.9);" : ""}${theme.uppercase ? "text-transform:uppercase;" : ""}`;
  const main = document.createElement("div");
  main.className = "rw-main";
  for (const l of slide.lines || []) { const d = document.createElement("div"); d.textContent = l; main.appendChild(d); }
  body.appendChild(main);
  const side = L.layout === "side" && slide.lines2 && slide.lines2.length;
  if (side) { body.style.display = "grid"; body.style.gridTemplateColumns = "1fr 1fr"; body.style.columnGap = "1.4em"; body.style.alignItems = "center"; body.style.width = "100%"; }
  if (slide.lines2 && slide.lines2.length) {
    const sec = document.createElement("div");
    sec.className = "rw-second";
    sec.style.cssText = `color:${theme.color2};${side ? "" : "margin-top:0.55em;"}font-weight:500;font-size:${Math.max(0.5, Math.min(1, +L.split || 0.82))}em;`;
    for (const l of slide.lines2) { const d = document.createElement("div"); d.textContent = l; sec.appendChild(d); }
    body.appendChild(sec);
  }
  wrap.appendChild(body);
  if (theme.footer && (slide.title || slide.ref) && mode !== "obs") {
    const f = document.createElement("div");
    f.style.cssText = `position:absolute;left:0;right:0;bottom:28px;text-align:center;font:500 30px/1 ${fontFam};opacity:.7;${theme.shadow ? "text-shadow:0 2px 6px rgba(0,0,0,.8);" : ""}`;
    f.textContent = [slide.kind === "song" ? slide.title : "", slide.ref].filter(Boolean).join("  ·  ");
    if (slide.kind === "bible" || slide.kind === "message") f.textContent = slide.ref || slide.title;
    wrap.appendChild(f);
  }
  stage.appendChild(wrap);
  fit(body, wrap, theme.scale, slide);
}

function fit(body, wrap, scale = 1, slide) {
  const maxW = 1920 - 220, maxH = 1080 - 190;
  const prose = slide.kind === "bible" || slide.kind === "message" || slide.kind === "text" || slide.kind === "notes";
  const top = Math.round((prose ? 84 : 96) * scale);
  const search = (nowrap) => {
    body.style.whiteSpace = nowrap ? "nowrap" : "normal";
    let hi = top, lo = 20;
    for (let i = 0; i < 12; i++) {
      const mid = Math.round((hi + lo) / 2);
      body.style.fontSize = mid + "px";
      if (body.scrollWidth <= maxW && body.scrollHeight <= maxH) lo = mid; else hi = mid;
    }
    body.style.fontSize = lo + "px";
    return lo;
  };
  // Songs: keep each lyric line on one line if that still gives a readable size
  if (!prose) { const sz = search(true); if (sz >= top * 0.62) return; }
  search(false);
}

// Scale a 1920x1080 stage element to fit its parent
export function fitStage(stage, parent = stage.parentElement) {
  const r = () => {
    const s = Math.min(parent.clientWidth / 1920, parent.clientHeight / 1080);
    stage.style.transform = `scale(${s})`;
    stage.style.left = (parent.clientWidth - 1920 * s) / 2 + "px";
    stage.style.top = (parent.clientHeight - 1080 * s) / 2 + "px";
  };
  r();
  new ResizeObserver(r).observe(parent);
  return r;
}
