// One list of church members for name cards, preachers (voice preset + photo for thumbnails) and sermon parsing.
import { S, h, db, uid, toast, modal, emit, saveSettings } from "./core.js";

// Members, their posts, photos and voice presets live only in the church database (Backup folder / private repo),
// never in the app code that is published for updates.
const DEFAULTS = {};
const VOICE_GENERIC = { input: 1302, fader: 0, hpf: 100, mudF: 250, mudG: -3, presF: 3500, presG: 3, airG: 2, gateTh: -48, compTh: -22, ratio: 3, makeup: 4, mixOn: true, cameraAudioOff: true, masterSafe: true };

let cache = null;
export async function people() {
  if (cache) return cache;
  let list = await db.all("people");
  let changed = false;
  for (const p of list) {
    if (p.v === 2) continue;
    Object.assign(p, { short: p.name, aliases: [], preacher: false, details: "", photo: "", voice: null }, DEFAULTS[p.name] || {}, { v: 2 });
    // carry over names/roles typed into the old Production speaker list
    await db.put("people", p); changed = true;
  }
  for (const sp of S.settings.speakers || []) {
    if (list.some(p => p.name === sp.name || p.short === sp.name)) continue;
    const p = { id: uid("p"), name: sp.name, short: sp.name, role: sp.role || "", details: "", aliases: [], preacher: true, voice: sp.voice || null, photo: "", v: 2 };
    await db.put("people", p); list.push(p); changed = true;
  }
  cache = list.sort((a, b) => (b.preacher - a.preacher) || a.name.localeCompare(b.name));
  if (changed) emit("people");
  return cache;
}
export const preachers = async () => (await people()).filter(p => p.preacher);
export async function savePerson(p) { p.v = 2; await db.put("people", p); cache = null; emit("people"); }
export async function deletePerson(p) { await db.del("people", p.id); cache = null; emit("people"); }
export async function personByName(name) { return (await people()).find(p => p.name === name || p.short === name) || null; }
export function photoUrl(p) { return p?.photo ? "/" + p.photo.replace(/^\//, "") : ""; }

// ---------- editor ----------
export async function openPeopleEditor(selectId) {
  let list = await people(), sel = list.find(p => p.id === selectId) || list[0] || null;
  const left = h("div", { class: "col", style: "gap:4px;width:220px;max-height:60vh;overflow:auto" });
  const right = h("div", { class: "col", style: "gap:8px;flex:1;min-width:0" });
  const box = h("div", { class: "row", style: "align-items:flex-start;flex-wrap:nowrap;gap:14px" }, left, right);
  const bg = modal("Church members & preachers", box, [{ label: "Close" }]);
  bg.querySelector(".modal").style.width = "min(860px, 94vw)";

  function renderList() {
    left.innerHTML = "";
    left.append(h("button", { class: "btn sm primary", onclick: () => { sel = { id: uid("p"), name: "", short: "", role: "", details: "", aliases: [], preacher: true, voice: null, photo: "", isNew: true }; renderList(); renderForm(); } }, "+ Add person"));
    for (const p of list) left.append(h("div", { class: "svc-item" + (sel && sel.id === p.id ? " sel" : ""), onclick: () => { sel = p; renderList(); renderForm(); } },
      p.photo ? h("img", { src: photoUrl(p), style: "width:28px;height:28px;border-radius:50%;object-fit:cover;object-position:top;background:#222" }) : h("div", { class: "ic name" }, (p.name || "?")[0]),
      h("div", { style: "min-width:0" }, h("div", { class: "tt", style: "font-size:13px" }, p.name || "(new)"), h("div", { class: "st" }, [p.role, p.preacher ? "preacher" : ""].filter(Boolean).join(" · ")))));
  }
  function field(label, key, ph, o = {}) {
    const el = h(o.area ? "textarea" : "input", { class: "input", placeholder: ph || "", rows: o.area ? 2 : null });
    el.value = key === "aliases" ? (sel.aliases || []).join(", ") : sel[key] || "";
    el.oninput = () => { sel[key] = key === "aliases" ? el.value.split(",").map(x => x.trim().toLowerCase()).filter(Boolean) : el.value; };
    return h("label", { class: "f", style: o.style || "" }, label, el);
  }
  function renderForm() {
    right.innerHTML = "";
    if (!sel) { right.append(h("div", { class: "muted" }, "Add a person to begin.")); return; }
    const file = h("input", { type: "file", accept: "image/png,image/webp,image/jpeg", style: "display:none", onchange: async e => {
      const f = e.target.files[0]; if (!f) return;
      toast("Uploading photo…");
      const small = await shrink(f, 2400);
      const name = (sel.name || "person").replace(/[^\w .()-]+/g, "_") + ".png";
      const r = await fetch(`/api/upload?path=${encodeURIComponent("People/" + name)}`, { method: "POST", body: small }).then(r => r.json());
      sel.photo = r.url.replace(/^\//, "") + "?v=" + Date.now(); renderForm(); toast("Photo added — save to keep it");
    } });
    right.append(
      h("div", { class: "row", style: "align-items:flex-start;flex-wrap:nowrap;gap:12px" },
        h("div", { class: "col", style: "gap:6px;width:150px;flex:0 0 auto" },
          h("div", { style: "width:150px;height:150px;border-radius:10px;background:repeating-conic-gradient(#1a1d24 0 25%, #14161b 0 50%) 0 0/16px 16px;overflow:hidden;display:grid;place-items:center" },
            sel.photo ? h("img", { src: photoUrl(sel), style: "max-width:100%;max-height:100%;object-fit:contain" }) : h("span", { class: "dim", style: "font-size:11px;text-align:center;padding:8px" }, "Photo for thumbnails (cut-out PNG works best)")),
          h("button", { class: "btn sm", onclick: () => file.click() }, sel.photo ? "Change photo" : "Add photo"), file,
          sel.photo ? h("button", { class: "btn sm ghost", onclick: () => { sel.photo = ""; renderForm(); } }, "Remove photo") : null),
        h("div", { class: "col", style: "gap:8px;flex:1;min-width:0" },
          field("Full name (name card, thumbnail)", "name", "Pastor Royal Rodrigues"),
          h("div", { class: "row", style: "flex-wrap:nowrap" }, field("Short name (YouTube title)", "short", "Br. Royal", { style: "flex:1" }), field("Post / role", "role", "Pastor", { style: "flex:1" })),
          field("Details (line under the name)", "details", "Revival Church Mumbai"),
          field("Other spellings the pastor uses (comma separated)", "aliases", "royal, rodrigues"))),
      h("label", { class: "row", style: "gap:6px" }, h("input", { type: "checkbox", checked: !!sel.preacher, onchange: e => { sel.preacher = e.target.checked; } }), "Preaches — show in the Speaker list"),
      h("label", { class: "row", style: "gap:6px" }, h("input", { type: "checkbox", checked: !!sel.voice, onchange: e => { sel.voice = e.target.checked ? structuredClone(sel.voice || VOICE_GENERIC) : null; } }), "Apply a microphone voice preset on the ATEM when this person speaks"),
      h("div", { class: "row", style: "justify-content:space-between;margin-top:6px" },
        sel.isNew ? h("span") : h("button", { class: "btn live", onclick: () => {
          modal(`Delete ${sel.name}?`, h("p", { class: "muted" }, "Removes this person, their post and details from the app. Their photo file stays in Media/People."), [{ label: "Cancel" }, { label: "Delete", cls: "live", fn: async () => {
            await deletePerson(sel); list = await people(); sel = list[0] || null; renderList(); renderForm(); toast("Deleted");
          } }]);
        } }, "Delete person"),
        h("button", { class: "btn primary", onclick: async () => {
          if (!sel.name.trim()) return toast("Please enter a name");
          delete sel.isNew; sel.short ||= sel.name; await savePerson(sel); list = await people(); renderList(); toast("Saved");
        } }, "Save")));
  }
  renderList(); renderForm();
}

// keep uploads light: huge cut-outs (e.g. 12000 px) are scaled down to `max` px tall, transparency kept
async function shrink(file, max) {
  const bm = await createImageBitmap(file);
  const k = Math.min(1, max / Math.max(bm.width, bm.height));
  const c = new OffscreenCanvas(Math.round(bm.width * k), Math.round(bm.height * k));
  c.getContext("2d").drawImage(bm, 0, 0, c.width, c.height);
  return c.convertToBlob({ type: "image/png" });
}
