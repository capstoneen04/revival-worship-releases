// Face finder in a background thread — keeps the app smooth while it watches the camera.
let faceapi = null, ready = null;

async function init(base) {
  const m = await import(base + "vendor/face-api/face-api.esm.js");
  // face-api expects browser objects; give it the worker equivalents
  class Dummy { }
  m.env.setEnv({
    Canvas: OffscreenCanvas, CanvasRenderingContext2D: OffscreenCanvasRenderingContext2D, Image: Dummy, ImageData, Video: Dummy,
    createCanvasElement: () => new OffscreenCanvas(1, 1), createImageElement: () => new Dummy(), createVideoElement: () => new Dummy(),
    fetch: self.fetch.bind(self), readFile: () => { throw new Error("no files in a worker"); },
  });
  const tf = m.tf;
  let backend = "cpu";
  try { if (await tf.setBackend("webgl")) backend = "webgl"; } catch { }
  if (backend !== "webgl") { try { (tf.setWasmPaths || m.setWasmPaths)?.(base + "vendor/face-api/wasm/"); if (await tf.setBackend("wasm")) backend = "wasm"; } catch { } }
  if (backend === "cpu") await tf.setBackend("cpu");
  await tf.ready();
  await m.nets.ssdMobilenetv1.loadFromUri(base + "vendor/face-api/model");
  faceapi = m;
  return backend;
}

self.onmessage = async (e) => {
  const d = e.data;
  if (d.type === "init") {
    ready ||= init(d.base);
    try { const backend = await ready; self.postMessage({ type: "ready", backend }); } catch (err) { self.postMessage({ type: "error", error: String(err && err.message || err) }); }
    return;
  }
  if (d.type === "frame") {
    try {
      await ready;
      const bm = d.bitmap, c = new OffscreenCanvas(bm.width, bm.height);
      c.getContext("2d").drawImage(bm, 0, 0); bm.close();
      const t0 = performance.now();
      const det = await faceapi.detectAllFaces(c, new faceapi.SsdMobilenetv1Options({ minConfidence: 0.35, maxResults: 6 }));
      self.postMessage({ type: "faces", id: d.id, w: c.width, h: c.height, ms: performance.now() - t0, faces: det.map(x => ({ x: x.box.x, y: x.box.y, w: x.box.width, h: x.box.height, s: x.score })) });
    } catch (err) { self.postMessage({ type: "faces", id: d.id, faces: [], error: String(err && err.message || err) }); }
  }
};
