// Reads the sermon details the pastor sends every week, e.g.
//   18/10/26 M [UN] BRO ROYAL
//   Title - New Church built up by God-called men, God-trained men.  { P - 25}
//   Sub - …   Ins - …   Scripture - Numbers 27 : 15 - 20 ; 1 Samuel 16 : 12 - 14
//   शीर्षक - …  विषय - …  प्रेरणा - …  पवित्रशास्त्र - …
import { parseRef } from "./bible.js";

const KEYS = [
  ["title", /^(title|topic|शीर्षक)(?=[\s\-–:]|$)/i], ["sub", /^(sub|subject|विषय)(?=[\s\-–:]|$)/i], ["ins", /^(ins|insp|inspiration|प्रेरणा)(?=[\s\-–:]|$)/i],
  ["scripture", /^(scriptures?|scr|verses?|reading|पवित्रशास्त्र|पवित्र\s*शास्त्र|वचन)(?=[\s\-–:]|$)/i],
];
const PLACES = { UN: "Ulhasnagar", MUM: "Mumbai", MU: "Mumbai", PB: "Punjab", PUN: "Punjab" };

export function parseSermon(raw = "") {
  const text = raw.replace(/[“”]/g, "").replace(/\r/g, "").trim();
  const out = { raw, date: "", session: "", placeCode: "", place: "", preacherText: "", page: "", en: {}, hi: {} };
  const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
  for (const line of lines) {
    // header: 18/10/26 M [UN] BRO ROYAL
    const hm = line.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})\s*([MEN]\b)?\s*(?:\[([^\]]+)\])?\s*(.*)$/i);
    if (hm && !out.date) {
      const yy = hm[3].length === 2 ? "20" + hm[3] : hm[3];
      out.date = `${yy}-${hm[2].padStart(2, "0")}-${hm[1].padStart(2, "0")}`;
      out.session = (hm[4] || "").toUpperCase();
      out.placeCode = (hm[5] || "").trim();
      out.place = PLACES[out.placeCode.toUpperCase()] || out.placeCode;
      out.preacherText = (hm[6] || "").trim();
      continue;
    }
    const isHi = /[ऀ-ॿ]/.test(line.split(/[-–:]/)[0]);
    for (const [k, re] of KEYS) {
      const head = line.split(/\s*[-–:]\s*/)[0];
      if (!re.test(head.trim())) continue;
      let val = line.slice(line.indexOf(head) + head.length).replace(/^\s*[-–:]\s*/, "").trim();
      const pm = val.match(/\{\s*([^}]*)\}\s*$/);
      if (pm) { out.page ||= pm[1].replace(/\s+/g, "").replace(/^P/i, "P"); val = val.replace(pm[0], "").trim(); }
      (isHi ? out.hi : out.en)[k] = val;
      break;
    }
  }
  out.refs = splitRefs(out.en.scripture || "");
  out.refsHi = (out.hi.scripture || "").split(/\s*;\s*/).map(s => s.replace(/[.।]\s*$/, "").trim()).filter(Boolean);
  return out;
}

// "Numbers 27 : 15 - 20 ; 1 king 19 : 18 - 21" -> [{label, ref}]
export function splitRefs(s) {
  return s.split(/\s*[;|]\s*/).map(x => x.replace(/[.]\s*$/, "").replace(/\s*:\s*/g, ":").replace(/\s*[-–]\s*/g, "-").replace(/\s+/g, " ").trim()).filter(Boolean).map(label => {
    const r = parseRef(label.replace(/\bking\b/i, "kings").replace(/\bpsalm\b/i, "psalms"));
    return { label, ref: r };
  });
}

// match "BRO ROYAL" to a person in the list (name, short name or aliases)
export function matchPerson(text, people) {
  const t = (text || "").toLowerCase().replace(/\b(bro|br|brother|pastor|ps|elder|rev|sis|sister)\.?\b/g, "").replace(/[^a-zऀ-ॿ ]/g, " ").trim();
  if (!t) return null;
  const words = t.split(/\s+/).filter(w => w.length > 2);
  let best = null, score = 0;
  for (const p of people) {
    const hay = [p.name, p.short, ...(p.aliases || [])].join(" ").toLowerCase();
    const s = words.filter(w => hay.includes(w)).length;
    if (s > score) { score = s; best = p; }
  }
  return best;
}

// colour mood from the title (same routing as the thumbnail blueprint)
export function moodFor(title = "") {
  const t = title.toLowerCase();
  if (/fire|blood|sacrific|love|passion|cross|calvary|lamb|redeem|redemption|atone/.test(t)) return "burgundy";
  if (/new life|grow|growth|built|build|restor|regenerat|new man|seed|harvest|vine|lively|living stone|branch/.test(t)) return "emerald";
  if (/king|kingdom|royal|majest|authority|throne|crown|reign|glory|bride/.test(t)) return "indigo";
  if (/spirit|wisdom|call|water|peace|holy ghost|river|rain|faith|trained|chosen/.test(t)) return "sapphire";
  return "charcoal";
}
