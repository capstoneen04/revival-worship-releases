// Turn songs / verses / quotes into projectable slides
import { stripChords, parseOrder, sectionColor } from "./chords.js";
export function chunk(lines, n) {
  if (lines.length <= n) return [lines];
  const parts = Math.ceil(lines.length / n);
  const size = Math.ceil(lines.length / parts);       // even split: 6 lines @4 -> 3+3
  const out = [];
  for (let i = 0; i < lines.length; i += size) out.push(lines.slice(i, i + size));
  return out;
}

// arrangement: default order; optionally repeat first chorus after every verse
export function arrange(sections, { autoChorus = true } = {}) {
  if (!sections || !sections.length) return [];
  const hasVerse = sections.some(s => /^Verse/i.test(s.label));
  const chorusIdx = sections.findIndex(s => /^Chorus/i.test(s.label));
  if (!autoChorus || chorusIdx < 0 || !hasVerse) return sections.map((s, i) => ({ ...s, idx: i }));
  const chorus = sections[chorusIdx];
  // already repeated in source?
  if (sections.filter(s => /^Chorus/i.test(s.label)).length > 1) return sections.map((s, i) => ({ ...s, idx: i }));
  const out = [];
  sections.forEach((s, i) => {
    out.push({ ...s, idx: i });
    if (/^Verse/i.test(s.label)) out.push({ ...chorus, idx: chorusIdx, repeat: true });
  });
  return out;
}

export function songSlides(song, { lang1, lang2 = "", linesPerSlide = 4, autoChorus = true, order = null } = {}) {
  const raw = song.versions || {};
  // projector text never shows chords; the chord lines travel with the slide for the musicians' stage view
  const versions = {};
  for (const [lg, vv] of Object.entries(raw)) versions[lg] = { ...vv, sections: (vv.sections || []).map(sx => ({ ...sx, chordLines: sx.lines, lines: sx.lines.map(stripChords).filter((x, i, a) => x || !sx.lines[i]) })) };
  const l1 = lang1 && versions[lang1] ? lang1 : Object.keys(versions)[0];
  const v1 = versions[l1];
  const v2 = lang2 && lang2 !== l1 ? versions[lang2] : null;
  if (!v1) return [];
  const per = v2 ? Math.max(2, Math.min(linesPerSlide, 3)) : linesPerSlide;
  // song order: the item's own arrangement, else the song's, else verse/chorus default
  const ord = parseOrder(order ?? song.order ?? "", v1.sections);
  const arr1 = ord ? ord.map((i, k) => ({ ...v1.sections[i], idx: i, repeat: ord.indexOf(i) < k })) : arrange(v1.sections, { autoChorus });
  const slides = [];
  arr1.forEach((sec, si) => {
    const c1 = chunk(sec.lines, per);
    const sec2 = v2 ? (v2.sections[sec.idx] || null) : null;
    const c2 = sec2 ? splitLike(sec2.lines, c1.map(c => c.length)) : [];
    const sizes = c1.map(c => c.length);
    const altChunks = {};
    for (const [lg, vv] of Object.entries(versions)) {
      if (lg === l1) { altChunks[lg] = c1; continue; }
      const sx = vv.sections && vv.sections[sec.idx];
      if (sx) altChunks[lg] = splitLike(sx.lines, sizes);
    }
    c1.forEach((lines, ci) => {
      const alt = {}; for (const [lg, ch] of Object.entries(altChunks)) if (ch[ci] && ch[ci].length) alt[lg] = ch[ci];
      const cl = sec.chordLines ? splitLike(sec.chordLines, c1.map(c => c.length))[ci] : null;
      slides.push({ alt, sectionIdx: sec.idx, color: sectionColor(sec.label), chordLines: cl && cl.some(x => /\[[A-G]/.test(x)) ? cl : null, key: song.key || "",
        kind: "song", songId: song.id, title: v1.title || song.title, label: sec.label + (c1.length > 1 ? ` ${String.fromCharCode(97 + ci)}` : ""),
        section: sec.label, repeat: !!sec.repeat, lines, lines2: c2[ci] || null, lang: l1, lang2: v2 ? lang2 : null,
        ref: (song.books || [])[0] ? `${song.books[0].book} ${song.books[0].num}` : "",
      });
    });
  });
  return slides;
}

function splitLike(lines, sizes) {
  const total = sizes.reduce((a, b) => a + b, 0);
  const out = []; let pos = 0;
  sizes.forEach((sz, i) => {
    const take = i === sizes.length - 1 ? lines.length - pos : Math.round(lines.length * sz / total);
    out.push(lines.slice(pos, pos + take)); pos += take;
  });
  return out;
}

export function textSlides(text, { linesPerSlide = 4, title = "", ref = "", kind = "text" } = {}) {
  const paras = text.split(/\n\s*\n/).map(p => p.split("\n").map(l => l.trim()).filter(Boolean)).filter(p => p.length);
  const slides = [];
  for (const p of paras) for (const c of chunk(p, linesPerSlide)) slides.push({ kind, title, ref, label: "", lines: c });
  return slides;
}

// Split long prose (a verse or a quote) into slides by approximate character budget
export function proseSlides(text, { maxChars = 220, title = "", ref = "", kind = "bible", text2 = "", lang = "", lang2 = "" } = {}) {
  const parts = splitProse(text, maxChars);
  const parts2 = text2 ? splitProse(text2, Math.ceil(maxChars * (text2.length / Math.max(1, text.length)))) : [];
  return parts.map((p, i) => ({ kind, title, ref, label: parts.length > 1 ? `${i + 1}/${parts.length}` : "", lines: [p], lines2: parts2.length ? [parts2[i] || ""] : null, lang, lang2 }));
}
function splitProse(text, maxChars) {
  const words = text.split(/\s+/); const out = []; let cur = "";
  for (const w of words) {
    if ((cur + " " + w).trim().length > maxChars && cur) { out.push(cur.trim()); cur = w; } else cur += " " + w;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}
