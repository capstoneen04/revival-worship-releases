// One light poller for OBS status + health (instead of every page polling on its own).
// S.obsStats = { live, stream, rec, tc, rtc, congestion, fps, renderMs, renderSkipped, outputSkipped, cpu, memMB, level }
import { S, emit } from "./core.js";

let timer = null, last = null, busy = false, n = 0;
S.obsStats = { live: false, level: "off" };

export async function pollNow() {
  if (busy || !S.obs.connected) return;
  busy = true;
  try {
    const [st, rec] = await Promise.all([S.obs.call("GetStreamStatus"), S.obs.call("GetRecordStatus")]);
    const o = S.obsStats;
    o.stream = !!st.outputActive; o.rec = !!rec.outputActive; o.live = o.stream || o.rec;
    o.tc = (st.outputTimecode || "").slice(0, 8); o.rtc = (rec.outputTimecode || "").slice(0, 8);
    o.congestion = st.outputCongestion || 0; o.drop = st.outputSkippedFrames || 0; o.total = st.outputTotalFrames || 0;
    if (n++ % 2 === 0) {
      const s = await S.obs.call("GetStats");
      o.fps = s.activeFps; o.renderMs = s.averageFrameRenderTime; o.cpu = s.cpuUsage; o.memMB = s.memoryUsage;
      // skipped frames in the last few seconds (not since OBS started)
      if (last) {
        o.renderSkipped = s.renderSkippedFrames - last.renderSkippedFrames;
        o.outputSkipped = s.outputSkippedFrames - last.outputSkippedFrames;
      } else { o.renderSkipped = 0; o.outputSkipped = 0; }
      last = s;
      const target = 60;
      o.level = o.renderSkipped > 2 || o.outputSkipped > 2 || o.fps < target * 0.9 || o.renderMs > 14 ? "bad"
        : o.renderMs > 8 || o.renderSkipped > 0 || o.outputSkipped > 0 || o.congestion > 0.25 ? "warn" : "ok";
    }
    emit("obsstats");
  } catch { }
  busy = false;
}
export function startHealth() {
  clearInterval(timer);
  timer = setInterval(() => { if (S.obs.connected) pollNow(); else if (S.obsStats.level !== "off") { S.obsStats = { live: false, level: "off" }; last = null; emit("obsstats"); } }, 1000);
}
export function healthText() {
  const o = S.obsStats;
  if (o.level === "off" || o.fps == null) return "";
  return `${Math.round(o.fps)} fps · ${o.renderMs?.toFixed(1)} ms`;
}
export function healthTip() {
  const o = S.obsStats;
  if (o.fps == null) return "";
  return `OBS health\n• ${o.fps?.toFixed(1)} fps (target 60)\n• frame render ${o.renderMs?.toFixed(1)} ms (good < 8 ms)\n• skipped frames last 2 s: render ${o.renderSkipped}, encoder ${o.outputSkipped}\n• OBS CPU ${o.cpu?.toFixed(0)} %, memory ${Math.round(o.memMB || 0)} MB` + (o.stream ? `\n• network ${(o.congestion * 100).toFixed(0)} % busy` : "");
}
