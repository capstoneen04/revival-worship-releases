// ATEM Mini Pro from the renderer (talks to Electron main, which holds the network connection)
import { S, native, emit, saveSettings, toast } from "./core.js";

export const ATEM = { state: { connected: false }, levels: {}, available: !!native?.atem };

if (native?.onAtemState) native.onAtemState(s => { ATEM.state = s; emit("atem"); });
if (native?.onAtemLevels) native.onAtemLevels(l => { ATEM.levels = l; });

export async function atem(cmd, ...args) {
  if (!native?.atem) throw new Error("ATEM control works in the Mac app");
  const r = await native.atem(cmd, ...args);
  if (!r.ok) throw new Error(r.error);
  return r.result;
}
export async function atemConnect(ip, quiet = false) {
  const a = S.settings.atem;
  try {
    await atem("connect", ip || a.ip || "192.168.10.240");
    a.ip = ip || a.ip || "192.168.10.240"; await saveSettings();
    if (!quiet) toast("Connecting to ATEM at " + a.ip + "…");
    return true;
  } catch (e) { if (!quiet) toast(e.message); return false; }
}
export async function atemDo(cmd, ...args) { try { return await atem(cmd, ...args); } catch (e) { toast(e.message); } }

// Voice presets made from the uploaded ATEM files for Br. Royal and Br. Joseph (Mic 2 = pulpit)
export const DEFAULT_SPEAKERS = [];   // speakers come from the church database (People)
