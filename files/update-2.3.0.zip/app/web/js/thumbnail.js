// YouTube thumbnail designer — follows the church's "premium minimalist" blueprint:
// left half = preacher cut-out, right half = title (heavy condensed caps), preacher (light), event (tracked caps),
// "REVIVAL CHURCH MUMBAI ✦" bottom-right, dark mood-coloured background with soft bokeh.
export const MOODS = {
  burgundy: { name: "Burgundy (fire, blood, love)", base: ["#1c0509", "#4a0c18", "#7a1626"], bokeh: ["#ff7a4d", "#ffc46b", "#ff3d5a", "#ffd9a0"] },
  sapphire: { name: "Sapphire (Spirit, calling, peace)", base: ["#020a1f", "#06215a", "#0d3b91"], bokeh: ["#4fa3ff", "#9fd0ff", "#2f6bff", "#cfe6ff"] },
  emerald: { name: "Emerald (new life, growth, built up)", base: ["#020f08", "#0a2e19", "#155232"], bokeh: ["#8fe39a", "#e8f5a0", "#4fc27a", "#d8ffd0"] },
  indigo: { name: "Indigo (King, kingdom, majesty)", base: ["#07041a", "#1d0f45", "#38207a"], bokeh: ["#b48cff", "#ffd27a", "#8a6bff", "#f0e0ff"] },
  charcoal: { name: "Charcoal (gold light)", base: ["#0c0d10", "#1d2026", "#2c3038"], bokeh: ["#ffc36b", "#ffdf9e", "#e0a040", "#fff2d0"] },
};

function rng(seed) { let s = 0; for (const c of String(seed)) s = (s * 31 + c.charCodeAt(0)) >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
const loadImg = (src) => new Promise((res, rej) => { if (!src) return rej(); const i = new Image(); i.crossOrigin = "anonymous"; i.onload = () => res(i); i.onerror = rej; i.src = src; });
const imgCache = new Map();
async function img(src) { if (!src) return null; if (!imgCache.has(src)) imgCache.set(src, loadImg(src).catch(() => null)); return imgCache.get(src); }

function bokeh(g, W, H, mood, seed) {
  const m = MOODS[mood] || MOODS.charcoal, r = rng(seed);
  const bg = g.createRadialGradient(W * 0.72, H * 0.32, 50, W * 0.6, H * 0.5, W * 0.85);
  bg.addColorStop(0, m.base[2]); bg.addColorStop(0.45, m.base[1]); bg.addColorStop(1, m.base[0]);
  g.fillStyle = bg; g.fillRect(0, 0, W, H);
  // soft out-of-focus lights, mostly top/right (left stays calm for the preacher)
  for (let layer = 0; layer < 2; layer++) {
    g.save(); g.filter = `blur(${layer ? 6 : 26}px)`;
    const n = layer ? 26 : 16;
    for (let i = 0; i < n; i++) {
      const x = W * (0.28 + r() * 0.8), y = H * (r() * r() * 0.95), rad = (layer ? 18 + r() * 46 : 60 + r() * 130);
      const c = m.bokeh[Math.floor(r() * m.bokeh.length)];
      const a = (layer ? 0.10 + r() * 0.22 : 0.08 + r() * 0.16) * (x < W * 0.45 ? 0.5 : 1);
      const gr = g.createRadialGradient(x, y, 0, x, y, rad);
      gr.addColorStop(0, hexA(c, a)); gr.addColorStop(0.7, hexA(c, a * 0.75)); gr.addColorStop(1, hexA(c, 0));
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, rad, 0, Math.PI * 2); g.fill();
    }
    g.restore();
  }
  // vignette
  const v = g.createRadialGradient(W * 0.55, H * 0.45, H * 0.3, W * 0.5, H * 0.5, W * 0.75);
  v.addColorStop(0, "rgba(0,0,0,0)"); v.addColorStop(1, "rgba(0,0,0,.55)");
  g.fillStyle = v; g.fillRect(0, 0, W, H);
}
function hexA(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; }

function wrap(g, text, maxW) {
  const words = text.split(/\s+/).filter(Boolean), out = []; let line = "";
  for (const w of words) { const t = line ? line + " " + w : w; if (g.measureText(t).width > maxW && line) { out.push(line); line = w; } else line = t; }
  if (line) out.push(line);
  return out;
}
function tracked(g, text, x, y, spacing, align = "right") {
  // canvas letterSpacing where available, manual fallback
  if ("letterSpacing" in g) { g.letterSpacing = spacing + "px"; g.textAlign = align; g.fillText(text, x + (align === "right" ? spacing : 0), y); g.letterSpacing = "0px"; return; }
  g.textAlign = "left"; let w = 0; for (const ch of text) w += g.measureText(ch).width + spacing;
  let cx = align === "right" ? x - w + spacing : x; for (const ch of text) { g.fillText(ch, cx, y); cx += g.measureText(ch).width + spacing; }
  g.textAlign = align;
}
function sparkle(g, x, y, s, color) {
  g.save(); g.fillStyle = color; g.beginPath();
  for (let i = 0; i < 8; i++) { const ang = (Math.PI / 4) * i - Math.PI / 2, rr = i % 2 ? s * 0.22 : s; g.lineTo(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr); }
  g.closePath(); g.fill(); g.restore();
}

// o: { title, titleHi, preacher, event, mood, background (url), photo (url), photoScale, photoX, photoY, style: "minimal"|"bilingual", page, seed }
export async function drawThumbnail(canvas, o) {
  const W = 1920, H = 1080; canvas.width = W; canvas.height = H;
  const g = canvas.getContext("2d");
  await Promise.all(["800 100px Oswald", "700 100px Oswald", "400 50px Montserrat", "500 30px Montserrat", "800 30px Montserrat", "600 60px 'Noto Sans Devanagari'"].map(f => document.fonts.load(f).catch(() => { })));
  const bgImg = await img(o.background);
  if (bgImg) {
    const s = Math.max(W / bgImg.width, H / bgImg.height); g.drawImage(bgImg, (W - bgImg.width * s) / 2, (H - bgImg.height * s) / 2, bgImg.width * s, bgImg.height * s);
    g.fillStyle = "rgba(0,0,0,.18)"; g.fillRect(0, 0, W, H);
  } else bokeh(g, W, H, o.mood, o.seed || o.title || "x");

  // preacher cut-out, bottom-left
  const ph = await img(o.photo);
  if (ph) {
    const hgt = H * (o.photoScale || 0.64), wid = ph.width * (hgt / ph.height);
    const x = W * (o.photoX ?? -0.02), y = H - hgt + H * (o.photoY ?? 0);
    g.save(); g.shadowColor = "rgba(0,0,0,.55)"; g.shadowBlur = 60; g.drawImage(ph, x, y, wid, hgt); g.restore();
  }
  // right-hand text block
  const R = W - 96, maxW = o.photo ? 1000 : 1240;
  g.textBaseline = "alphabetic"; g.fillStyle = "#ffffff"; g.textAlign = "right";
  g.shadowColor = "rgba(0,0,0,.45)"; g.shadowBlur = 24; g.shadowOffsetY = 4;
  const title = (o.title || "Sermon title").toUpperCase().replace(/\s+/g, " ").trim();
  let fs = 150, lines;
  for (; fs >= 70; fs -= 4) { g.font = `700 ${fs}px Oswald`; lines = wrap(g, title, maxW); if (lines.length <= 4 && lines.every(l => g.measureText(l).width <= maxW)) break; }
  const lh = fs * 0.98;
  let hiLines = [], hfs = 0;
  if (o.style === "bilingual" && o.titleHi) { hfs = Math.max(38, Math.round(fs * 0.42)); g.font = `600 ${hfs}px 'Noto Sans Devanagari'`; hiLines = wrap(g, o.titleHi, maxW).slice(0, 3); }
  const nameFs = Math.round(Math.max(44, Math.min(58, fs * 0.42))), evFs = 27;
  const blockH = lines.length * lh + (hiLines.length ? 24 + hiLines.length * hfs * 1.35 : 0) + 30 + nameFs + (o.event ? 22 + evFs : 0);
  let y = Math.max(110, Math.min(H * 0.44 - blockH / 2, 260)) + fs * 0.85;
  g.font = `700 ${fs}px Oswald`;
  if ("letterSpacing" in g) g.letterSpacing = "-1px";
  for (const l of lines) { g.fillText(l, R, y); y += lh; }
  if ("letterSpacing" in g) g.letterSpacing = "0px";
  y -= lh - fs * 0.15;
  if (hiLines.length) { g.font = `600 ${hfs}px 'Noto Sans Devanagari'`; g.fillStyle = "#f1d391"; y += 18; for (const l of hiLines) { y += hfs * 1.32; g.fillText(l, R, y); } g.fillStyle = "#ffffff"; }
  y += 22 + nameFs;
  g.font = `400 ${nameFs}px Montserrat`; if (o.preacher) g.fillText(o.preacher, R, y);
  if (o.event) { y += 18 + evFs; g.font = `500 ${evFs}px Montserrat`; g.fillStyle = "rgba(255,255,255,.88)"; tracked(g, o.event.toUpperCase(), R, y, 3); g.fillStyle = "#fff"; }
  g.shadowColor = "transparent";
  // branding
  g.font = "800 24px Montserrat"; const w1 = g.measureText("REVIVAL ").width; g.font = "400 24px Montserrat"; const w2 = g.measureText("CHURCH MUMBAI").width;
  g.textAlign = "left"; g.fillStyle = "rgba(255,255,255,.92)";
  g.font = "800 24px Montserrat"; g.fillText("REVIVAL ", R - w1 - w2, H - 64);
  g.font = "400 24px Montserrat"; g.fillText("CHURCH MUMBAI", R - w2, H - 64);
  sparkle(g, R - 24, H - 128, 22, "rgba(255,255,255,.85)"); sparkle(g, R - 52, H - 112, 9, "rgba(255,255,255,.6)");
  g.textAlign = "right";
  return canvas;
}

// the Gemini prompt from the church's blueprint, filled in — for a custom AI background
export function geminiPrompt({ title, preacher, event, mood }) {
  const m = MOODS[mood] || MOODS.charcoal;
  return `Role: You are an expert YouTube Thumbnail Designer specializing in Apple-inspired, premium, and minimalist aesthetics.

Generate a 1920x1080 YouTube thumbnail BACKGROUND ONLY (no text, no people).
- Split the 16:9 canvas into two halves. The LEFT half must stay completely empty and calm (negative space) — a photographic cut-out of a right-facing preacher will be placed there.
- The RIGHT half is reserved for white text added later, so keep it dark, clean and uncrowded.
- Clean, high-contrast, premium. No messy glow effects, no cluttered images. Use subtle bokeh, soft lighting gradients or rich textures for depth.
- Colour theme: ${m.name.replace(/ \(.*/, "")} — deep, dark and muted so white text pops.

Sermon title (for mood only, do not write it): ${title || ""}
Preacher: ${preacher || ""}
Event: ${event || ""}`;
}
