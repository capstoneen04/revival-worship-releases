// Automatic sound helper — for churches without a sound engineer.
// The whole mixer mix arrives on ATEM Mic 2, so the app can't separate instruments; what it can do safely:
//  • sound MODES (Worship / Preaching / Prayer): processing for music vs. speech on Mic 2 (ATEM Fairlight),
//    or — when the ATEM is not on the network — OBS filters on the ATEM's audio in OBS;
//  • AUTO LEVEL: a slow, limited "hand on the fader" that keeps YouTube loudness steady when the band
//    overplays or someone speaks softly (never more than −10 / +6 dB, never during pauses);
//  • a hard limiter so nothing ever distorts, plus alerts: no sound while live, distortion, feedback,
//    "singers buried under the band" with a one-click vocal lift and a message to the stage display.
import { S, emit, onChange, saveSettings, broadcast, toast } from "./core.js";
import { ATEM, atem } from "./atem-client.js";
import { monitor, AudioMonitor } from "./audio-monitor.js";

export const MODES = {
  worship: {
    label: "Worship", icon: "🎵", target: -15, hint: "Band + singers: gentle compression, singers a little forward, never gated.",
    atem: { input: 1302, hpf: 70, mudF: 350, mudG: -2, presF: 2800, presG: 2, airG: 0, compTh: -20, ratio: 2.5, compAttack: 20, compRelease: 250, makeup: 3, limTh: -3, gateOff: true, mixOn: true, cameraAudioOff: true, masterSafe: true },
    obs: { eq: { low: -2, mid: 1, high: 0 }, comp: { ratio: 2.5, threshold: -20, attack_time: 20, release_time: 250, output_gain: 2 } },
  },
  preaching: {
    label: "Preaching", icon: "🎤", target: -16, hint: "Voice: speaker preset (clean low end, clear words, steady level).",
    atem: { input: 1302, hpf: 100, mudF: 250, mudG: -3, presF: 3500, presG: 3, airG: 2, gateTh: -48, compTh: -22, ratio: 3, makeup: 4, mixOn: true, cameraAudioOff: true, masterSafe: true },
    obs: { eq: { low: -4, mid: 2, high: 1 }, comp: { ratio: 3, threshold: -22, attack_time: 6, release_time: 150, output_gain: 3 } },
  },
  prayer: {
    label: "Prayer", icon: "🙏", target: -17, hint: "Soft voices over quiet music: more lift for soft words, no gate.",
    atem: { input: 1302, hpf: 90, mudF: 300, mudG: -2, presF: 3200, presG: 2, airG: 1, compTh: -28, ratio: 3, compAttack: 10, compRelease: 200, makeup: 6, limTh: -3, gateOff: true, mixOn: true, cameraAudioOff: true, masterSafe: true },
    obs: { eq: { low: -2, mid: 2, high: 0 }, comp: { ratio: 3, threshold: -28, attack_time: 10, release_time: 200, output_gain: 5 } },
  },
};
const FLOOR = -10, CEIL = 6;                    // auto level never goes beyond these (dB from the mode's normal)
const F_EQ = "RW Sound EQ", F_COMP = "RW Sound Compressor", F_LIM = "RW Sound Limiter";

const A = () => {
  const d = { deviceId: "", auto: true, sceneModes: true, autoTone: false, autoStart: true, mode: "preaching", offsets: { worship: 0, preaching: 0, prayer: 0 }, obsInput: "" };
  const a = S.settings.audio = Object.assign(d, S.settings.audio || {});
  a.offsets = Object.assign({ worship: 0, preaching: 0, prayer: 0 }, a.offsets || {});
  return a;
};

export const sound = {
  backend: "none", obsInput: "", applied: null, voice: null, log: [], alerts: [], status: "", level: "off",
  hi: 0, lo: 0, lastStep: 0, lastSet: null, toneDone: false, silentSince: 0, lastPeaks: 0,
};
let saveT = 0;
const saveSoon = () => { clearTimeout(saveT); saveT = setTimeout(() => saveSettings(), 3000); };
function note(t) { const d = new Date(); sound.log.unshift(`${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")} ${t}`); sound.log.length = Math.min(sound.log.length, 8); }

// ---------- where to act ----------
async function findObsAudio() {
  if (!S.obs.connected) return "";
  const a = A();
  const { inputs } = await S.obs.call("GetInputList");
  const names = inputs.map(i => i.inputName);
  if (a.obsInput && names.includes(a.obsInput)) return a.obsInput;
  const cands = [];
  for (const i of inputs) {
    if (!/coreaudio|avcapture|av_capture|wasapi_input|dshow|pulse|alsa/.test(i.inputKind)) continue;
    let st = {}; try { st = (await S.obs.call("GetInputSettings", { inputName: i.inputName })).inputSettings || {}; } catch { }
    const txt = i.inputName + " " + JSON.stringify(st);
    try { await S.obs.call("GetInputVolume", { inputName: i.inputName }); } catch { continue; }   // no audio
    cands.push({ name: i.inputName, score: (/blackmagic|atem/i.test(txt) ? 2 : 0) + (/coreaudio|wasapi|pulse|alsa/.test(i.inputKind) ? 1 : 0) });
  }
  cands.sort((x, y) => y.score - x.score);
  return cands[0] && cands[0].score >= 2 ? cands[0].name : "";
}
async function pickBackend() {
  const prev = sound.backend + sound.obsInput;
  if (ATEM.state.connected) { sound.backend = "atem"; sound.obsInput = ""; }
  else if (S.obs.connected) { sound.obsInput = await findObsAudio().catch(() => ""); sound.backend = sound.obsInput ? "obs" : "none"; }
  else sound.backend = "none";
  if (prev !== sound.backend + sound.obsInput) {
    sound.applied = null; sound.lastSet = null;
    if (sound.backend === "atem") await obsFilters(false).catch(() => { });     // never process twice
    if (A().auto) await applyMode(A().mode, "connected").catch(() => { });
  }
}

// ---------- OBS filter chain on the ATEM's audio ----------
async function obsFilter(name, kind, settings) {
  const sourceName = sound.obsInput;
  try { await S.obs.call("GetSourceFilter", { sourceName, filterName: name }); await S.obs.call("SetSourceFilterSettings", { sourceName, filterName: name, filterSettings: settings, overlay: true }); }
  catch { await S.obs.call("CreateSourceFilter", { sourceName, filterName: name, filterKind: kind, filterSettings: settings }); }
  await S.obs.call("SetSourceFilterEnabled", { sourceName, filterName: name, filterEnabled: true });
}
async function obsFilters(on) {
  if (!S.obs.connected) return;
  const { inputs } = await S.obs.call("GetInputList");
  if (on) return;
  for (const i of inputs) for (const f of [F_EQ, F_COMP, F_LIM]) {
    try { await S.obs.call("SetSourceFilterEnabled", { sourceName: i.inputName, filterName: f, filterEnabled: false }); } catch { }
  }
}

// ---------- modes ----------
export async function applyMode(mode, why = "") {
  const a = A(), m = MODES[mode]; if (!m) return;
  a.mode = mode; saveSoon();
  sound.toneDone = false; sound.hi = sound.lo = 0;
  if (sound.backend === "atem") {
    const p = mode === "preaching" && sound.voice ? { ...sound.voice, mixOn: true, cameraAudioOff: true, masterSafe: true } : m.atem;
    const { gain, fader, ...rest } = p;      // never touch the input gain the team set on the mixer/ATEM; the fader belongs to the auto level
    await atem("voice", rest);
    await setLevel(a.offsets[mode] || 0);
  } else if (sound.backend === "obs") {
    await obsFilter(F_EQ, "basic_eq_filter", m.obs.eq);
    await obsFilter(F_COMP, "compressor_filter", { ...m.obs.comp, sidechain_source: "none" });
    await obsFilter(F_LIM, "limiter_filter", { threshold: -1, release_time: 60 });
    await setLevel(a.offsets[mode] || 0);
  }
  sound.applied = mode;
  note(`${m.icon} ${m.label}${why ? " (" + why + ")" : ""}`);
  emit("sound");
}
export async function setMode(mode, why = "manual") {
  try { await applyMode(mode, why); }
  catch (e) { toast("Sound: " + e.message); }
}
export async function speakerOn(sp) {                     // Produce → Speaker on
  sound.voice = sp?.voice || null;
  if (A().auto || sound.backend === "atem") await setMode("preaching", sp?.name || "speaker");
}

// ---------- the level ("hand on the fader") ----------
async function setLevel(db) {
  db = Math.max(FLOOR, Math.min(CEIL, Math.round(db * 2) / 2));
  if (sound.backend === "atem") await atem("nudge", { input: 1302, fader: db });
  else if (sound.backend === "obs") await S.obs.call("SetInputVolume", { inputName: sound.obsInput, inputVolumeDb: db });
  sound.lastSet = db;
  return db;
}
function currentLevel() {
  if (sound.backend === "atem") return ATEM.state.audio?.["1302"]?.fader ?? null;
  return sound.lastSet;
}
async function step(delta, why) {
  const a = A(), mode = a.mode;
  // someone moved the fader by hand (ATEM Software Control) → respect it as the new normal
  const cur = currentLevel();
  if (sound.backend === "atem" && cur != null && sound.lastSet != null && Math.abs(cur - sound.lastSet) > 0.6) { a.offsets[mode] = cur; sound.lastSet = cur; note(`Hand change noticed: ${cur.toFixed(1)} dB`); saveSoon(); return; }
  const from = a.offsets[mode] || 0, to = Math.max(FLOOR, Math.min(CEIL, from + delta));
  if (to === from) return;
  a.offsets[mode] = await setLevel(to);
  sound.lastStep = Date.now(); saveSoon();
  note(`${delta < 0 ? "▼" : "▲"} ${to > 0 ? "+" : ""}${to.toFixed(1)} dB — ${why}`);
}

// ---------- every second ----------
async function tick() {
  const a = A(), st = monitor.state || {};
  const alerts = [];
  if (!monitor.running) { sound.status = "Sound check is off"; sound.level = "off"; sound.alerts = []; emit("sound"); return; }
  const live = !!S.obsStats?.stream;
  const L = st.short, M = st.momentary;
  // 1. silence while live
  if (live && !(M > -55)) { sound.silentSince ||= Date.now(); } else sound.silentSince = 0;
  if (sound.silentSince && Date.now() - sound.silentSince > 10000) alerts.push({ level: "bad", title: "No sound going to YouTube", detail: "Nothing for 10 seconds while live. Check the mixer's stream output, the cable into ATEM Mic 2, and that Mic 2 is ON.", action: sound.backend === "atem" ? { label: "Turn Mic 2 on", fn: () => atem("nudge", { input: 1302, mixOn: true }) } : null });
  // 2. distortion
  const peaksNow = monitor.peaks.length;
  if (peaksNow >= 3) alerts.push({ level: "bad", title: "Distorting on loud moments", detail: "Turn the stream output on the mixer down a little. The app is lowering the level and the limiter is on." });
  // 3. feedback
  if (st.feedback) alerts.push({ level: "bad", title: `Whistle / feedback around ${st.feedback.hz >= 1000 ? (st.feedback.hz / 1000).toFixed(1) + " kHz" : st.feedback.hz + " Hz"}`, detail: "Lower the pulpit/vocal mic on the mixer straight away, or turn the mic away from the speakers. (The stream can't remove it — it is in the room.)" });

  const mode = a.mode, m = MODES[mode];
  // 4. automatic level — only on real programme, never in pauses
  if (a.auto && sound.backend !== "none" && sound.applied && m && isFinite(L) && L > -38) {
    const eff = sound.backend === "obs" ? L + (sound.lastSet || 0) : L;        // OBS acts after the point we listen to
    const err = eff - m.target;
    sound.hi = err > 2.5 ? sound.hi + 1 : 0;
    sound.lo = err < -3 ? sound.lo + 1 : 0;
    const since = Date.now() - sound.lastStep;
    if (peaksNow > sound.lastPeaks + 1 && since > 1500) await step(-1, "peaks").catch(() => { });
    else if (sound.hi >= 3 && since > 2000) { await step(err > 6 ? -2 : -1, mode === "worship" ? "music loud" : "too loud").catch(() => { }); sound.hi = 0; }
    else if (sound.lo >= 6 && since > 4000) { await step(+1, "too soft").catch(() => { }); sound.lo = 0; }
  }
  sound.lastPeaks = peaksNow;

  // 5. worship: are the singers buried under the band?
  if (mode === "worship") {
    const H = (monitor.history || []).slice(-100).filter(b => -0.691 + 10 * Math.log10(b.ms || 1e-12) > -35);
    if (H.length > 50) {
      const avg = (k) => 10 * Math.log10(H.reduce((s, b) => s + Math.pow(10, b.bands[k] / 10), 0) / H.length);
      const low = avg("low"), mud = avg("mud"), mid = avg("mid");
      const buried = low - mid > 8 || mud - mid > 6;
      if (buried) {
        const what = low - mid > 8 ? "bass / drums" : "keyboard / guitars";
        alerts.push({ level: "warn", title: `Singers buried under the ${what}`, detail: "Ask the band to play softer (sends a note to the stage display), or lift the singers on the stream.", action: { label: "Lift singers", fn: () => vocalLift() }, action2: { label: "🎵 Tell band", fn: () => stageMsg("🎵 Music a little softer please") } });
        if (a.autoTone && !sound.toneDone) await vocalLift().catch(() => { });
      }
    }
    if ((a.offsets.worship || 0) <= -6) alerts.push({ level: "warn", title: "The band is much louder than usual", detail: `The app has turned the music down ${Math.abs(a.offsets.worship).toFixed(0)} dB to keep YouTube steady. Ask the musicians to play softer, or turn down the stream output on the mixer.`, action2: { label: "🎵 Tell band", fn: () => stageMsg("🎵 Music a little softer please") } });
  }
  if ((a.offsets[mode] || 0) >= CEIL) alerts.push({ level: "warn", title: "Still too soft at the limit", detail: "Turn up the stream (AUX) output on the mixer a little, or the Mic 2 gain in ATEM Software Control." });

  sound.alerts = alerts;
  const off = a.offsets[mode] || 0;
  sound.level = alerts.some(x => x.level === "bad") ? "bad" : alerts.length ? "warn" : "ok";
  sound.status = `${m ? m.icon + " " + m.label : ""}${a.auto && sound.backend !== "none" ? ` · auto ${off > 0 ? "+" : ""}${off.toFixed(1)} dB` : ""}`;
  emit("sound");
}
async function vocalLift() {
  sound.toneDone = true;
  if (sound.backend === "atem") { await atem("nudge", { input: 1302, band: 2, freq: 350, gainAdd: -2 }); await atem("nudge", { input: 1302, band: 3, freq: 2800, gainAdd: 2 }); }
  else if (sound.backend === "obs") await obsFilter(F_EQ, "basic_eq_filter", { low: -5, mid: 3, high: 0 });
  else return;
  note("Singers lifted (less low-mid, more presence)");
}
export function stageMsg(t) { S.stageMessage = t; broadcast(); note(t ? `Stage: ${t}` : "Stage message cleared"); emit("sound"); if (t) setTimeout(() => { if (S.stageMessage === t) { S.stageMessage = ""; broadcast(); emit("sound"); } }, 45000); }

// follow the OBS scene: Worship scenes → Worship, Sermon/Scripture → Preaching, Prayer → Prayer
function sceneMode(name = "") {
  if (/worship|song|praise/i.test(name)) return "worship";
  if (/prayer/i.test(name)) return "prayer";
  if (/sermon|scripture|preach|message/i.test(name)) return "preaching";
  return null;                                                                       // Starting, Welcome, Ending… keep as is
}

let started = false, lastScene = "";
export function startSound() {
  if (started) return; started = true;
  A();
  setInterval(() => tick().catch(() => { }), 1000);
  setInterval(() => pickBackend().catch(() => { }), 5000);
  onChange(async (w) => {
    if (w === "atem" || w === "obs") { if ((ATEM.state.connected ? "atem" : "x") !== (sound.backend === "atem" ? "atem" : "x")) pickBackend().catch(() => { }); }
    if (w === "obs" && A().sceneModes && S.obsScenes.current !== lastScene) {
      lastScene = S.obsScenes.current;
      const md = sceneMode(lastScene);
      if (md && md !== A().mode && sound.backend !== "none") setMode(md, "scene");
    }
  });
  // listen from the start (needs the microphone permission the app asks for)
  setTimeout(async () => {
    if (!A().autoStart || monitor.running) return;
    try { const devs = await AudioMonitor.devices(); const id = devs.find(d => d.id === A().deviceId)?.id || AudioMonitor.pickDefault(devs); if (id && devs.find(d => d.id === id && /blackmagic|atem/i.test(d.label))) { await monitor.start(id); emit("sound"); } } catch { }
  }, 4000);
}
