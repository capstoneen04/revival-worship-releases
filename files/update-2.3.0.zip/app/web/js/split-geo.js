// Geometry of the split scenes (1920×1080). Shared by the split template and the app (camera placement + auto-framing).
// layout: "landscape" = wide camera + verse beside it; "portrait" = tall camera (speaker framed automatically) + big verse box.
export function splitGeo(layout = "landscape", side = "left") {
  let cam, panel, strip;
  if (layout === "portrait") {
    cam = { x: 96, y: 70, w: 540, h: 940 };
    panel = { x: 712, y: 70, w: 1112, h: 830 };
    strip = { x: 712, y: 920, w: 1112, h: 90 };
  } else {
    cam = { x: 60, y: 70, w: 1110, h: 624 };
    panel = { x: 1220, y: 70, w: 630, h: 624 };
    strip = { x: 58, y: 748, w: 1792, h: 272 };
  }
  if (side === "right") {
    const flip = r => ({ ...r, x: 1920 - r.x - r.w });
    cam = flip(cam); panel = flip(panel); strip = layout === "portrait" ? flip(strip) : strip;
  }
  return { cam, panel, strip, layout, side };
}
