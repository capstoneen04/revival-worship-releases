// Add a Bible version from a file: Zefania XML, OSIS XML, USFX XML, or a Revival Worship Bible JSON.
// Free versions to download: ebible.org (e.g. Marathi IRV, Hindi IRV, many Indian languages — Zefania/OSIS/USFX downloads).
import { BOOKS_EN } from "./bible.js";

const OSIS = ["Gen", "Exod", "Lev", "Num", "Deut", "Josh", "Judg", "Ruth", "1Sam", "2Sam", "1Kgs", "2Kgs", "1Chr", "2Chr", "Ezra", "Neh", "Esth", "Job", "Ps", "Prov", "Eccl", "Song", "Isa", "Jer", "Lam", "Ezek", "Dan", "Hos", "Joel", "Amos", "Obad", "Jonah", "Mic", "Nah", "Hab", "Zeph", "Hag", "Zech", "Mal",
  "Matt", "Mark", "Luke", "John", "Acts", "Rom", "1Cor", "2Cor", "Gal", "Eph", "Phil", "Col", "1Thess", "2Thess", "1Tim", "2Tim", "Titus", "Phlm", "Heb", "Jas", "1Pet", "2Pet", "1John", "2John", "3John", "Jude", "Rev"];
const USFM = ["GEN", "EXO", "LEV", "NUM", "DEU", "JOS", "JDG", "RUT", "1SA", "2SA", "1KI", "2KI", "1CH", "2CH", "EZR", "NEH", "EST", "JOB", "PSA", "PRO", "ECC", "SNG", "ISA", "JER", "LAM", "EZK", "DAN", "HOS", "JOL", "AMO", "OBA", "JON", "MIC", "NAM", "HAB", "ZEP", "HAG", "ZEC", "MAL",
  "MAT", "MRK", "LUK", "JHN", "ACT", "ROM", "1CO", "2CO", "GAL", "EPH", "PHP", "COL", "1TH", "2TH", "1TI", "2TI", "TIT", "PHM", "HEB", "JAS", "1PE", "2PE", "1JN", "2JN", "3JN", "JUD", "REV"];

function empty() { return { books: BOOKS_EN.slice(), text: BOOKS_EN.map(() => []) }; }
const put = (b, bi, c, v, t) => { if (bi < 0 || bi > 65 || c < 1 || v < 1) return; (b.text[bi][c - 1] ||= [])[v - 1] = (t || "").replace(/\s+/g, " ").trim(); };
const tidy = (b) => { b.text = b.text.map(ch => Array.from(ch, c => Array.from(c || [], v => v || ""))); return b; };

function zefania(doc) {
  const b = empty(); b.title = doc.documentElement.getAttribute("biblename") || "";
  for (const bk of doc.getElementsByTagName("BIBLEBOOK")) {
    const bi = +bk.getAttribute("bnumber") - 1; if (bk.getAttribute("bname")) b.books[bi] = bk.getAttribute("bname");
    for (const ch of bk.getElementsByTagName("CHAPTER")) for (const v of ch.getElementsByTagName("VERS")) put(b, bi, +ch.getAttribute("cnumber"), +v.getAttribute("vnumber"), v.textContent);
  }
  return tidy(b);
}
function osis(doc) {
  const b = empty();
  b.title = doc.getElementsByTagName("title")[0]?.textContent || "";
  const verses = doc.getElementsByTagName("verse");
  const parse = (id) => { const m = (id || "").split(" ")[0].match(/^([1-3]?[A-Za-z]+)\.(\d+)\.(\d+)/); return m ? [OSIS.indexOf(m[1]), +m[2], +m[3]] : null; };
  for (const v of verses) {
    if (v.getAttribute("osisID") && !v.getAttribute("sID")) { const r = parse(v.getAttribute("osisID")); if (r) put(b, r[0], r[1], r[2], v.textContent); continue; }
    const sid = v.getAttribute("sID"); if (!sid) continue;
    const r = parse(v.getAttribute("osisID") || sid); if (!r) continue;
    let t = "", n = v.nextSibling;                                                  // milestone style: text until the matching eID
    const walk = (node) => { while (node) { if (node.nodeType === 1 && node.nodeName === "verse" && node.getAttribute("eID")) return true; if (node.nodeType === 3) t += node.textContent; else if (node.nodeType === 1 && !/^(note|title)$/.test(node.nodeName)) { if (walk(node.firstChild)) return true; } node = node.nextSibling; } return false; };
    walk(n); put(b, r[0], r[1], r[2], t);
  }
  for (const d of doc.getElementsByTagName("div")) if (d.getAttribute("type") === "book") { const i = OSIS.indexOf(d.getAttribute("osisID")); const t = [...d.children].find(c => c.nodeName === "title"); if (i >= 0 && t) b.books[i] = t.textContent.trim(); }
  return tidy(b);
}
function usfx(doc) {
  const b = empty();
  for (const bk of doc.getElementsByTagName("book")) {
    const bi = USFM.indexOf((bk.getAttribute("id") || "").toUpperCase()); if (bi < 0) continue;
    const h = bk.getElementsByTagName("h")[0]; if (h) b.books[bi] = h.textContent.trim();
    let c = 0, v = 0, buf = "";
    const flush = () => { if (c && v) put(b, bi, c, v, buf); buf = ""; };
    const walk = (node) => { for (const n of node.childNodes) {
      if (n.nodeType === 3) { if (v) buf += n.textContent; continue; }
      if (n.nodeType !== 1) continue;
      if (n.nodeName === "c") { flush(); c = +n.getAttribute("id"); v = 0; continue; }
      if (n.nodeName === "v") { flush(); v = +n.getAttribute("id"); continue; }
      if (n.nodeName === "ve") { flush(); v = 0; continue; }
      if (/^(f|x|h|toc|id|ide|rem)$/.test(n.nodeName)) continue;
      walk(n);
    } };
    walk(bk); flush();
  }
  return tidy(b);
}

export async function readBibleFile(file) {
  const text = await file.text();
  if (/^\s*[{[]/.test(text)) { const j = JSON.parse(text); if (Array.isArray(j.text)) return { books: j.books || BOOKS_EN, text: j.text, title: j.title || "", format: "JSON" }; throw new Error("Unknown JSON Bible"); }
  const doc = new DOMParser().parseFromString(text, "application/xml");
  if (doc.getElementsByTagName("parsererror").length) throw new Error("This file is not valid XML");
  const root = doc.documentElement.nodeName;
  let b, format;
  if (root === "XMLBIBLE" || doc.getElementsByTagName("BIBLEBOOK").length) { b = zefania(doc); format = "Zefania"; }
  else if (root === "osis" || doc.getElementsByTagName("osisText").length) { b = osis(doc); format = "OSIS"; }
  else if (root === "usfx" || doc.getElementsByTagName("usfx").length) { b = usfx(doc); format = "USFX"; }
  else throw new Error("Unknown Bible format (use Zefania, OSIS or USFX XML)");
  const verses = b.text.reduce((n, bk) => n + bk.reduce((m, c) => m + c.length, 0), 0);
  if (verses < 100) throw new Error("Hardly any verses found in this file");
  return { ...b, format, verses };
}
