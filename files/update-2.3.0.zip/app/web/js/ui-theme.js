// App look: dark (default), light (white) or match the Mac. Remembered on this Mac.
import { native } from "./core.js";
const KEY = "rw-ui";
const mq = matchMedia("(prefers-color-scheme: dark)");
export function uiPref() { try { return localStorage.getItem(KEY) || "dark"; } catch { return "dark"; } }
export function uiResolved(p = uiPref()) { return p === "auto" ? (mq.matches ? "dark" : "light") : p; }
export function applyUi(p = uiPref()) {
  document.documentElement.dataset.ui = uiResolved(p);
  try { native?.setUiTheme?.(p === "auto" ? "system" : p); } catch { }
  const b = document.getElementById("btn-ui");
  if (b) { const r = uiResolved(p); b.textContent = p === "auto" ? "◐" : r === "light" ? "☀︎" : "☾"; b.title = `Look: ${p === "auto" ? "match the Mac" : r === "light" ? "light (white)" : "dark"} — click to change`; }
  window.dispatchEvent(new Event("rw-ui"));
}
export function setUi(p) { try { localStorage.setItem(KEY, p); } catch { } applyUi(p); }
export function cycleUi() { const order = ["dark", "light", "auto"]; setUi(order[(order.indexOf(uiPref()) + 1) % order.length]); }
export function startUi() {
  applyUi();
  mq.addEventListener("change", () => { if (uiPref() === "auto") applyUi(); });
  const b = document.getElementById("btn-ui"); if (b) b.onclick = cycleUi;
}
// read a theme colour (for canvas drawing)
export function cssVar(name, fallback) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback; }
