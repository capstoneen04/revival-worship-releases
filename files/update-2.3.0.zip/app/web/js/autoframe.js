// Split scenes: landscape / portrait swap, and auto-framing of the speaker in the tall portrait window.
// Face detection runs here in the app (offline model, no internet); OBS only receives the new crop of the camera.
import { S, emit, saveSettings, toast } from "./core.js";
import { splitGeo } from "./split-geo.js";

export const SPLIT_SCENES = ["Revival · 4 Worship Split", "Revival · 6 Sermon Split"];
const CAM = "RW Church Camera";
const ZOOM = { wide: 0.09, medium: 0.15, close: 0.22 };   // face height as a share of the frame height

let worker = null, workerReady = null, timer = null, anim = null, busy = false, lastSeen = 0, lastDetect = 0, reqId = 0;
const ids = {};
let src = { w: 1920, h: 1080 }, cur = null, tgt = null, track = null;
export const AF = { status: "off", faces: 0, box: null, mode: "", ms: 0 };

// Face finding runs in a background worker (never blocks the app) and, when it can, reads the camera
// directly — the same ATEM/OBSBOT feed OBS uses — so OBS is not asked for any screenshots at all.
function loadModel() {
  if (workerReady) return workerReady;
  worker = new Worker(new URL("./face-worker.js", import.meta.url), { type: "module" });
  workerReady = new Promise((res, rej) => {
    const onMsg = (e) => { if (e.data.type === "ready") { worker.removeEventListener("message", onMsg); res(e.data.backend); } else if (e.data.type === "error") { worker.removeEventListener("message", onMsg); rej(new Error(e.data.error)); } };
    worker.addEventListener("message", onMsg);
    worker.postMessage({ type: "init", base: new URL("../", import.meta.url).href });
  });
  return workerReady;
}
function findFaces(bitmap) {
  return new Promise((res) => {
    const id = ++reqId;
    const onMsg = (e) => { if (e.data.type === "faces" && e.data.id === id) { worker.removeEventListener("message", onMsg); res(e.data); } };
    worker.addEventListener("message", onMsg);
    worker.postMessage({ type: "frame", id, bitmap }, [bitmap]);
    setTimeout(() => { worker.removeEventListener("message", onMsg); res({ faces: [], w: 1, h: 1, timeout: true }); }, 4000);
  });
}

// ---- frames: camera directly (preferred) or a small OBS snapshot (fallback) ----
let camStream = null, camVideo = null, camLabel = "", camFailedAt = 0;
async function openCamera() {
  if (camVideo) return true;
  if (Date.now() - camFailedAt < 30000) return false;      // don't keep retrying every look
  camFailedAt = Date.now();
  try {
    const { inputSettings } = await S.obs.call("GetInputSettings", { inputName: CAM });
    const want = (inputSettings.device_name || "").toLowerCase();
    if (!want) return false;
    if (window.revival?.askCamera && !(await window.revival.askCamera())) return false;
    let devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === "videoinput");
    if (devs.every(d => !d.label)) { const t = await navigator.mediaDevices.getUserMedia({ video: true }); t.getTracks().forEach(x => x.stop()); devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === "videoinput"); }
    const dev = devs.find(d => d.label.toLowerCase() === want) || devs.find(d => d.label && (want.includes(d.label.toLowerCase()) || d.label.toLowerCase().includes(want)));
    if (!dev) return false;
    camStream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: { exact: dev.deviceId }, width: { ideal: 640 }, height: { ideal: 360 }, frameRate: { ideal: 10, max: 15 } }, audio: false });
    camVideo = document.createElement("video"); camVideo.muted = true; camVideo.playsInline = true; camVideo.srcObject = camStream;
    await camVideo.play(); camLabel = dev.label; camFailedAt = 0;
    return true;
  } catch { closeCamera(); return false; }
}
function closeCamera() { try { camStream?.getTracks().forEach(t => t.stop()); } catch { } camStream = null; camVideo = null; }
async function grabFrame(onAir) {
  if (await openCamera()) { AF.mode = "camera"; return createImageBitmap(camVideo, { resizeWidth: 512, resizeHeight: Math.round(512 * camVideo.videoHeight / camVideo.videoWidth) || 288 }); }
  if (!onAir) return null;                       // snapshots cost OBS a GPU read-back: only while the split scene is on air
  AF.mode = "obs";
  const r = await S.obs.call("GetSourceScreenshot", { sourceName: CAM, imageFormat: "jpg", imageWidth: 512, imageCompressionQuality: 60 });
  const blob = await (await fetch(r.imageData)).blob();
  return createImageBitmap(blob);
}

function settings() { const b = S.settings.broadcast; return { layout: b.splitLayout || "landscape", side: b.splitSide || "left", auto: b.autoFrame !== false, zoom: b.frameZoom || "medium" }; }

// put the camera into the right window in both split scenes
export async function applySplitLayout() {
  if (!S.obs.connected) return;
  const st = settings(), g = splitGeo(st.layout, st.side);
  for (const scene of SPLIT_SCENES) {
    try {
      const { sceneItemId } = await S.obs.call("GetSceneItemId", { sceneName: scene, sourceName: CAM });
      ids[scene] = sceneItemId;
      const { sceneItemTransform: t } = await S.obs.call("GetSceneItemTransform", { sceneName: scene, sceneItemId });
      if (t.sourceWidth) src = { w: t.sourceWidth, h: t.sourceHeight };
      const crop = st.layout === "portrait" ? cropFor(cur || centreBox(g)) : { cropLeft: 0, cropRight: 0, cropTop: 0, cropBottom: 0 };
      await S.obs.call("SetSceneItemTransform", { sceneName: scene, sceneItemId, sceneItemTransform: { positionX: g.cam.x, positionY: g.cam.y, alignment: 5, boundsType: "OBS_BOUNDS_SCALE_OUTER", boundsAlignment: 0, boundsWidth: g.cam.w, boundsHeight: g.cam.h, ...crop } });
    } catch { }
  }
  if (st.layout === "portrait" && st.auto) start(); else stop();
}
function centreBox(g) { const h = src.h, w = h * g.cam.w / g.cam.h; return { x: (src.w - w) / 2, y: 0, w, h }; }
function cropFor(b) {
  const L = Math.round(Math.max(0, b.x)), T = Math.round(Math.max(0, b.y));
  return { cropLeft: L, cropTop: T, cropRight: Math.max(0, Math.round(src.w - b.x - b.w)), cropBottom: Math.max(0, Math.round(src.h - b.y - b.h)) };
}

export async function setSplit(changes) {
  Object.assign(S.settings.broadcast, changes);
  await saveSettings();
  cur = null; await applySplitLayout(); emit("autoframe");
}

let ready = false;
function start() {
  if (timer) return;
  AF.status = "starting"; emit("autoframe");
  loadModel().then(() => { ready = true; AF.status = "searching"; emit("autoframe"); }).catch(e => { AF.status = "error"; toast("Auto-framing could not start: " + e.message); stop(); });
  timer = setInterval(detect, 200);
  anim = setInterval(step, 80);
}
export function stop() { clearInterval(timer); clearInterval(anim); timer = anim = null; closeCamera(); AF.status = "off"; emit("autoframe"); }

async function detect() {
  if (busy || !ready || !S.obs.connected) return;
  const onAir = SPLIT_SCENES.includes(S.obsScenes.current);
  // on air: ~2 looks a second; off air: keep the framing ready every 2 s (camera mode only, costs OBS nothing)
  if (Date.now() - lastDetect < (onAir ? 450 : 2000)) return;
  busy = true; lastDetect = Date.now();
  try {
    const bm = await grabFrame(onAir);
    if (!bm) { busy = false; return; }
    const r = await findFaces(bm);
    AF.ms = Math.round(r.ms || 0);
    const k = src.w / (r.w || 1);
    const faces = (r.faces || []).map(d => ({ x: d.x * k, y: d.y * k, w: d.w * k, h: d.h * k, s: d.s }));
    AF.faces = faces.length;
    const st = settings(), g = splitGeo(st.layout, st.side);
    if (faces.length) {
      // one person: stay with the face we were following; otherwise the biggest (nearest the camera)
      let f;
      if (track) f = faces.reduce((a, b) => dist(b, track) - b.h < dist(a, track) - a.h ? b : a);
      else f = faces.reduce((a, b) => (b.h > a.h ? b : a));
      if (track && dist(f, track) > src.w * 0.25 && Date.now() - lastSeen < 2500) f = null;   // ignore a sudden jump to someone else
      if (f) {
        track = { cx: f.x + f.w / 2, cy: f.y + f.h / 2, h: f.h }; lastSeen = Date.now();
        AF.box = f; AF.status = "tracking";
        const want = target(track, g, st.zoom);
        // dead zone: small movements don't move the camera (no seasick framing)
        if (!tgt || Math.abs(want.x - tgt.x) > want.w * 0.07 || Math.abs(want.y - tgt.y) > want.h * 0.07 || Math.abs(want.h - tgt.h) > tgt.h * 0.12) tgt = want;
      }
    } else if (Date.now() - lastSeen > 5000) {
      AF.status = "searching"; track = null; AF.box = null;
      tgt = centreBox(g);                                // nobody found for a while: ease back to the full height of the stage
    }
    emit("autoframe");
  } catch { }
  busy = false;
}
function dist(f, t) { return Math.hypot(f.x + f.w / 2 - t.cx, f.y + f.h / 2 - t.cy); }
function target(t, g, zoom) {
  const a = g.cam.w / g.cam.h;
  let h = Math.min(src.h, Math.max(src.h * 0.38, t.h / (ZOOM[zoom] || ZOOM.medium)));
  let w = h * a;
  if (w > src.w) { w = src.w; h = w / a; }
  let x = t.cx - w / 2, y = (t.cy - t.h / 2) - h * 0.2;         // eyes in the upper third
  x = Math.max(0, Math.min(src.w - w, x)); y = Math.max(0, Math.min(src.h - h, y));
  return { x, y, w, h };
}
let lastSent = "";
async function step() {
  if (!tgt) return;
  if (!cur) cur = { ...tgt };
  const e = 0.12;
  for (const k of ["x", "y", "w", "h"]) cur[k] += (tgt[k] - cur[k]) * e;
  const crop = cropFor(cur), key = JSON.stringify(crop);
  if (key === lastSent) return; lastSent = key;
  const st = settings(), g = splitGeo(st.layout, st.side);
  for (const scene of SPLIT_SCENES) {
    try {
      const sceneItemId = ids[scene]; if (sceneItemId == null) continue;
      await S.obs.call("SetSceneItemTransform", { sceneName: scene, sceneItemId, sceneItemTransform: { positionX: g.cam.x, positionY: g.cam.y, boundsWidth: g.cam.w, boundsHeight: g.cam.h, boundsType: "OBS_BOUNDS_SCALE_OUTER", ...crop } });
    } catch { }
  }
}
export function recentre() { track = null; tgt = null; cur = null; lastSeen = 0; applySplitLayout(); }

// Reload Revival overlays in OBS — by default only the ones that did not load (e.g. OBS opened them while
// this app was closed). Overlays that are working are never touched, so nothing flashes on stream.
export async function refreshOverlays({ all = false } = {}) {
  if (!S.obs.connected) return { reloaded: 0, ok: 0 };
  const { bus } = await import("./core.js");
  const alive = new Set();
  const off = bus.on(m => { if (m.type === "tpl-pong" && m.obs) alive.add(m.href); });
  bus.send({ type: "tpl-ping" });
  await new Promise(r => setTimeout(r, 1500));
  off();
  const { inputs } = await S.obs.call("GetInputList", { inputKind: "browser_source" });
  let reloaded = 0, ok = 0;
  for (const i of inputs) {
    if (!/^RW /.test(i.inputName)) continue;
    try {
      const { inputSettings: st } = await S.obs.call("GetInputSettings", { inputName: i.inputName });
      // Starting Soon + Ending carry the background hymns: their sound must go into OBS's mix (only change it if needed — a settings change reloads the page)
      if (/^RW (Starting Soon|Ending)$/.test(i.inputName) && !st.reroute_audio) { await S.obs.call("SetInputSettings", { inputName: i.inputName, inputSettings: { reroute_audio: true } }); reloaded++; continue; }
      let path = ""; try { const u = new URL(st.url); path = u.pathname + u.search; } catch { }
      if (!all && path && alive.has(path)) { ok++; continue; }
      await S.obs.call("PressInputPropertiesButton", { inputName: i.inputName, propertyName: "refreshnocache" }); reloaded++;
    } catch { }
  }
  return { reloaded, ok };
}
