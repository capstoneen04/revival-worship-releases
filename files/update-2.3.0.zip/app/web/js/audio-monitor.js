// Live audio monitor: listens to the ATEM's USB audio (what goes to YouTube) and gives plain-language suggestions.
// Loudness follows ITU-R BS.1770 (K-weighting, momentary 400 ms / short-term 3 s), close enough for live mixing.

const BANDS = { sub: [30, 60], low: [60, 200], mud: [200, 500], body: [500, 1000], mid: [1000, 4000], pres: [2000, 5000], harsh: [5000, 9000], air: [9000, 16000] };
const TARGET = -16;        // LUFS: good for speech on YouTube (YouTube plays back at about -14)

export class AudioMonitor extends EventTarget {
  constructor() { super(); this.running = false; this.history = []; this.peaks = []; this.listenGain = null; this.state = {}; }

  static async devices() {
    try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach(t => t.stop()); } catch { }
    const all = await navigator.mediaDevices.enumerateDevices();
    return all.filter(d => d.kind === "audioinput").map(d => ({ id: d.deviceId, label: d.label || "Microphone" }));
  }
  static pickDefault(list) {
    return (list.find(d => /blackmagic|atem/i.test(d.label)) || list.find(d => /obsbot/i.test(d.label)) || list[0] || {}).id;
  }

  async start(deviceId) {
    this.stop();
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: deviceId ? { exact: deviceId } : undefined, echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 2 } });
    const tr = this.stream.getAudioTracks()[0];
    this.label = tr?.label || "";
    this.stereo = (tr?.getSettings?.().channelCount || 1) > 1;
    const ctx = this.ctx = new AudioContext({ sampleRate: 48000, latencyHint: "interactive" });
    const src = this.src = ctx.createMediaStreamSource(this.stream);
    // K-weighting: high shelf + high pass
    const shelf = ctx.createBiquadFilter(); shelf.type = "highshelf"; shelf.frequency.value = 1681; shelf.gain.value = 4;
    const hp = ctx.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 38; hp.Q.value = 0.5;
    this.k = ctx.createAnalyser(); this.k.fftSize = 4096;
    src.connect(shelf); shelf.connect(hp); hp.connect(this.k);
    this.raw = ctx.createAnalyser(); this.raw.fftSize = 8192; this.raw.smoothingTimeConstant = 0.6;
    src.connect(this.raw);
    this.listenGain = ctx.createGain(); this.listenGain.gain.value = 0; src.connect(this.listenGain); this.listenGain.connect(ctx.destination);
    this.kBuf = new Float32Array(this.k.fftSize); this.rBuf = new Float32Array(this.raw.fftSize); this.fBuf = new Float32Array(this.raw.frequencyBinCount);
    this.history = []; this.peaks = []; this.integ = []; this.started = Date.now();
    this.running = true;
    this.timer = setInterval(() => this.tick(), 100);
    this.sugTimer = setInterval(() => this.suggest(), 1000);
  }
  stop() {
    this.running = false; clearInterval(this.timer); clearInterval(this.sugTimer);
    try { this.stream?.getTracks().forEach(t => t.stop()); } catch { }
    try { this.ctx?.close(); } catch { }
    this.ctx = null;
  }
  listen(on) { if (this.listenGain) this.listenGain.gain.value = on ? 1 : 0; }

  tick() {
    if (!this.ctx) return;
    this.k.getFloatTimeDomainData(this.kBuf);
    const n = Math.round(48000 * 0.1);          // newest 100 ms
    let ms = 0; for (let i = this.kBuf.length - n; i < this.kBuf.length; i++) ms += this.kBuf[i] * this.kBuf[i];
    ms /= n;
    this.raw.getFloatTimeDomainData(this.rBuf);
    let pk = 0; for (let i = this.rBuf.length - n; i < this.rBuf.length; i++) { const a = Math.abs(this.rBuf[i]); if (a > pk) pk = a; }
    this.raw.getFloatFrequencyData(this.fBuf);
    const bands = this.bandLevels();
    const t = Date.now();
    this.history.push({ t, ms, pk, bands });
    while (this.history.length && t - this.history[0].t > 30000) this.history.shift();
    const lufs = (arr) => { if (!arr.length) return -Infinity; const m = arr.reduce((a, b) => a + b.ms, 0) / arr.length; return -0.691 + 10 * Math.log10(m || 1e-12) + (this.stereo ? 3.01 : 0); };
    const momentary = lufs(this.history.slice(-4)), short = lufs(this.history.slice(-30));
    if (momentary > -70) this.integ.push(this.history[this.history.length - 1]);
    if (this.integ.length > 36000) this.integ.shift();
    const peakDb = 20 * Math.log10(pk || 1e-9);
    if (peakDb > -1) this.peaks.push(t);
    this.peaks = this.peaks.filter(x => t - x < 15000);
    const feedback = this.feedbackCheck();
    this.state = { momentary, short, peak: peakDb, bands, clipping: this.peaks.length, label: this.label, feedback };
    this.dispatchEvent(new CustomEvent("level", { detail: this.state }));
  }
  // Feedback / howl: one narrow frequency far above its neighbours that stays put and keeps growing
  feedbackCheck() {
    const binHz = 48000 / this.raw.fftSize, f = this.fBuf;
    const a = Math.floor(400 / binHz), b = Math.floor(8000 / binHz);
    let mi = a; for (let i = a; i <= b; i++) if (f[i] > f[mi]) mi = i;
    let sum = 0, n = 0;
    for (let i = mi - 40; i <= mi + 40; i++) { if (Math.abs(i - mi) < 4 || i < 0 || i >= f.length) continue; sum += f[i]; n++; }
    const prom = f[mi] - sum / n, lvl = f[mi];
    const c = this._fb;
    if (prom > 28 && lvl > -55) {
      if (c && Math.abs(c.bin - mi) <= 2) { c.n++; c.last = lvl; c.prom = prom; }
      else this._fb = { bin: mi, n: 1, first: lvl, last: lvl, prom };
    } else this._fb = null;
    const k = this._fb;
    // ≥1.5 s on the same pitch and either rising or extremely narrow/strong
    if (k && k.n >= 15 && (k.last - k.first > 3 || k.prom > 36)) return { hz: Math.round(k.bin * binHz), prom: Math.round(k.prom) };
    return null;
  }
  bandLevels() {
    const binHz = 48000 / this.raw.fftSize, out = {};
    for (const [k, [a, b]] of Object.entries(BANDS)) {
      let p = 0; for (let i = Math.floor(a / binHz); i <= Math.ceil(b / binHz) && i < this.fBuf.length; i++) p += Math.pow(10, this.fBuf[i] / 10);
      out[k] = 10 * Math.log10(p || 1e-12);
    }
    // narrow hum check: 50/100/150 Hz vs. neighbours
    const at = (f) => this.fBuf[Math.round(f / binHz)];
    const neigh = (f) => (at(f - 12) + at(f + 12)) / 2;
    out.hum = Math.max(at(50) - neigh(50), at(100) - neigh(100), at(150) - neigh(150));
    return out;
  }
  integrated() {
    const blocks = this.integ.filter(b => -0.691 + 10 * Math.log10(b.ms || 1e-12) > -70);
    if (!blocks.length) return -Infinity;
    const L = (arr) => -0.691 + 10 * Math.log10(arr.reduce((a, b) => a + b.ms, 0) / arr.length) + (this.stereo ? 3.01 : 0);
    const rel = L(blocks) - 10;
    const g = blocks.filter(b => -0.691 + 10 * Math.log10(b.ms) + (this.stereo ? 3.01 : 0) > rel);
    return g.length ? L(g) : -Infinity;
  }

  // ---------- suggestions ----------
  suggest() {
    const H = this.history.slice(-150);           // last 15 s
    if (H.length < 30) return;
    const off = this.stereo ? 3.01 : 0;
    const blockL = (b) => -0.691 + 10 * Math.log10(b.ms || 1e-12) + off;
    const lv = H.map(blockL);
    const speech = H.filter((b, i) => lv[i] > -45);
    const quiet = H.filter((b, i) => lv[i] <= -45);
    const out = [];
    const sorted = [...lv].sort((a, b) => a - b);
    const p = (q) => sorted[Math.min(sorted.length - 1, Math.floor(q * sorted.length))];
    const noise = p(0.1);

    if (speech.length < H.length * 0.15) {
      if (p(0.9) < -55) out.push({ id: "silent", level: "bad", title: "No sound coming in", detail: "Nothing above −55 LUFS for 15 seconds. Check the pulpit mic is switched on, its cable, and that Mic 2 is ON in the ATEM audio mixer.", action: { label: "Turn Mic 2 on", nudge: { input: 1302, mixOn: true } } });
      else out.push({ id: "waiting", level: "info", title: "Waiting for someone to speak or sing…", detail: `Room level ${noise.toFixed(0)} LUFS.` });
    } else {
      const sp = speech.map(blockL).sort((a, b) => a - b);
      const avg = -0.691 + 10 * Math.log10(speech.reduce((a, b) => a + b.ms, 0) / speech.length) + off;
      const range = sp[Math.floor(sp.length * 0.95)] - sp[Math.floor(sp.length * 0.1)];
      // 1. level
      const diff = TARGET - avg;
      if (diff > 4) out.push({ id: "quiet", level: diff > 8 ? "bad" : "warn", title: `Too quiet — raise Mic 2 by about +${Math.round(Math.min(diff, 10))} dB`, detail: `Voice is ${avg.toFixed(1)} LUFS; aim for ${TARGET}. People on YouTube will turn their volume right up.`, action: { label: `Raise +${Math.round(Math.min(diff, 6))} dB`, nudge: { input: 1302, faderDelta: Math.round(Math.min(diff, 6)) } } });
      else if (diff < -4) out.push({ id: "loud", level: diff < -8 ? "bad" : "warn", title: `Too loud — lower Mic 2 by about ${Math.round(Math.max(diff, -10))} dB`, detail: `Voice is ${avg.toFixed(1)} LUFS; aim for ${TARGET}.`, action: { label: `Lower ${Math.round(Math.max(diff, -6))} dB`, nudge: { input: 1302, faderDelta: Math.round(Math.max(diff, -6)) } } });
      // 2. clipping
      if (this.peaks.length >= 3) out.push({ id: "clip", level: "bad", title: "Distorting on loud moments", detail: `${this.peaks.length} peaks hit 0 dB in the last 15 s. Lower the Mic 2 input gain 3 dB and keep the master limiter on.`, action: { label: "Gain −3 dB + limiter", nudge: { input: 1302, gainDelta: -3, masterLimiter: true } } });
      // 3. dynamics
      if (range > 16) out.push({ id: "dyn", level: "warn", title: "Voice jumps between soft and loud", detail: `Spread is ${range.toFixed(0)} LU. A bit more compression keeps the preaching even for listeners on phones.`, action: { label: "More compression", nudge: { input: 1302, compressor: { th: -26, ratio: 4 } } } });
      // tone — averaged over speech frames
      const avgBand = (k) => 10 * Math.log10(speech.reduce((a, b) => a + Math.pow(10, b.bands[k] / 10), 0) / speech.length);
      const low = avgBand("low"), mud = avgBand("mud"), mid = avgBand("mid"), pres = avgBand("pres"), harsh = avgBand("harsh"), body = avgBand("body");
      if (low - mid > -2) out.push({ id: "boom", level: "warn", title: "Boomy / too much bass", detail: "Typical when the speaker is close to the mic. Raise the high-pass filter to 120 Hz.", action: { label: "High-pass 120 Hz", nudge: { input: 1302, band: 0, freq: 120 } } });
      else if (mud - mid > 5) out.push({ id: "mud", level: "warn", title: "Muddy / boxy sound", detail: "Too much 200–500 Hz. Cut 300 Hz a little more.", action: { label: "Cut 300 Hz −2 dB", nudge: { input: 1302, band: 2, freq: 300, gainAdd: -2 } } });
      if (pres - body < -12) out.push({ id: "dull", level: "warn", title: "Dull — words not clear", detail: "Add a little presence around 3.5 kHz so every word is understood.", action: { label: "Presence +2 dB", nudge: { input: 1302, band: 3, freq: 3500, gainAdd: 2 } } });
      if (harsh - mid > -3) out.push({ id: "harsh", level: "warn", title: "Harsh / sharp ‘S’ sounds", detail: "Too much 5–9 kHz. Reduce the top end a little.", action: { label: "Top end −2 dB", nudge: { input: 1302, band: 4, gainAdd: -2 } } });
      if (!out.length) out.push({ id: "good", level: "ok", title: `Sounding good · ${avg.toFixed(1)} LUFS`, detail: "Level, tone and peaks are all in a healthy range for YouTube." });
    }
    // noise / hum (uses the quiet moments)
    if (quiet.length > 20) {
      const qn = -0.691 + 10 * Math.log10(quiet.reduce((a, b) => a + b.ms, 0) / quiet.length) + off;
      const hum = quiet.reduce((a, b) => a + (b.bands.hum || 0), 0) / quiet.length;
      if (hum > 14 && qn > -62) out.push({ id: "hum", level: "warn", title: "Electrical hum (50 Hz)", detail: "A steady hum is in the pauses. Usually a cable or a power ground loop — try another socket for the mixer/amp, or a DI box. A higher high-pass filter hides some of it.", action: { label: "High-pass 120 Hz", nudge: { input: 1302, band: 0, freq: 120 } } });
      else if (qn > -48) out.push({ id: "noise", level: "warn", title: "Background noise between sentences", detail: `Room/fan noise is ${qn.toFixed(0)} LUFS in the pauses. A gentle gate keeps it down.`, action: { label: "Gentle gate", nudge: { input: 1302, gate: { th: Math.round(qn + 6) } } } });
    }
    this.suggestions = out;
    this.dispatchEvent(new CustomEvent("suggest", { detail: { list: out, integrated: this.integrated() } }));
  }
}

// one monitor for the whole app (Produce page and the automatic sound helper share it)
export const monitor = new AudioMonitor();
