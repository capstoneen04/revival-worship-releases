// Theme packs: ready-made looks for conventions/events, kept as folders in Media/Themes/<Folder>/theme.json
// (built outside the app — e.g. with the "revival-theme-builder" skill — and simply dropped in).
//
// theme.json (format "revival-theme", version 1) — every field optional except name:
// {
//   "format": "revival-theme", "version": 1, "name": "Punjab Meetings 2026", "description": "…",
//   "accent": "#e0564a",                                   // accent colour for all overlays
//   "headline": { "a": "the", "b": "PUNJAB", "c": "meetings", "d": "2026" },   // Starting Soon: small · BIG · small · BIG
//   "meeting": "Punjab Meetings", "startLabel": "Service begins shortly", "ticker": "…",
//   "endTitle": "God Bless You", "endText": "…",
//   "start": { "picture": "start.jpg", "layout": "left|full", "zoom": 1, "dx": 0, "dy": 0, "dim": 0 },
//   "end":   { "picture": "end.jpg",   "layout": "left|full", "zoom": 1, "dx": 0, "dy": 0, "dim": 0 },
//   "music": { "start": "music/start", "end": "music/end" }, // folders inside the pack, or shared ones like "Music/Start"
//   "thumbnail": { "background": "thumb.jpg", "mood": "burgundy|sapphire|emerald|indigo|charcoal" }
// }
// Relative file names are inside the pack folder. Paths starting with "Music/", "Pictures/", "assets/" or "media/" are used as they are.

const SHARED = /^(Music|Pictures|People|Thumbnails|Themes)\//;
export function resolve(dir, p) {
  if (!p) return "";
  if (/^(https?:|data:|\/|assets\/|media\/)/.test(p)) return p;
  if (SHARED.test(p)) return "media/" + p;
  return `media/Themes/${dir}/${p}`;
}
function musicDir(dir, p, fallback) {
  if (!p) return fallback;
  if (/^(Music|Themes)\//.test(p)) return p;
  return `Themes/${dir}/${p}`;
}

export async function listPacks() {
  let dirs = [];
  try { dirs = (await fetch("/api/media?dir=Themes").then(r => r.json())).dirs || []; } catch { }
  const out = [];
  for (const d of dirs) {
    try {
      const j = await fetch(`/media/Themes/${encodeURIComponent(d)}/theme.json`, { cache: "no-store" }).then(r => r.ok ? r.json() : null);
      if (j && j.name) out.push({ dir: d, pack: j });
    } catch { }
  }
  return out;
}

// pack → the same shape as an in-app theme (see screens.js THEME_KEYS)
export function packToTheme(dir, p) {
  const pic = (x, def) => x ? { src: resolve(dir, x.picture), layout: x.layout || def.layout, zoom: x.zoom ?? 1, dx: x.dx ?? 0, dy: x.dy ?? 0, dim: x.dim ?? 0 } : null;
  return {
    id: "pack:" + dir, name: p.name, pack: true,
    headline: p.headline ? { a: p.headline.a ?? "", b: p.headline.b ?? "", c: p.headline.c ?? "", d: p.headline.d ?? "" } : null,
    brandGold: p.accent || "",
    startPicture: pic(p.start, { layout: "left" }), endPicture: pic(p.end, { layout: "left" }),
    music: p.music ? {
      start: { on: true, dir: musicDir(dir, p.music.start, "Music/Start"), volume: p.music.volume ?? 0.55, shuffle: true, title: true },
      end: { on: true, dir: musicDir(dir, p.music.end, "Music/End"), volume: p.music.volume ?? 0.5, shuffle: true, title: true },
    } : null,
    endTitle: p.endTitle ?? null, endText: p.endText ?? null, meeting: p.meeting ?? null, ticker: p.ticker ?? null, startLabel: p.startLabel ?? null,
    themeThumb: p.thumbnail ? { background: p.thumbnail.background ? "/" + resolve(dir, p.thumbnail.background) : "", mood: p.thumbnail.mood || "" } : { background: "", mood: "" },
  };
}

// current look → a pack folder (theme.json only; pictures stay where they are, referenced by path)
export function themeToPack(name, b) {
  const pic = (x) => x && x.src ? { picture: x.src.replace(/^\//, ""), layout: x.layout, zoom: x.zoom, dx: x.dx, dy: x.dy, dim: x.dim } : undefined;
  const md = (x) => x?.dir;
  return {
    format: "revival-theme", version: 1, name, accent: b.brandGold || "#d4a24c", headline: b.headline, meeting: b.meeting || "",
    startLabel: b.startLabel, ticker: b.ticker, endTitle: b.endTitle, endText: b.endText,
    start: pic(b.startPicture), end: pic(b.endPicture),
    music: b.music ? { start: md(b.music.start), end: md(b.music.end) } : undefined,
    thumbnail: b.themeThumb?.background || b.themeThumb?.mood ? { background: (b.themeThumb.background || "").replace(/^\/media\//, ""), mood: b.themeThumb.mood } : undefined,
  };
}
