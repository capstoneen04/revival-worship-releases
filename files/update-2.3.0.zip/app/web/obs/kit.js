// Shared runtime for Revival OBS templates (1920×1080 browser sources)
import { createBus } from "../js/bus.js";

export const DEFAULTS = {
  churchName: "Revival Fellowship", serviceTitle: "Sunday Worship Service", speaker: "", sermonTitle: "",
  countdownTo: 0, startLabel: "Service begins shortly",
  verse: { text: "I was glad when they said unto me, Let us go into the house of the LORD.", ref: "Psalm 122:1" },
  announcements: ["Welcome to Revival Fellowship Mumbai"], ticker: "Welcome to Revival Fellowship Mumbai",
  brbTitle: "Let us pray", brbText: "We will be right back", endTitle: "God Bless You", endText: "Thank you for worshipping with us",
  nextService: "Every Sunday · 2:00 PM", address: "", social: "", accent: "#d4a24c", gold: "#d4a24c",
};

export function startKit(render) {
  const p = new URLSearchParams(location.search);
  const kit = { info: { ...DEFAULTS }, live: null, lower: null, theme: {}, params: p, connected: false };
  const bus = createBus("obs-template");
  kit.bus = bus; kit.listeners = new Set();
  const apply = () => {
    const r = document.documentElement.style;
    // convention themes can change the accent colour of every template
    if (kit.info.brandGold) { r.setProperty("--gold", kit.info.brandGold); r.setProperty("--gold2", mix(kit.info.brandGold, "#ffffff", 0.45)); }
    else { r.removeProperty("--gold"); r.removeProperty("--gold2"); }
    render(kit);
  };
  bus.on(m => {
    // skip repeats: the app re-sends settings often, and an unchanged message needs no redraw
    if (m.type === "broadcast") { const k = JSON.stringify(m.data); if (k === kit._bk) return; kit._bk = k; kit.info = { ...DEFAULTS, ...m.data }; apply(); }
    if (m.type === "state") { kit.live = m.state.live; kit.lower = m.state.lower; kit.liveTitle = m.state.title; kit.program = m.state.program; sceneHint(kit.program); apply(); }
    if (m.type === "theme") { kit.theme = m.theme; }
    if (m.type === "_bus") kit.connected = m.connected;
    kit.listeners.forEach(fn => { try { fn(m); } catch { } });
  });
  bus.send({ type: "need-state" });
  apply();
  return kit;
}

export const $ = (s, r = document) => r.querySelector(s);
function mix(a, b, t) { const p = (c) => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16)); const x = p(a), y = p(b); return "#" + x.map((v, i) => Math.round(v + (y[i] - v) * t).toString(16).padStart(2, "0")).join(""); }
export function setText(sel, t) { const e = $(sel); if (e) e.textContent = t || ""; }
export function lines(el, arr) { el.innerHTML = ""; (arr || []).forEach(l => { const d = document.createElement("div"); d.textContent = l; el.appendChild(d); }); }

export function fmtCountdown(ms) {
  if (ms <= 0) return "00:00";
  const s = Math.ceil(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return (h ? h + ":" + String(m).padStart(2, "0") : String(m).padStart(2, "0")) + ":" + String(x).padStart(2, "0");
}
export function clock() { return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); }
export function today() { return new Date().toLocaleDateString([], { weekday: "long", day: "numeric", month: "long", year: "numeric" }); }

// Soft floating light particles on a canvas (cheap: ~40 dots)
export function particles(canvas, n = 40) {
  const c = canvas.getContext("2d"); const W = canvas.width = 1920, H = canvas.height = 1080;
  const dots = Array.from({ length: n }, () => ({ x: Math.random() * W, y: Math.random() * H, r: 1 + Math.random() * 3, s: 0.15 + Math.random() * 0.45, a: 0.15 + Math.random() * 0.45 }));
  (function f() {
    c.clearRect(0, 0, W, H);
    for (const d of dots) {
      d.y -= d.s; d.x += Math.sin(d.y / 90) * 0.2; if (d.y < -10) { d.y = H + 10; d.x = Math.random() * W; }
      const g = c.createRadialGradient(d.x, d.y, 0, d.x, d.y, d.r * 4); g.addColorStop(0, `rgba(255,230,170,${d.a})`); g.addColorStop(1, "rgba(255,230,170,0)");
      c.fillStyle = g; c.beginPath(); c.arc(d.x, d.y, d.r * 4, 0, Math.PI * 2); c.fill();
    }
    requestAnimationFrame(f);
  })();
}

// Fit text inside a box by shrinking font size
export function fitText(el, max, min = 20) {
  let lo = min, hi = max;
  for (let i = 0; i < 10; i++) { const mid = (lo + hi) >> 1; el.style.fontSize = mid + "px"; if (el.scrollHeight <= el.clientHeight + 2 && el.scrollWidth <= el.clientWidth + 2) lo = mid; else hi = mid; }
  el.style.fontSize = lo + "px";
}

// "261018 M" — same pattern as the stream titles and the Message tape codes
export function dateCode(info = {}, d = new Date()) {
  if (info.serviceCode) return info.serviceCode;
  const yy = String(d.getFullYear()).slice(2), mm = String(d.getMonth() + 1).padStart(2, "0"), dd = String(d.getDate()).padStart(2, "0");
  return `${yy}${mm}${dd} ${d.getHours() < 15 ? "M" : "E"}`;
}
export function dateLabel(d = new Date()) {
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }).toUpperCase();
}
// ---------- on-screen or not? (OBS tells each browser source) ----------
// Hidden overlays pause every animation, so a scene that isn't showing costs OBS almost nothing.
let _visible = true; const _visSubs = new Set();
export const isVisible = () => _visible;
export function onVisibility(fn) { _visSubs.add(fn); fn(_visible); return () => _visSubs.delete(fn); }
function setVisible(v) {
  if (v === _visible) return; _visible = v;
  document.documentElement.classList.toggle("paused", !v);
  _visSubs.forEach(f => { try { f(v); } catch { } });
}
let _obsSaid = false;
window.addEventListener("obsSourceVisibleChanged", e => { _obsSaid = true; setVisible(!!e.detail?.visible); });
// Until OBS sends its first visibility event, guess from the on-air scene name the app shares
const _page = (location.pathname.split("/").pop() || "").replace(".html", "");
const _hint = { starting: /starting/i, welcome: /welcome/i, scripture: /scripture/i, prayer: /prayer/i, ending: /ending/i }[_page];
function sceneHint(program) { if (_obsSaid || !_hint || !window.obsstudio || !program) return; setVisible(_hint.test(program)); }
document.addEventListener("visibilitychange", () => { if (!window.obsstudio) setVisible(document.visibilityState === "visible"); });
// OBS loads hidden sources too — ask it once whether we are showing right now
if (window.obsstudio?.getStatus) { try { window.obsstudio.getControlLevel?.(() => { }); } catch { } }

// gold dust: one pre-drawn glow, half-resolution canvas, 30 fps, stops when hidden
export function goldDust(canvas, n = 40) {
  const W = 960, H = 540, c = canvas.getContext("2d");
  canvas.width = W; canvas.height = H; canvas.style.width = "1920px"; canvas.style.height = "1080px";
  const sprite = document.createElement("canvas"); sprite.width = sprite.height = 32;
  const sg = sprite.getContext("2d"), gr = sg.createRadialGradient(16, 16, 0, 16, 16, 16);
  gr.addColorStop(0, "rgba(241,211,145,1)"); gr.addColorStop(.35, "rgba(241,211,145,.45)"); gr.addColorStop(1, "rgba(241,211,145,0)");
  sg.fillStyle = gr; sg.fillRect(0, 0, 32, 32);
  const dots = Array.from({ length: Math.round(n * 0.8) }, () => ({ x: Math.random() * W, y: Math.random() * H, r: 1.6 + Math.random() * 4.5, s: .06 + Math.random() * .17, a: .1 + Math.random() * .4, p: Math.random() * 6 }));
  let raf = 0, last = 0;
  function f(t) {
    raf = requestAnimationFrame(f);
    if (t - last < 33) return; const dt = Math.min(3, (t - last) / 16.7); last = t;
    c.clearRect(0, 0, W, H);
    for (const d of dots) {
      d.y -= d.s * dt; d.x += Math.sin((d.y + d.p * 50) / 60) * .12 * dt; if (d.y < -8) { d.y = H + 8; d.x = Math.random() * W; }
      c.globalAlpha = d.a * (.6 + .4 * Math.sin(t / 900 + d.p));
      const s = d.r * 5; c.drawImage(sprite, d.x - s / 2, d.y - s / 2, s, s);
    }
    c.globalAlpha = 1;
  }
  onVisibility(v => { cancelAnimationFrame(raf); if (v) { last = 0; raf = requestAnimationFrame(f); } });
}
// re-run an entrance animation on an element
export function replay(el, cls = "wipe-in") { el.classList.remove(cls, "wipe-out"); void el.offsetWidth; el.classList.add(cls); }

// ---------- picture behind the Starting / Ending screens (chosen in the app, editable) ----------
// cfg: { src, layout: "left" | "full", zoom (1 = fill the box), dx, dy (-1..1 shift), dim (0..1) }
export const PICTURE_DEFAULTS = {
  start: { src: "assets/img/backgrounds/eagle.jpg", layout: "left", zoom: 0.78, dx: -0.24, dy: 0.12, dim: 0 },
  end: { src: "assets/img/backgrounds/cloud.jpg", layout: "left", zoom: 0.86, dx: -0.06, dy: 0.28, dim: 0.05 },
};
export function picture(box, cfg) {
  if (!cfg || !cfg.src) { box.style.display = "none"; return; }
  box.style.display = "";
  const layout = cfg.layout === "full" ? "full" : "left";
  box.className = "hero " + layout + (box.dataset.shown ? "" : " fade"); box.dataset.shown = 1;
  let cv = box.querySelector("canvas");
  if (!cv) { cv = document.createElement("canvas"); box.appendChild(cv); }
  const src = /^(https?:|data:|\/)/.test(cfg.src) ? cfg.src : "/" + cfg.src;
  const key = JSON.stringify([src, layout, cfg.zoom, cfg.dx, cfg.dy, cfg.dim]);
  if (box.dataset.key === key) return; box.dataset.key = key;
  const img = new Image();
  img.onload = () => {
    if (box.dataset.key !== key) return;        // a newer picture was chosen while this one was loading
    const W = layout === "full" ? 1920 : 1150, H = 1080; cv.width = W; cv.height = H;
    const g = cv.getContext("2d"), nw = img.naturalWidth, nh = img.naturalHeight;
    const s = Math.max(W / nw, H / nh) * (cfg.zoom || 1), w = nw * s, h = nh * s;
    const x = (W - w) / 2 + (cfg.dx || 0) * W, y = (H - h) / 2 + (cfg.dy || 0) * H;
    g.clearRect(0, 0, W, H);
    g.filter = cfg.dim ? `brightness(${1 - cfg.dim})` : "none";
    g.drawImage(img, x, y, w, h); g.filter = "none";
    if (layout === "left") {
      // feather the photo's own edges, then fade the whole panel out towards the text
      g.globalCompositeOperation = "destination-in";
      const ix = Math.max(0, x), iy = Math.max(0, y), iw = Math.min(W, x + w) - ix, ih = Math.min(H, y + h) - iy;
      const cx = ix + iw * 0.46, cy = iy + ih * 0.52, r = Math.max(iw, ih) * 0.62;
      g.save(); g.translate(cx, cy); g.scale(iw / Math.max(iw, ih), ih / Math.max(iw, ih));
      const rg = g.createRadialGradient(0, 0, r * 0.55, 0, 0, r * 1.0); rg.addColorStop(0, "rgba(0,0,0,1)"); rg.addColorStop(0.55, "rgba(0,0,0,.65)"); rg.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = rg; g.fillRect(-W * 2, -H * 2, W * 4, H * 4); g.restore();
      const fade = (x0, y0, x1, y1) => { const l = g.createLinearGradient(x0, y0, x1, y1); l.addColorStop(0, "rgba(0,0,0,0)"); l.addColorStop(1, "rgba(0,0,0,1)"); g.fillStyle = l; g.fillRect(0, 0, W, H); };
      fade(W, 0, W * 0.68, 0);                                   // towards the text
      if (iy > 1) fade(0, iy, 0, iy + ih * 0.28);                 // photo's top edge
      if (iy + ih < H - 1) fade(0, iy + ih, 0, iy + ih - ih * 0.18); // photo's bottom edge
      if (ix > 1) fade(ix, 0, ix + iw * 0.2, 0);                  // photo's left edge
      g.globalCompositeOperation = "source-over";
    }
  };
  img.src = src;
}

// ---------- background hymns (only plays inside OBS, so app previews stay silent) ----------
// cfg: { on, dir: "Music/Start", volume 0..1, shuffle, title }
export function musicPlayer(kit, screen, npEl) {
  const inObs = !!window.obsstudio || kit.params.get("music") === "1";
  // on air? — the app tells us OBS's program scene; OBS also tells the page directly when the source goes live / off
  const mine = screen === "end" ? /ending/i : /starting/i;
  let obsActive = null;
  window.addEventListener("obsSourceActiveChanged", e => { obsActive = !!e.detail?.active; onAir(); });
  const live = () => obsActive != null ? obsActive : kit.program ? mine.test(kit.program) : true;
  let wasLive = null;
  function onAir() {
    const l = live(); if (l === wasLive) return; wasLive = l;
    if (!l) { A.forEach(a => fadeTo(a, 0, 2500, () => a.pause())); npEl && (npEl.style.opacity = 0); status(); }
    else { pos = Math.max(-1, pos - 0); play(); }
  }
  const A = [new Audio(), new Audio()]; let cur = 0, list = [], order = [], pos = -1, cfgKey = "", paused = false, fading = null;
  const cfg = () => (kit.info.music || {})[screen] || {};
  const vol = () => Math.max(0, Math.min(1, cfg().volume ?? 0.55));
  const title = (n) => decodeURIComponent(n).replace(/\.[^.]+$/, "").replace(/^\d+[\s._-]+/, "");
  const status = () => kit.bus.send({ type: "music-status", screen, playing: !paused && !A[cur].paused, title: list[order[pos]] ? title(list[order[pos]].name) : "", count: list.length });
  async function load() {
    const c = cfg();
    try { list = (await fetch(`/api/media?dir=${encodeURIComponent(c.dir || (screen === "end" ? "Music/End" : "Music/Start"))}`).then(r => r.json())).files.filter(f => /\.(mp3|m4a|aac|wav|ogg)$/i.test(f.name)); } catch { list = []; }
    order = list.map((_, i) => i);
    if (c.shuffle !== false) for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    pos = -1;
  }
  function fadeTo(a, target, ms, done) {
    const from = a.volume, t0 = performance.now();
    const step = (t) => { const k = Math.min(1, (t - t0) / ms); a.volume = Math.max(0, Math.min(1, from + (target - from) * k)); if (k < 1) requestAnimationFrame(step); else done && done(); };
    requestAnimationFrame(step);
  }
  function play(next = true) {
    if (!list.length || !inObs || paused || cfg().on === false || !live()) { npEl && (npEl.style.opacity = 0); status(); return; }
    pos = (pos + (next ? 1 : 0)) % order.length;
    const old = A[cur]; cur = 1 - cur; const a = A[cur];
    a.src = list[order[pos]].url; a.volume = 0; a.play().catch(() => { });
    fadeTo(a, vol(), 2500);
    if (!old.paused) fadeTo(old, 0, 2500, () => old.pause());
    if (npEl) { npEl.textContent = cfg().title === false ? "" : "♪  " + title(list[order[pos]].name); npEl.style.opacity = cfg().title === false ? 0 : 1; }
    status();
  }
  A.forEach(a => {
    a.addEventListener("timeupdate", () => { if (a === A[cur] && a.duration && a.duration - a.currentTime < 3 && !a._x) { a._x = true; play(); } });
    a.addEventListener("playing", () => { a._x = false; });
    a.addEventListener("error", () => { if (a === A[cur]) setTimeout(play, 500); });
  });
  kit.listeners.add(m => {
    if (m.type !== "music" || (m.screen && m.screen !== screen)) return;
    if (m.cmd === "next") { paused = false; play(); }
    if (m.cmd === "pause") { paused = true; fadeTo(A[cur], 0, 1200, () => A[cur].pause()); npEl && (npEl.style.opacity = 0); setTimeout(status, 1300); }
    if (m.cmd === "play") { paused = false; if (A[cur].src && A[cur].paused) { A[cur].play().catch(() => { }); fadeTo(A[cur], vol(), 1500); npEl && (npEl.style.opacity = 1); status(); } else play(); }
    if (m.cmd === "reload") { load().then(() => play()); }
    if (m.cmd === "status") status();
  });
  return {
    async update() {
      if (wasLive !== null && live() !== wasLive) { onAir(); }
      if (wasLive === null) wasLive = live();
      const c = cfg(), k = JSON.stringify([c.dir, c.shuffle, c.on]);
      if (k !== cfgKey) { cfgKey = k; await load(); if (c.on === false) { A.forEach(a => fadeTo(a, 0, 1000, () => a.pause())); npEl && (npEl.style.opacity = 0); status(); } else play(); return; }
      if (!A[cur].paused) A[cur].volume = vol();
      if (npEl) npEl.style.opacity = c.title === false || A[cur].paused ? 0 : 1;
    },
  };
}
