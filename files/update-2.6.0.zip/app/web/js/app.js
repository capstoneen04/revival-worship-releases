import { ensureSeeded, startAutoBackup, mergeLibrarySongs } from "./db.js";
import { libraryGate } from "./unlock.js";
import { hideLower } from "./core.js";
import { S, bus, onChange, emit, loadSettings, loadLibrary, loadService, sendTheme, sendBroadcast, broadcast, next, prev, toggleOverride, toggleLowerFollow, openOutput, obsConnect, isTyping, go, native, toast } from "./core.js";
import { songsView } from "./views/songs.js";
import { serviceView } from "./views/service.js";
import { liveView } from "./views/live.js";
import { bibleView } from "./views/bible.js";
import { messageView } from "./views/message.js";
import { ocrView } from "./views/ocr.js";
import { obsView } from "./views/obs.js";
import { broadcastView } from "./views/broadcast.js";
import { settingsView } from "./views/settings.js";
import { productionView } from "./views/production.js";
import { sermonView } from "./views/sermon.js";
import { guideView } from "./views/guide.js";
import { applySplitLayout, refreshOverlays } from "./autoframe.js";
import { startHealth, healthText, healthTip } from "./obs-health.js";
import { startSound, sound } from "./sound.js";
import { startUi } from "./ui-theme.js";
import { atemConnect } from "./atem-client.js";

const VIEWS = { guide: ["Guide — what to use when", guideView], production: ["Production", productionView], sermon: ["Sermon · YouTube · Thumbnail", sermonView], songs: ["Songs", songsView], service: ["Service planner", serviceView], live: ["Live", liveView], bible: ["Bible", bibleView], message: ["The Message", messageView], ocr: ["Image → Text", ocrView], obs: ["OBS & Lower Thirds", obsView], broadcast: ["Broadcast", broadcastView], settings: ["Settings", settingsView] };
const mounted = {};
let current = null;

export function show(name) {
  if (!VIEWS[name]) name = "songs";
  current = name;
  document.querySelectorAll("#rail button[data-view]").forEach(b => b.classList.toggle("on", b.dataset.view === name));
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("on", v.id === "v-" + name));
  document.getElementById("viewtitle").textContent = VIEWS[name][0];
  const el = document.getElementById("v-" + name);
  if (!mounted[name]) mounted[name] = VIEWS[name][1](el) || {};
  mounted[name].onShow?.();
  try { localStorage.setItem("rw-view", name); } catch { }
}
window.rwShow = show;
window.rwViews = mounted;

async function boot() {
  const bootEl = document.getElementById("boot");
  await loadSettings();
  (await import("./bible.js")).setBibleMap({ kjv: S.settings.bibles?.v1 || "kjv", hindi: S.settings.bibles?.v2 || "hindi" });
  await libraryGate(bootEl);
  const seeded = await ensureSeeded(msg => (bootEl.textContent = msg));
  if (!seeded.seeded) await mergeLibrarySongs(msg => (bootEl.textContent = msg)).catch(() => { });
  await loadLibrary();
  await loadService();
  bootEl.remove();
  startAutoBackup();
  import("./core.js").then(c => c.dedupeQuotes()).catch(() => { });   // 2.6: one quote per paragraph
  // new church library arrived while running (team songs published from another computer) → add the songs now
  window.revival?.updates?.onStatus?.(async (st) => {
    if (!st?.libNote) return;
    const r = await mergeLibrarySongs().catch(() => ({ added: 0 }));
    if (r.added) { await loadLibrary(); toast(`${r.added} new or corrected song${r.added > 1 ? "s" : ""} from the media team`); }
  });
  document.querySelectorAll("#rail button[data-view]").forEach(b => b.onclick = () => show(b.dataset.view));
  document.querySelectorAll("#onair [data-act]").forEach(b => b.onclick = () => {
    const a = b.dataset.act;
    if (a === "next") next(); else if (a === "prev") prev(); else if (a === "lower") toggleLowerFollow();
    else if (a === "projector") openOutput("projector"); else toggleOverride(a);
  });
  onChange(updateTop);
  document.getElementById("btn-lcard").onclick = () => hideLower();
  updateTop();
  // first run → the Guide; after that, the last page used
  let start = "guide"; try { start = localStorage.getItem("rw-view") || "guide"; } catch { }
  show(start);
  sendTheme(); broadcast(); sendBroadcast();
  if (S.settings.obs.autoConnect && (S.settings.obs.connectedOnce || native?.obsLocalConfig)) obsConnect(true);
  setInterval(() => { if (S.settings.obs.autoConnect && !S.obs.connected && native?.obsLocalConfig) obsConnect(true); }, 15000);
  if (native?.onQuote) native.onQuote(q => {
    if (!q.action) { emit({ quote: q }); show("message"); return; }
    tableAction(q).catch(e => toast(e.message));
  });
  // OBS just connected: put the split scenes in the chosen layout (and start auto-framing if it's portrait)
  let wasObs = false;
  // only overlays that failed to load are reloaded — working ones are never touched (nothing flashes on stream)
  onChange(w => { if (w === "obs") { if (S.obs.connected && !wasObs) { setTimeout(() => refreshOverlays().catch(() => { }), 2500); applySplitLayout(); } wasObs = S.obs.connected; } });
  startHealth();
  startSound();
  startUi();
  if (native?.atem && S.settings.atem.auto && S.settings.atem.ip) atemConnect(S.settings.atem.ip, true);
  // keyboard
  document.addEventListener("keydown", e => {
    if ((e.metaKey || e.ctrlKey) && e.key === "0") { e.preventDefault(); show("production"); return; }
    if ((e.metaKey || e.ctrlKey) && /^[1-7]$/.test(e.key)) { e.preventDefault(); show(["songs", "service", "live", "bible", "message", "ocr", "obs"][+e.key - 1]); return; }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "f") { const i = document.querySelector(".view.on input[type=search]"); if (i) { e.preventDefault(); i.focus(); i.select(); } return; }
    if (isTyping() || e.metaKey || e.ctrlKey || e.altKey) return;
    const k = e.key;
    if (k === "ArrowRight" || k === "ArrowDown" || k === " " || k === "PageDown") { e.preventDefault(); next(); }
    else if (k === "ArrowLeft" || k === "ArrowUp" || k === "PageUp") { e.preventDefault(); prev(); }
    else if (k === "b" || k === "B" || k === ".") toggleOverride("blank");
    else if (k === "l" || k === "L") toggleOverride("logo");
    else if (k === "Escape") toggleOverride("clear");
    else if (k === "t" || k === "T") toggleLowerFollow();
    else if (/^[1-9]$/.test(k) || k === "c" || k === "C") {
      const target = k.toLowerCase() === "c" ? /^chorus/i : new RegExp(`^verse ${k}\\b`, "i");
      const i = S.live.slides.findIndex((s, idx) => target.test(s.section || s.label || "") && (k.toLowerCase() !== "c" || idx > S.live.index || true));
      if (i >= 0) go(i);
    }
  });
}

// The Table buttons: ▣ Lower third / ▶ Projector / ✕ Clear (and Follow) act straight away; every quote is kept in the Message history
// Clear goes back to what was there before (sermon card / worship) — never to the Quote of the Day — and if a Table send
// had switched the OBS scene, the scene that was live before comes back.
let tableScene = null;
async function tableAction(q) {
  const core = await import("./core.js");
  if (q.action === "clear") {
    core.hideLower(); if (S.live.item?.type === "message") core.setOverride("clear");
    if (tableScene && S.obs.connected && S.obsScenes.current === tableScene.to && tableScene.from) S.obs.setScene(tableScene.from).catch(() => { });
    tableScene = null; core.sessionLog("table clear"); return;
  }
  let text = (q.text || "").trim(); const pm = text.match(/^\[?(\d{1,4})\]?\s+(?=\S)/); if (pm) { q.para ||= pm[1]; text = text.slice(pm[0].length); }
  const quote = { text, title: q.title || "", code: q.code || "", para: q.para || "" };
  const ref = [quote.title, quote.code, quote.para ? `¶${quote.para}` : ""].filter(Boolean).join(" · ");
  const before = S.obs.connected ? S.obsScenes.current : "";
  if (q.action === "lower") core.showLowerCard({ type: "message", kicker: "The Message", lines: [text], ref });
  else if (q.action === "project") core.present({ type: "message", ...quote, oneSlide: q.source !== "selection" });
  setTimeout(() => { const now = S.obs.connected ? S.obsScenes.current : ""; if (before && now && now !== before && !tableScene) tableScene = { from: before, to: now }; }, 600);
  emit({ quote: quote });
  core.sessionLog(`table ${q.action} ${quote.code} ¶${quote.para} target=${q.target || q.action} source=${q.source || "?"} chars=${text.length}`);
  try { await core.saveTableQuote(quote, q.parts); emit("quotes"); } catch { }
}

// what is on the lower third right now (name card with its countdown, quote, verse…) — click to take it off
let chipTimer = null;
function lowerChip() {
  const b = document.getElementById("btn-lcard"); if (!b) return;
  const l = S.lowerManual; clearTimeout(chipTimer);
  b.hidden = !l; if (!l) return;
  const left = l.until ? Math.max(0, Math.ceil((l.until - Date.now()) / 1000)) : 0;
  const qp = l.kind === "message" ? ((l.ref || "").match(/¶[\d–-]+/) || [""])[0] : "";
  b.querySelector("span").textContent = ({ name: "Name", title: "Title", message: "Quote", bible: "Verse", text: "Text" }[l.kind] || "Lower ⅓") + (qp ? " " + qp : "") + (left ? ` · ${left}s` : "");
  if (left) chipTimer = setTimeout(lowerChip, 500);
}
function updateTop() {
  const live = S.live, sl = live.slides[live.index];
  const lab = document.getElementById("live-label");
  const pill = document.getElementById("pill-live");
  if (live.override) { lab.textContent = "Projector: " + ({ blank: "blank", logo: "logo", camera: "camera" }[live.override] || "cleared"); pill.className = "pill"; }
  else if (sl) { lab.textContent = `${live.title} · ${sl.label || ""}`.slice(0, 48); pill.className = "pill live"; }
  else { lab.textContent = "Nothing live"; pill.className = "pill"; }
  document.getElementById("btn-lower").classList.toggle("on", S.lowerFollow);
  lowerChip();
  const po = document.getElementById("pill-obs"), lv = S.obsStats?.level;
  po.className = "pill" + (S.obs.connected ? (lv === "bad" ? " bad" : lv === "warn" ? " warn" : " ok") : "");
  po.lastElementChild.textContent = S.obs.connected ? `OBS · ${(S.obsScenes.current || "connected").replace(/^Revival · \d+ /, "")}` : "OBS off";
  const ph = document.getElementById("pill-health");
  if (ph) { const t = healthText(); ph.style.display = t ? "" : "none"; ph.lastElementChild.textContent = t; ph.title = healthTip(); ph.className = "pill" + (lv === "bad" ? " bad" : lv === "warn" ? " warn" : " ok"); }
  const psn = document.getElementById("pill-sound");
  if (psn) { const on = sound.level !== "off" && !!sound.status; psn.style.display = on ? "" : "none"; psn.lastElementChild.textContent = sound.level === "bad" ? "Sound ⚠ " + (sound.alerts[0]?.title || "") : sound.status; psn.title = [(sound.alerts || []).map(a => a.title).join("\n") || "Sound OK", sound.watch ? `Watching what OBS sends to the stream: ${sound.watch}` : "Stream sound meter: not connected", sound.streamDb != null ? `Level now: ${sound.streamDb.toFixed(0)} dBFS` : ""].filter(Boolean).join("\n"); document.body.classList.toggle("sound-flash", (sound.alerts || []).some(a => a.flash)); psn.className = "pill" + (sound.level === "bad" ? " bad" : sound.level === "warn" ? " warn" : " ok"); psn.onclick = () => show("production"); }
  const pl = document.getElementById("pill-onair");
  if (pl) { const o = S.obsStats || {}; pl.style.display = o.live ? "" : "none"; pl.lastElementChild.textContent = o.stream ? `LIVE ${o.tc || ""}` : `REC ${o.rtc || ""}`; }
  document.getElementById("pill-bus").className = "pill" + (S.busConnected ? " ok" : "");
  document.getElementById("pill-bus").lastElementChild.textContent = S.busConnected ? "Outputs linked" : "Outputs: this browser";
}

boot().catch(e => { console.error(e); document.getElementById("boot").textContent = "Error: " + e.message; });
