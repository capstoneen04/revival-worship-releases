// The "is YouTube getting sound?" decision (2.6), kept free of imports so test/sound/ can check it on its own.
//   meter: { ok, db, names }  from obs-meter.js (ok:false = the meter feed is missing — that is NOT silence)
//   returns { silentSince, verdict: "ok" | "silent" | "no-source" | "meter-missing" | "not-live", secs }
export const SILENT_DB = -55, SILENT_SECS = 10;
export function judgeStreamSound(prevSilentSince, { live, meter, now = Date.now() }) {
  if (!live) return { silentSince: 0, verdict: "not-live", secs: 0 };
  if (!meter || !meter.ok) return { silentSince: 0, verdict: "meter-missing", secs: 0 };
  const quiet = !(meter.db > SILENT_DB);
  const silentSince = quiet ? (prevSilentSince || now) : 0;
  const secs = silentSince ? Math.round((now - silentSince) / 1000) : 0;
  if (secs >= SILENT_SECS) return { silentSince, verdict: meter.names && meter.names.length ? "silent" : "no-source", secs };
  return { silentSince, verdict: "ok", secs };
}
