// Runs inside The Table window (2.6). Adds a READING BAND and a compact control bar.
//
//   Reading band — two thin lines over the page. Whatever full lines of text lie between them is what goes on screen.
//   Its height follows the output: Lower third (2–3 printed lines), Side panel of Sermon Split (~6), Projector (~5).
//   Drag the small ≡ tab on the top line to move the band, the one on the bottom line to change how many lines it holds;
//   every output remembers its own height.
//
//   ▣ / ▶  send the selected text if something is selected (then the selection is cleared), otherwise what is in the band.
//   ✕      takes the quote off the lower third / side panel and the projector.
//   ⇣ Follow  while on, the band's text goes on screen as you scroll with the preacher — only when it has changed and held
//          still for a moment (or as soon as scrolling stops), never the same text twice, and tiny scroll-ups are ignored.
//          A click on a paragraph brings it into the band.
//
// The sermon title and date code come from the result / page the text belongs to (sermonFor), not the first one on the page.
// This file is also loaded by test/table/ in a normal browser with a stub require("electron") — keep it free of other requires.
const { ipcRenderer } = require("electron");

const CODE_RE = /\b(\d{2}-\d{4}[A-Z]?)\b/;
const clean = (t) => (t || "").replace(/\s+/g, " ").trim();
const titleCase = (t) => t === t.toUpperCase() ? t.toLowerCase().replace(/(^|[\s(-])([a-z])/g, (m, a, b) => a + b.toUpperCase()) : t;

// "59-0611 The Time Of Decision 57-58" → { code, title, range }   (search hits add the paragraph range at the end)
function parseHeader(t) {
  t = clean(t); const code = (t.match(CODE_RE) || [])[1] || "";
  let rest = clean(t.replace(CODE_RE, "")).replace(/^[\s\-–|·:]+/, "");
  const rm = rest.match(/\s(\d{1,4})(?:\s*-\s*(\d{1,4}))?$/); const range = rm ? rm[1] : "";
  if (rm) rest = rest.slice(0, rm.index);
  return { code, title: titleCase(clean(rest.replace(/[\s\-–|·:]+$/, ""))), range };
}
const isHeader = (el) => { const t = clean(el.innerText); return t && t.length < 160 && CODE_RE.test(t) && ![...el.children].some(c => CODE_RE.test(c.innerText || "")); };
const hasTitle = (el) => /[A-Za-z]{3,}/.test(clean(el.innerText).replace(CODE_RE, ""));
function sermonFor(node) {
  const start = node && (node.nodeType === 1 ? node : node.parentElement);
  for (let n = start, i = 0; n && n !== document.documentElement && i < 10; n = n.parentElement, i++) {
    const before = [...n.querySelectorAll("*")].filter(el => isHeader(el) && (el.compareDocumentPosition(start) & Node.DOCUMENT_POSITION_FOLLOWING) && el.getBoundingClientRect().height);
    if (!before.length) continue;
    const titled = before.filter(hasTitle);
    const h = parseHeader((titled.length ? titled[titled.length - 1] : before[before.length - 1]).innerText);
    if (!h.title) { const bar = document.querySelector("[class*=sermon-title-bar]"); if (bar) { const b = parseHeader(bar.innerText); if (b.code === h.code) h.title = b.title; } }
    return h;
  }
  const bar = document.querySelector("[class*=sermon-title-bar]");
  if (bar) return parseHeader(bar.innerText);
  return parseHeader(CODE_RE.test(document.title) ? document.title : "");
}
// the paragraph block (its text starts with its number) that contains a node.
// On The Table each paragraph is <p class="normal_pn"><span class="first st"><span class="pn">175</span> first phrase…</span>
// <span class="st">…</span>…</p>. The first phrase's span ALSO starts with the number, so the old "nearest ancestor whose text
// starts with a number" took that span for the whole paragraph — that is how only "I said, “That same God,” hallelujah,
// “that Jehovah-jireh," of ¶175 went on screen on 22 Nov 2026. Only block elements count as a paragraph now.
const PARA_RE = /^\[?(\d{1,4})\]?\s+(\S.*)$/s;
const isInline = (el) => { try { return /^inline/.test(getComputedStyle(el).display); } catch { return false; } };
function paragraphOf(node) {
  const start = node && (node.nodeType === 1 ? node : node.parentElement);
  if (!start) return null;
  const p = start.closest && start.closest("p");
  if (p) { const t = clean(p.innerText); const m = t.match(PARA_RE); if (m && +m[1] > 0 && t.length < 8000) return { el: p, para: m[1], text: m[2] }; }
  for (let n = start, i = 0; n && n !== document.body && i < 8; n = n.parentElement, i++) {
    if (isInline(n)) continue;
    const t = clean(n.innerText); const m = t.match(PARA_RE);
    if (m && +m[1] > 0 && t.length < 8000) return { el: n, para: m[1], text: m[2] };   // ("0 results" of the search list is not ¶0)
  }
  return null;
}

// ---------- settings, remembered in this window's own storage ----------
const TARGETS = {
  lower: { label: "Lower third", action: "lower", lines: 3, min: 1, max: 4 },
  side: { label: "Side panel", action: "lower", lines: 6, min: 2, max: 12 },
  project: { label: "Projector", action: "project", lines: 5, min: 2, max: 12 },
};
// How many letters each output shows comfortably (measured 22 Nov 2026 by rendering real Table paragraphs through the band
// on web/obs/lower-third.html and web/obs/split.html — test/overlays/calibrate.html):
//   lower third: 3 band lines ≈ 280 letters → 3 lines at 30 px; 4 lines ≈ 375 → 26 px (too small) → limit 320
//   side panel:  6 band lines ≈ 410–530 letters → 34–40 px; 8 lines ≈ 600–670 → 31–34 px → limit 560
// More than this → the output shrinks its font to fit and the band gets an amber edge.
const CAPACITY = { lower: 320, side: 560, project: 520 };
const KEY = "rw-table-2.6";
const cfg = (() => { let c = {}; try { c = JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { } return Object.assign({ target: "lower", topPct: 0.30, startFollow: false, barTop: false }, c, { lines: Object.assign({ lower: 3, side: 6, project: 5 }, c.lines || {}) }); })();
const saveCfg = () => { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch { } };

let follow = false;
function send(action, payload) { ipcRenderer.send("quote", { ...payload, action }); }

// ---------- band geometry ----------
const band = { top: 0, bottom: 0, lineH: 0 };
function measureLineHeight() {
  // the printed line height of the sermon text: distinct line tops of a visible paragraph
  const probe = paragraphOf(document.elementFromPoint(Math.round(window.innerWidth / 2), Math.round(window.innerHeight * 0.45)))
    || paragraphOf(document.elementFromPoint(Math.round(window.innerWidth / 2), Math.round(window.innerHeight * cfg.topPct)));
  if (probe) {
    const r = document.createRange(); r.selectNodeContents(probe.el);
    const tops = [...new Set([...r.getClientRects()].filter(x => x.width > 2 && x.height > 4).map(x => Math.round(x.top)))].sort((a, b) => a - b);
    const gaps = []; for (let i = 1; i < tops.length; i++) { const g = tops[i] - tops[i - 1]; if (g > 8 && g < 80) gaps.push(g); }
    if (gaps.length) { gaps.sort((a, b) => a - b); return gaps[Math.floor(gaps.length / 2)]; }
    const lh = parseFloat(getComputedStyle(probe.el).lineHeight); if (lh > 8 && lh < 80) return lh;
  }
  return band.lineH || 28;
}
function layoutBand() {
  band.lineH = measureLineHeight();
  const n = cfg.lines[cfg.target] || TARGETS[cfg.target].lines;
  band.top = Math.round(window.innerHeight * cfg.topPct);
  band.bottom = Math.round(band.top + n * band.lineH);
}

// ---------- what lies inside the band ----------
// Every word whose middle is between the two lines, in reading order, grouped per paragraph. Whole lines only (a line's
// words share one vertical position), never a cut word.
function scrollerOf(el) {
  for (let n = el; n && n !== document.body && n !== document.documentElement; n = n.parentElement) {
    const s = getComputedStyle(n); if (/(auto|scroll)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 4) return n;
  }
  return null;
}
function firstTextNode(el) { const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode: n => n.nodeValue.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP }); return w.nextNode(); }
function bandContent(ui) {
  const top = band.top, bot = band.bottom;
  const words = []; const paraCache = new Map(); const rng = document.createRange();
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      if (!n.nodeValue.trim()) return NodeFilter.FILTER_SKIP;
      const p = n.parentElement; if (!p || (ui && ui.contains(p))) return NodeFilter.FILTER_SKIP;
      rng.selectNodeContents(n);
      for (const r of rng.getClientRects()) if (r.bottom >= top && r.top <= bot && r.height) return NodeFilter.FILTER_ACCEPT;
      return NodeFilter.FILTER_SKIP;
    },
  });
  for (let n; (n = walker.nextNode());) {
    const pe = n.parentElement;
    let p = paraCache.get(pe);
    if (p === undefined) {                              // one object per paragraph element, however many spans it has
      p = paragraphOf(n);
      if (p) { const known = paraCache.get(p.el); if (known && known.el === p.el) p = known; else { p.first = firstTextNode(p.el); paraCache.set(p.el, p); } }
      paraCache.set(pe, p);
    }
    if (!p) continue;                                   // headers, menus, search box … are never part of a quote
    const re = /\S+/g; let m, firstWord = true;
    while ((m = re.exec(n.nodeValue))) {
      rng.setStart(n, m.index); rng.setEnd(n, m.index + m[0].length);
      const r = rng.getBoundingClientRect();
      const isNum = firstWord && n === p.first && /^\[?\d{1,4}\]?$/.test(m[0]) && m[0].replace(/\D/g, "") === p.para;
      firstWord = false;
      if (isNum || !r.height || !r.width) continue;     // the paragraph number itself / hidden text
      const mid = (r.top + r.bottom) / 2;
      if (mid < top || mid > bot) continue;
      // only words the operator can actually see (not text hidden behind the reading panel, e.g. the search list)
      const hit = document.elementFromPoint(Math.min(window.innerWidth - 1, Math.max(0, (r.left + r.right) / 2)), mid);
      if (hit && !p.el.contains(hit) && !(ui && ui.contains(hit))) continue;
      words.push({ w: m[0], p, y: Math.round(r.top), l: r.left, r: r.right, n });
    }
  }
  if (!words.length) return null;
  // lines (same paragraph + same vertical position ±3 px)
  const lines = [];
  for (const wd of words) { const L = lines[lines.length - 1]; if (L && L.p === wd.p && Math.abs(L.y - wd.y) <= 3) L.words.push(wd); else lines.push({ p: wd.p, y: wd.y, words: [wd] }); }
  // start at a sentence when one begins within the first line (and the band holds more than that line)
  const startsPara = (L) => clean(L.p.text).startsWith(L.words[0].w);
  if (lines.length > 1 && !startsPara(lines[0])) {
    const ws = lines[0].words; const k = ws.findIndex((x, j) => j < ws.length - 1 && /[.?!][”"’')\]]*$/.test(x.w));
    if (k >= 0) lines[0] = { ...lines[0], words: ws.slice(k + 1) };
  }
  const join = (ws) => { let s = ""; ws.forEach((x, j) => { const prev = ws[j - 1]; s += (!prev ? "" : (prev.n !== x.n && Math.abs(prev.y - x.y) <= 3 && x.l - prev.r < 1.5) ? "" : " ") + x.w; }); return s; };
  const segs = [];
  for (const L of lines) { const S = segs[segs.length - 1]; if (S && S.p === L.p) { S.words.push(...L.words); S.lines.push(L.y); } else segs.push({ p: L.p, words: [...L.words], lines: [L.y] }); }
  const meta = sermonFor(segs[0].p.el);
  // line numbers inside the first paragraph, for the "On screen: ¶175 (lines 3–5)" note
  const r0 = document.createRange(); r0.selectNodeContents(segs[0].p.el);
  const tops = [...new Set([...r0.getClientRects()].filter(x => x.width > 2 && x.height > 4).map(x => Math.round(x.top)))].sort((a, b) => a - b);
  const idx = (y) => { let best = 0, d = 1e9; tops.forEach((t, i) => { if (Math.abs(t - y) < d) { d = Math.abs(t - y); best = i; } }); return best + 1; };
  const paras = segs.map(s => s.p.para).filter((v, i, a) => a.indexOf(v) === i);
  return {
    text: segs.map(s => join(s.words)).join(" "),
    title: meta.title, code: meta.code,
    para: paras.length > 1 ? `${paras[0]}–${paras[paras.length - 1]}` : paras[0],
    parts: segs.map(s => ({ para: s.p.para, full: clean(s.p.text) })),
    lineCount: lines.length, from: idx(segs[0].lines[0]), to: idx(segs[0].lines[segs[0].lines.length - 1]),
    el: segs[0].p.el,
  };
}
function fromSelection() {
  const s = window.getSelection(); const text = clean(s?.toString());
  if (!text) return null;
  const meta = sermonFor(s.anchorNode);
  const p = paragraphOf(s.anchorNode);
  return { text, title: meta.title, code: meta.code, para: p?.para || meta.range || "", parts: p ? [{ para: p.para, full: clean(p.text) }] : [] };
}

// for the test page (test/table/) — harmless inside Electron (the page can't reach it through context isolation)
if (typeof window !== "undefined") window.__rwTable = { bandContent: () => bandContent(document.getElementById("rw-table-ui")), layoutBand, band, cfg, paragraphOf, sermonFor, parseHeader, CAPACITY };

window.addEventListener("DOMContentLoaded", () => {
  const ui = document.createElement("div"); ui.id = "rw-table-ui";
  // ----- the band -----
  const mkLine = (which) => {
    const l = document.createElement("div");
    l.style.cssText = "position:fixed;left:0;right:0;height:0;border-top:2px solid rgba(31,111,224,.75);z-index:2147483645;pointer-events:none";
    const tab = document.createElement("div"); tab.textContent = "≡"; tab.title = which === "top" ? "Drag to move the reading band" : "Drag to change how many lines go on screen";
    tab.style.cssText = "position:absolute;left:6px;top:-11px;width:30px;height:20px;border-radius:6px;background:#1f6fe0;color:#fff;font:700 13px/20px system-ui;text-align:center;cursor:ns-resize;pointer-events:auto;user-select:none";
    l.appendChild(tab); ui.appendChild(l); return { l, tab };
  };
  const shade = document.createElement("div"); shade.style.cssText = "position:fixed;left:0;right:0;background:rgba(31,111,224,.06);z-index:2147483644;pointer-events:none";
  ui.appendChild(shade);
  const T = mkLine("top"), B = mkLine("bottom");
  // ----- the bar (compact, see-through until the mouse is over it) -----
  const bar = document.createElement("div");
  bar.style.cssText = "position:fixed;right:12px;z-index:2147483647;display:flex;gap:4px;align-items:center;background:rgba(15,20,35,.88);padding:5px;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,.3);font:600 12.5px -apple-system,system-ui,sans-serif;opacity:.55;transition:opacity .15s";
  const menu = document.createElement("div");
  menu.style.cssText = "display:none;position:absolute;right:0;bottom:44px;background:#141a2b;color:#e6eaf3;border-radius:10px;padding:8px 10px;box-shadow:0 8px 24px rgba(0,0,0,.4);font:500 13px system-ui;white-space:nowrap";
  const placeBar = () => {
    bar.style.top = cfg.barTop ? "12px" : ""; bar.style.bottom = cfg.barTop ? "" : "12px";
    menu.style.bottom = cfg.barTop ? "" : "44px"; menu.style.top = cfg.barTop ? "44px" : "";
    document.body.style.paddingBottom = cfg.barTop ? "" : "90px";          // the last lines can scroll above the bar
  };
  bar.onmouseenter = () => (bar.style.opacity = "1");
  bar.onmouseleave = () => { if (menu.style.display !== "block") bar.style.opacity = ".55"; };
  const mk = (label, bg, tip) => { const b = document.createElement("button"); b.textContent = label; b.title = tip; b.style.cssText = `border:0;border-radius:8px;padding:6px 9px;background:${bg};color:#fff;font:inherit;cursor:pointer;white-space:nowrap`; bar.appendChild(b); return b; };
  const lower = mk("▣", "#1f6fe0", "Lower third / side panel: the selected text, or what is in the band");
  const proj = mk("▶", "#d64545", "Projector: the selected text, or what is in the band");
  const clear = mk("✕", "#3a4256", "Take the quote off the lower third, side panel and projector");
  const fol = mk("⇣ Follow", "#3a4256", "On: what is in the band goes on screen as you scroll");
  const tgt = mk("", "#2b3348", "Which output the band is sized for — click to change");
  const more = mk("⋯", "#2b3348", "Options");
  const note = document.createElement("span"); note.style.cssText = "color:#cfd6e6;font-weight:500;padding:0 6px;max-width:230px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"; bar.appendChild(note);
  const opt = (label, key, after) => { const r = document.createElement("label"); r.style.cssText = "display:flex;gap:8px;align-items:center;padding:4px 0;cursor:pointer"; const c = document.createElement("input"); c.type = "checkbox"; c.checked = !!cfg[key]; c.onchange = () => { cfg[key] = c.checked; saveCfg(); if (after) after(); }; r.append(c, label); menu.appendChild(r); };
  opt("Start The Table with Follow on", "startFollow");
  opt("Bar at the top right", "barTop", placeBar);
  bar.appendChild(menu);
  more.onclick = () => { menu.style.display = menu.style.display === "block" ? "none" : "block"; };

  let sticky = "";
  const say = (t, keep) => { note.textContent = t; clearTimeout(say.t); if (keep) sticky = t; else say.t = setTimeout(() => (note.textContent = sticky), 2500); };
  const paint = () => {
    layoutBand();
    T.l.style.top = band.top + "px"; B.l.style.top = band.bottom + "px";
    shade.style.top = band.top + "px"; shade.style.height = Math.max(0, band.bottom - band.top) + "px";
    tgt.textContent = `${TARGETS[cfg.target].label} · ${cfg.lines[cfg.target]}`;
  };
  const amber = (on) => { const c = on ? "rgba(217,140,20,.95)" : "rgba(31,111,224,.75)"; T.l.style.borderTopColor = c; B.l.style.borderTopColor = c; shade.style.background = on ? "rgba(217,140,20,.08)" : "rgba(31,111,224,.06)"; };

  // ----- sending -----
  const actionFor = () => TARGETS[cfg.target].action;
  let lastKey = "", lastPos = null, lastScroller = null, liveEl = null;
  const mark = (el) => { if (liveEl && liveEl !== el) liveEl.style.boxShadow = ""; liveEl = el; if (el) el.style.boxShadow = "inset 4px 0 0 #1f6fe0"; };
  const pos = () => lastScroller ? lastScroller.scrollTop : window.scrollY;
  const strip = ({ el, lineCount, from, to, ...payload }) => payload;
  const sendBand = (c, key, how, action = actionFor()) => {
    lastKey = key; lastPos = pos();
    send(action, { ...strip(c), source: how, target: cfg.target });
    mark(c.el); amber(c.text.length > CAPACITY[cfg.target]);
    return `¶${c.para} (line${c.from === c.to ? "" : "s"} ${c.from}${c.from === c.to ? "" : "–" + c.to})`;
  };
  const go = (action) => {
    const s = fromSelection();
    if (s) { send(action, { ...s, source: "selection", target: cfg.target }); window.getSelection().removeAllRanges(); say(`${action === "lower" ? "Lower third" : "Projector"} ✓ ${s.code} ¶${s.para || "?"}`); return; }
    const c = bandContent(ui); if (!c) { say("Nothing in the band — scroll the text into it"); return; }
    say(`${action === "lower" ? "Lower third" : "Projector"} ✓ ${c.code} ` + sendBand(c, c.code + "|" + c.para + "|" + c.text, "band", action), follow);
  };
  lower.onclick = () => go("lower"); proj.onclick = () => go("project");
  clear.onclick = () => { ipcRenderer.send("quote", { action: "clear" }); lastKey = ""; mark(null); amber(false); say("Cleared"); };

  // Follow: the band's content goes out when it has changed and held still for HOLD ms, or straight away when scrolling stops.
  const HOLD = 320, STOP = 150;
  let cand = null, holdT = null, stopT = null, busy = false;
  function check(final) {
    if (!follow) return;
    const c = bandContent(ui); if (!c || !c.text) return;
    const key = c.code + "|" + c.para + "|" + c.text;
    if (key === lastKey) { cand = null; return; }                                   // never the same text twice
    const p = pos();
    if (lastPos != null && p < lastPos && lastPos - p < band.lineH * 0.95) return;   // a tiny scroll-up is noise
    if (!final) {
      if (!cand || cand.key !== key) { cand = { key, at: Date.now() }; clearTimeout(holdT); holdT = setTimeout(() => check(false), HOLD + 10); return; }
      if (Date.now() - cand.at < HOLD) return;
    }
    cand = null; say("On screen: " + sendBand(c, key, final ? "follow-stop" : "follow-hold"), true);
  }
  const setFollow = (on) => {
    follow = on; lastKey = ""; cand = null; sticky = "";
    fol.textContent = follow ? "⇣ Follow ✓" : "⇣ Follow"; fol.style.background = follow ? "#16a34a" : "#3a4256";
    if (follow) { say("Follow on", true); check(true); } else { mark(null); say("Follow off"); }
  };
  fol.onclick = () => setFollow(!follow);
  tgt.onclick = () => { const ks = Object.keys(TARGETS); cfg.target = ks[(ks.indexOf(cfg.target) + 1) % ks.length]; saveCfg(); paint(); lastKey = ""; if (follow) check(true); };

  // ----- dragging the band lines -----
  const drag = (which) => (e) => {
    e.preventDefault(); e.stopPropagation();
    const move = (ev) => {
      if (which === "top") cfg.topPct = Math.min(0.75, Math.max(0.06, ev.clientY / window.innerHeight));
      else { const t = TARGETS[cfg.target]; cfg.lines[cfg.target] = Math.min(t.max, Math.max(t.min, Math.round((ev.clientY - band.top) / band.lineH))); }
      paint();
    };
    const up = () => { removeEventListener("pointermove", move, true); removeEventListener("pointerup", up, true); saveCfg(); lastKey = ""; if (follow) check(true); };
    addEventListener("pointermove", move, true); addEventListener("pointerup", up, true);
  };
  T.tab.addEventListener("pointerdown", drag("top")); B.tab.addEventListener("pointerdown", drag("bottom"));

  window.addEventListener("scroll", (e) => {
    const t = e.target; const sc = (t && t.nodeType === 1 && t !== document.documentElement && t !== document.body) ? t : null;
    if (sc !== lastScroller) { lastScroller = sc; lastPos = null; }
    if (!follow) return;
    if (!busy) { busy = true; setTimeout(() => { busy = false; check(false); }, 100); }
    clearTimeout(stopT); stopT = setTimeout(() => check(true), STOP);
  }, true);
  window.addEventListener("resize", () => { paint(); if (follow) check(true); });
  // Follow on: a click on a paragraph brings its first line to the top of the band (then it goes on screen)
  document.addEventListener("click", (e) => {
    if (!follow || ui.contains(e.target) || (window.getSelection()?.toString() || "").trim()) return;
    const p = paragraphOf(e.target); if (!p) return;
    const r = document.createRange(); r.selectNodeContents(p.el); const first = [...r.getClientRects()].find(x => x.height > 4 && x.width > 2);
    if (!first) return;
    const dy = Math.round(first.top - band.top - 2);
    lastKey = ""; lastPos = null;
    if (Math.abs(dy) < 3) { check(true); return; }
    (scrollerOf(p.el) || window).scrollBy({ top: dy, behavior: "smooth" });
  }, true);

  ui.appendChild(bar); document.body.appendChild(ui);
  placeBar(); paint();
  // the page loads its text after this script — measure the line height again once it is there
  setTimeout(paint, 1500); setTimeout(paint, 4000);
  if (cfg.startFollow) setTimeout(() => setFollow(true), 1600);
  if (typeof window !== "undefined") Object.assign(window.__rwTable, { setFollow, paint, check });
});
