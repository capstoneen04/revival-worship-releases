// First start on a new computer: unlock the church library (songs + Hindi Bible) with the church password.
import { h, native } from "./core.js";
export async function libraryGate(bootEl) {
  if (!native?.library) return;                       // browser / phone pages: served by the Mac app
  let st; try { st = await native.library.status(); } catch { return; }
  if (!st.pack || (st.unlocked && !st.passwordChanged)) return;
  const changed = st.unlocked && st.passwordChanged;
  await new Promise((resolve) => {
    const pw = h("input", { class: "input", type: "password", placeholder: "Church library password", style: "width:280px;height:38px;font-size:15px", autocomplete: "off" });
    const msg = h("div", { class: "muted", style: "min-height:20px;font-size:12.5px" }, "");
    const go = async () => {
      if (!pw.value.trim()) { pw.focus(); return; }
      btn.disabled = true; msg.textContent = "Unlocking…";
      const r = await native.library.unlock(pw.value.trim());
      if (r.ok) { msg.textContent = `Unlocked — ${r.files} files.`; box.remove(); resolve(); }
      else { msg.textContent = r.error; btn.disabled = false; pw.select(); }
    };
    const btn = h("button", { class: "btn primary", style: "height:38px", onclick: go }, "Unlock");
    pw.addEventListener("keydown", e => { if (e.key === "Enter") go(); });
    const box = h("div", { class: "unlock" },
      h("img", { src: "assets/img/logo.png", style: "width:84px;height:84px;border-radius:50%;background:#fff" }),
      h("h2", {}, changed ? "New church library password" : "Welcome to Revival Worship"),
      changed ? h("p", { class: "muted", style: "max-width:520px;text-align:center" }, "The media team changed the church library password. Type the new password once to get the latest songs. Your songs stay as they are until then.") :
      h("p", { class: "muted", style: "max-width:520px;text-align:center" }, "Type the church library password once to unlock the songs and the Hindi Bible on this computer. Ask the media team if you don't have it. Updates unlock by themselves after this."),
      h("div", { class: "row", style: "justify-content:center" }, pw, btn), msg,
      h("button", { class: "btn ghost sm", onclick: () => { box.remove(); resolve(); } }, changed ? "Later (keep the songs I have)" : "Later (open without songs)"));
    bootEl.style.display = "none";
    document.body.appendChild(box); pw.focus();
  });
  bootEl.style.display = "";
}
