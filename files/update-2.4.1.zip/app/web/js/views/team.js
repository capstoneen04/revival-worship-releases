// Team songbook on the desktop: approve songs sent from the team phones, publish the church library to GitHub.
import { S, h, toast, modal, saveSong, native, db, newService, switchService, saveService, uid } from "../core.js";
import { stripChords } from "../chords.js";
import { sectionsToText } from "../song-text.js";

const T = () => native?.team;
const ago = (iso) => { const d = (Date.now() - new Date(iso)) / 60000; return d < 60 ? `${Math.max(1, Math.round(d))} min ago` : d < 1440 ? `${Math.round(d / 60)} h ago` : new Date(iso).toLocaleDateString(); };
// ---- is this song already in the songbook? compare the words (3-letter pieces), so photo/typing mistakes still match ----
const clean = (t) => (t || "").replace(/\[[^\]]*\]/g, " ").replace(/\(x\d+\)|\.{2,}\s*\d/g, " ").replace(/^\s*[\d१-९]+[.)]?\s+/gm, "").replace(/[^\p{L}\p{M}]+/gu, "").toLowerCase();
const grams = (t) => { const c = clean(t), g = new Set(); for (let i = 0; i + 3 <= c.length; i++) g.add(c.slice(i, i + 3)); return g; };
const songWords = (s) => Object.values(s.versions || {}).filter(v => !v.auto).map(v => [v.title, ...(v.sections || []).flatMap(x => x.lines)].join("\n")).join("\n");
let gramIndex = null, gramFor = 0;
export function findMatches(song, limit = 2) {
  if (!gramIndex || gramFor !== S.songs.length) { gramIndex = S.songs.map(s => ({ s, g: grams(songWords(s)) })); gramFor = S.songs.length; }
  const q = grams(songWords(song)); if (q.size < 12) return [];
  const out = [];
  for (const x of gramIndex) { if (x.s.id === song.id) continue; let n = 0; for (const t of q) if (x.g.has(t)) n++; const score = n / q.size; if (score >= 0.55) out.push({ song: x.s, score }); }
  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}
const bookOf = (s) => (s.books || []).map(b => b.book + " " + b.num).join(", ");
const preview = (song) => { const v = song?.versions?.[song.lang] || Object.values(song?.versions || {})[0]; return (v?.sections || []).slice(0, 2).map(s => `[${s.label}]\n` + s.lines.slice(0, 4).map(stripChords).join("\n")).join("\n\n"); };

export async function inboxCount() { if (!T()) return 0; const st = await T().status(); if (!st.hasToken) return 0; const r = await T().inbox(); return r.ok ? new Set(r.items.map(i => i.kind === "setlist" ? "l" + (i.setlist?.id || i.name) : "s" + (i.song?.id || i.name))).size : 0; }

// ctx = { review(draft, { by, onSaved, onCancel }), open(id), changed() } — provided by the Songs page
export async function openInbox(ctx = {}) {
  if (!T()) return toast("The song inbox works in the desktop app");
  const st = await T().status(); if (!st.hasToken) return modal("Song inbox", h("p", { class: "muted" }, "Add the GitHub team key in Settings → Team songbook first."), [{ label: "OK" }]);
  const body = h("div", { class: "col", style: "max-height:66vh;overflow:auto;padding-right:4px" }, h("div", { class: "muted" }, "Loading songs from the team phones…"));
  const close = modal("Song inbox — from the team phones", body, [{ label: "Close" }]); close.firstChild.style.width = "min(760px, 92vw)";
  const r = await T().inbox();
  body.innerHTML = "";
  if (!r.ok) { body.append(h("div", { class: "muted" }, r.error)); return; }
  // one card per song: if a tester sent the same song several times (corrections), only the newest is shown; the older ones go with it
  const groups = new Map();
  for (const it of r.items) {
    const k = it.kind === "setlist" ? "list:" + (it.setlist?.id || it.name) : "song:" + (it.song?.id || it.name);
    const g = groups.get(k); if (!g) groups.set(k, { latest: it, older: [] });
    else if (String(it.at) > String(g.latest.at)) { g.older.push(g.latest); g.latest = it; } else g.older.push(it);
  }
  if (!groups.size) { body.append(h("div", { class: "muted" }, "Nothing waiting. New songs from the team phones appear here.")); return; }
  const resolve = async (g, why, decision) => {           // remove the card's submission(s) from the inbox and tell the phone
    for (const x of [g.latest, ...g.older]) { const d = await T().remove(x.path, x.sha, why, decision); if (!d.ok) { toast(d.error); return false; } }
    ctx.changed?.(); return true;
  };
  for (const g of groups.values()) {
    if (g.latest.kind === "setlist") { body.append(setlistRow(g.latest, g.older, ctx)); continue; }
    body.append(songRow(g));
  }

  function songRow(g) {
    const it = g.latest, song = it.song || {};
    const exists = S.songs.find(s => s.id === song.id);
    const matches = exists ? [] : findMatches(song); const dup = matches[0]?.song;
    const by = it.by || "the team";
    const row = h("div", { class: "card col", style: "gap:6px" },
      h("div", { class: "row" }, h("b", { style: "flex:1" }, song.title || "Untitled"),
        h("span", { class: "chip" }, exists ? "Correction" : "New song"),
        h("span", { class: "dim", style: "font-size:12px" }, `${by} · ${ago(it.at)}`)),
      g.older.length ? h("div", { class: "dim", style: "font-size:12px" }, `Sent ${g.older.length + 1} times — showing the newest; the older ones are cleared with it.`) : null,
      it.note ? h("div", { class: "muted", style: "font-size:12.5px" }, "Note: " + it.note) : null,
      exists ? h("div", { class: "muted", style: "font-size:12.5px" }, `Correction to ${bookOf(exists)} “${exists.title}” — the number stays ${bookOf(exists)}.`)
        : matches.length ? h("div", { style: "font-size:12.5px;color:#d97706;display:flex;flex-direction:column;gap:4px" }, ...matches.map(m => h("div", {}, `⚠ ${Math.round(m.score * 100)}% the same as ${bookOf(m.song)} “${m.song.title}” — already in the songbook.`)))
        : h("div", { style: "font-size:12.5px;color:#16a34a" }, `✓ Checked all ${S.songs.length.toLocaleString()} songs — this is a new song. It will get ${bookStr(nextFree())}.`),
      h("pre", { style: "white-space:pre-wrap;font:inherit;font-size:13px;margin:0;max-height:180px;overflow:auto;background:var(--bg2,rgba(0,0,0,.04));padding:8px;border-radius:8px" }, preview(song)),
      h("div", { class: "row", style: "flex-wrap:wrap" },
        dup ? h("button", { class: "btn sm primary", onclick: () => compare(dup) }, `Compare with ${bookOf(dup)}`)
            : h("button", { class: "btn sm primary", onclick: () => review(exists || null) }, "Review"),
        h("span", { style: "flex:1" }),
        h("button", { class: "btn sm ghost", onclick: reject }, dup ? `Discard — keep ${bookOf(dup)}` : "Reject")));

    // Review: the song opens in Songs in edit mode (not saved yet). Save → it is added / updated and leaves the inbox. Cancel → it stays here.
    function review(target) {
      const draft = target ? JSON.parse(JSON.stringify(target)) : JSON.parse(JSON.stringify(song));
      if (target) { for (const [l, v] of Object.entries(song.versions || {})) { if (v.auto && draft.versions[l] && !draft.versions[l].auto) continue; draft.versions[l] = { ...v }; } if (song.key && !draft.key) draft.key = song.key; if (!exists) draft.title = target.title; else draft.title = song.title || target.title; }
      else { draft.books = []; draft.status = "ok"; draft.source = song.source || "team:" + by; }
      delete draft._score; delete draft._pending;
      close.remove();
      ctx.review?.(draft, {
        by, isNew: !target,
        onSaved: async (saved) => { const ok = await resolve(g, target && !exists ? "merged" : "approved", { songId: saved.id, book: bookOf(saved), title: saved.title }); if (ok) toast(`${bookOf(saved)} “${saved.title}” saved — cleared from the inbox. Publish library to send it to everyone.`); },
      });
    }
    function compare(old) {
      const col = (head, sg) => h("div", { class: "col", style: "flex:1;min-width:0;gap:4px" }, h("b", { style: "font-size:13px" }, head),
        h("pre", { style: "white-space:pre-wrap;font:inherit;font-size:13px;margin:0;max-height:52vh;overflow:auto;background:var(--bg2,rgba(0,0,0,.04));padding:8px;border-radius:8px" }, sectionsToText((sg.versions[sg.lang] || Object.values(sg.versions)[0]).sections)));
      const m = modal(`${bookOf(old)} “${old.title}” — songbook vs. sent`, h("div", { class: "row", style: "align-items:flex-start;gap:10px" }, col(`In the songbook (${bookOf(old)})`, old), col(`Sent by ${by}`, song)), [
        { label: `Keep ${bookOf(old)} as it is`, fn: () => { reject(); } },
        { label: "It's a different song — review", fn: () => review(null) },
        { label: `Review ${bookOf(old)} with the sent words`, cls: "primary", fn: () => review(old) }]);
      m.firstChild.style.width = "min(980px, 94vw)";
    }
    async function reject() { if (await resolve(g, "rejected", dup ? { songId: dup.id, book: bookOf(dup), title: dup.title, reason: "already in the songbook" } : {})) { row.remove(); toast("Removed from the inbox"); } }
    return row;
  }
}
const bookStr = (b) => `${b.book} ${b.num}`;
const nextFree = () => { const book = S.settings?.team?.newBook || "RH"; let max = 0; for (const s of S.songs) for (const b of s.books || []) if (b.book === book && b.num > max) max = b.num; return { book, num: max + 1 }; };

// ---- a song leader's set list → that day's service ----
const SH = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"], FL = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"];
const noteIx = (k) => { const m = String(k || "").trim().match(/^([A-G](?:#|b)?)/); if (!m) return -1; const i = SH.indexOf(m[1]); return i >= 0 ? i : FL.indexOf(m[1]); };
const semis = (from, to) => { const a = noteIx(from), b = noteIx(to); if (a < 0 || b < 0) return 0; let d = (b - a + 12) % 12; return d > 6 ? d - 12 : d; };
const niceDate = (iso) => { try { return new Date(iso + "T12:00:00").toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" }); } catch { return iso; } };
function setlistRow(it, older = [], ctx = {}) {
  const L = it.setlist || { items: [] };
  const row = h("div", { class: "card col", style: "gap:6px" },
    h("div", { class: "row" }, h("b", { style: "flex:1" }, `${L.title} — ${niceDate(L.date)}`), h("span", { class: "chip" }, "Set list"), h("span", { class: "dim", style: "font-size:12px" }, `${it.by || "Song leader"} · ${ago(it.at)}`)),
    h("ol", { style: "margin:0;padding-left:22px;font-size:13.5px;line-height:1.6" }, ...L.items.map(x => { const s = S.songs.find(y => y.id === x.songId); return h("li", {}, s ? `${bookOf(s)} ${s.title}` : "(song not on this computer)", x.key ? h("span", { class: "dim" }, `  · key ${x.key}${s?.key && s.key !== x.key ? " (song is in " + s.key + ")" : ""}`) : null); })),
    h("div", { class: "row" },
      h("button", { class: "btn sm primary", onclick: () => add(false) }, `Add to the service on ${niceDate(L.date)}`),
      h("button", { class: "btn sm", onclick: () => add(true) }, "Add to the open service"),
      h("span", { style: "flex:1" }),
      h("button", { class: "btn sm ghost", onclick: async () => { for (const x of [it, ...older]) { const d = await T().remove(x.path, x.sha, "rejected", { reason: "not used" }); if (!d.ok) return toast(d.error); } row.remove(); ctx.changed?.(); toast("Removed"); } }, "Discard")));
  async function add(current) {
    let svc = current ? S.service : (await db.all("services")).find(x => x.date === L.date);
    if (!svc) { svc = newService(new Date(L.date + "T12:00:00").getDay() === 0 ? "Sunday Service" : "Service"); svc.date = L.date; await db.put("services", svc); }
    const headTitle = `${L.title} — ${it.by || "song leader"}`;
    const block = [{ id: uid("it"), type: "header", title: headTitle }];
    for (const x of L.items) { const s = S.songs.find(y => y.id === x.songId); if (!s) continue; const t = x.key && s.key ? semis(s.key, x.key) : 0; block.push({ id: uid("it"), type: "song", songId: s.id, ...(t ? { transpose: t } : {}), ...(x.note ? { note: x.note } : {}) }); }
    // the same list sent again (changed) → replace the earlier block instead of adding the songs twice
    const at = svc.items.findIndex(x => x.type === "header" && x.title === headTitle);
    if (at >= 0) { let end = at + 1; while (end < svc.items.length && svc.items[end].type !== "header") end++; svc.items.splice(at, end - at, ...block); }
    else svc.items.push(...block);
    if (svc.id === S.service.id) { S.service = svc; await saveService(); } else await db.put("services", svc);
    for (const x of [it, ...older]) { const d = await T().remove(x.path, x.sha, "added", { service: `${svc.name}, ${niceDate(svc.date)}`, serviceId: svc.id }); if (!d.ok) toast(d.error); }
    row.remove(); ctx.changed?.(); toast(`Added ${L.items.length} songs to “${svc.name}” (${niceDate(svc.date)})`);
    if (svc.id !== S.service.id) modal("Set list added", h("p", { class: "muted" }, `The songs are in “${svc.name}” on ${niceDate(svc.date)}.`), [{ label: "OK" }, { label: "Open that service", cls: "primary", fn: () => { switchService(svc); window.rwShow?.("service"); } }]);
  }
  return row;
}

export async function publishLibrary(btn, out) {
  if (!T()) return;
  const by = S.settings.team?.name || "";
  if (btn) btn.disabled = true;
  T().onStep?.((t) => { if (out) out.textContent = t; });
  const songs = S.songs.filter(s => s.status !== "draft");
  const r = await T().publish(JSON.parse(JSON.stringify(songs)), by, { ...(S.settings.deletedSongs || {}) });
  if (btn) btn.disabled = false;
  const msg = !r.ok ? "Could not publish: " + r.error : r.nothing ? "Nothing new to publish — the library is up to date." : `Published library ${r.version}: ${r.added} new, ${r.changed} changed, ${r.removed || 0} removed (${r.total.toLocaleString()} songs). Other computers get it within 2 hours, phones when they open the songbook.`;
  if (out) out.textContent = msg; toast(msg.split(".")[0]);
  return r;
}

export function teamCard() {
  const box = h("div", { class: "card col" });
  if (!T()) return box;
  const render = async () => {
    const st = await T().status(); S.settings.team ||= {};
    const tok = h("input", { class: "input", type: "password", placeholder: st.hasToken ? "•••••••• (saved — paste a new one to replace)" : "Paste the GitHub key (github_pat_…)", autocomplete: "off" });
    const inbox = h("input", { class: "input", value: st.inbox });
    const name = h("input", { class: "input", value: S.settings.team.name || "", placeholder: "e.g. Media desk" });
    const books = Object.keys(S.books || {}).length ? S.books : { RH: "Revival Hindi Songbook" };
    const newBook = h("select", { class: "input" }, ...Object.entries(books).map(([k, v]) => h("option", { value: k, selected: k === (S.settings.team.newBook || "RH") }, `${k} — ${v}`)));
    newBook.onchange = async () => { S.settings.team.newBook = newBook.value; (await import("../core.js")).saveSettings(); const { nextBookNumber } = await import("../core.js"); toast(`New songs will be numbered from ${newBook.value} ${nextBookNumber().num}`); };
    const out = h("div", { class: "muted", style: "font-size:12.5px;min-height:18px" }, st.lastPublish ? `Last published: library ${st.lastPublish.version} · ${new Date(st.lastPublish.at).toLocaleString()} · ${st.lastPublish.added} new, ${st.lastPublish.changed} changed` : "");
    const pub = h("button", { class: "btn primary", disabled: !st.hasToken, onclick: () => publishLibrary(pub, out) }, "Publish library to everyone");
    box.innerHTML = "";
    box.append(h("div", { style: "font-weight:650;font-size:14px" }, "Team songbook & publishing"),
      h("div", { class: "muted", style: "font-size:12.5px" }, "Songs added on the team phones wait in Songs → Inbox. After approving, Publish sends the locked library to GitHub; every computer and phone then gets the new songs."),
      h("div", { class: "row" }, h("label", { class: "f", style: "flex:2" }, "GitHub key", tok), h("label", { class: "f", style: "flex:2" }, "Inbox repository", inbox), h("label", { class: "f", style: "flex:1" }, "This desk's name", name)),
      h("div", { class: "row" },
        h("button", { class: "btn", onclick: async () => { S.settings.team.name = name.value.trim(); const { saveSettings } = await import("../core.js"); saveSettings(); await T().set(tok.value || null, inbox.value); const c = await T().check(); toast(c.ok ? "Team key works ✓" : c.error); render(); } }, "Save & test"),
        st.hasToken ? h("button", { class: "btn ghost", onclick: async () => { await T().set("", null); render(); } }, "Remove key") : null,
        h("button", { class: "btn", onclick: () => openInbox() }, "Open inbox"), pub),
      h("label", { class: "f" }, "New songs get the next number in", newBook),
      out,
      h("div", { class: "dim", style: "font-size:11.5px" }, "Key: github.com → Settings → Developer settings → Fine-grained tokens → only the repositories “revival-song-inbox” and “revival-worship-releases”, permission Contents: Read and write. It stays on this computer."));
  };
  render();
  return box;
}
