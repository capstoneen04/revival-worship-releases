// What actually goes to YouTube (2.6): OBS's own audio meters for the inputs that feed the stream's audio track.
//
// 22 Nov 2026 the desk said "No sound going to YouTube" for minutes while the OBS recording of that service has sound
// in every minute: the old check listened to the ATEM's USB audio on its own (a second capture of the device), not to what
// OBS sends. This module reads OBS's InputVolumeMeters for:
//   • the global audio sources (Settings → Audio: Desktop Audio, Mic/Aux), and
//   • sources shown in the program scene,
// that are not muted and have the stream's track ticked (Advanced Audio Properties; track 1 unless the profile says
// otherwise). The level is the loudest of them, post-fader (what the OBS mixer bars show).
// If the meter feed stops (OBS not connected, events missing) read() says ok:false — never "silence".
import { S, sessionLog } from "./core.js";

const STALE_MS = 3000;
export const obsMeter = {
  levels: new Map(),          // inputName → { db, at }
  watched: [],                // input names feeding the stream track
  track: "1",
  lastTrack: "",
  lastEvent: 0,
  refreshing: false,
  lastRefresh: 0,
  read() {
    const now = Date.now();
    if (!S.obs?.connected || now - this.lastEvent > STALE_MS) return { ok: false, db: null, names: this.watched };
    let db = -Infinity;
    for (const n of this.watched) { const l = this.levels.get(n); if (l && now - l.at < STALE_MS && l.db > db) db = l.db; }
    return { ok: true, db, names: this.watched };
  },
};

const toDb = (mul) => (mul > 0 ? 20 * Math.log10(mul) : -Infinity);

function onEvent(e) {
  const d = e.detail || {};
  if (d.eventType === "InputVolumeMeters") {
    const now = Date.now(); obsMeter.lastEvent = now;
    for (const i of d.eventData?.inputs || []) {
      const ch = i.inputLevelsMul || [];
      let m = 0; for (const c of ch) if (c && c[0] > m) m = c[0];            // [magnitude, peak, inputPeak] per channel
      obsMeter.levels.set(i.inputName, { db: toDb(m), at: now });
    }
  } else if (/^(CurrentProgramSceneChanged|InputMuteStateChanged|InputAudioTracksChanged|SceneItemEnableStateChanged|InputCreated|InputRemoved|InputNameChanged)$/.test(d.eventType)) {
    refreshWatched().catch(() => { });
  }
}

export async function refreshWatched() {
  const obs = S.obs; if (!obs?.connected || obsMeter.refreshing) return;
  obsMeter.refreshing = true;
  try {
    // which track goes to the stream (Simple output = track 1)
    try {
      const mode = await obs.call("GetProfileParameter", { parameterCategory: "Output", parameterName: "Mode" });
      if (/advanced/i.test(mode.parameterValue || "")) {
        const t = await obs.call("GetProfileParameter", { parameterCategory: "AdvOut", parameterName: "TrackIndex" });
        obsMeter.track = String(t.parameterValue || t.defaultParameterValue || "1");
      } else obsMeter.track = "1";
    } catch { obsMeter.track = "1"; }
    const special = new Set(Object.values(await obs.call("GetSpecialInputs").catch(() => ({}))).filter(Boolean));
    const { inputs } = await obs.call("GetInputList");
    const out = [];
    for (const i of inputs) {
      const name = i.inputName;
      let tracks; try { tracks = (await obs.call("GetInputAudioTracks", { inputName: name })).inputAudioTracks; } catch { continue; }   // no audio
      if (tracks && tracks[obsMeter.track] === false) continue;
      try { if ((await obs.call("GetInputMute", { inputName: name })).inputMuted) continue; } catch { }
      if (!special.has(name)) {
        try { const a = await obs.call("GetSourceActive", { sourceName: name }); if (!a.videoActive) continue; } catch { continue; }
      }
      out.push(name);
    }
    const was = obsMeter.watched.join("|") + "@" + obsMeter.lastTrack;
    obsMeter.watched = out; obsMeter.lastRefresh = Date.now();
    if (out.join("|") + "@" + obsMeter.track !== was) sessionLog(`obs meter track=${obsMeter.track} watching=[${out.join(", ") || "none"}]`);   // what the sound check listens to
    obsMeter.lastTrack = obsMeter.track;
  } finally { obsMeter.refreshing = false; }
}

let started = false;
export function startObsMeter() {
  if (started || !S.obs) return; started = true;
  S.obs.addEventListener("event", onEvent);
  S.obs.addEventListener("connected", () => setTimeout(() => refreshWatched().catch(() => { }), 1500));
  S.obs.addEventListener("disconnected", () => { obsMeter.watched = []; obsMeter.levels.clear(); });
  setInterval(() => { if (S.obs.connected && Date.now() - obsMeter.lastRefresh > 15000) refreshWatched().catch(() => { }); }, 5000);
  if (S.obs.connected) refreshWatched().catch(() => { });
}
