import { S, h, db, saveSettings, toast, modal, openOutput, native, loadLibrary, LANGS, sendTheme } from "../core.js";
import { exportBackup, importBackup, setSetting, saveBackupToFolder } from "../db.js";
import { BACKGROUNDS } from "../render.js";
import { uiPref, setUi } from "../ui-theme.js";

export function settingsView(root) {
  const page = h("div", { class: "pagepad" });
  root.appendChild(page);
  async function render() {
    const st = S.settings, th = st.theme;
    page.innerHTML = "";
    const songs = S.songs;
    const counts = { total: songs.length, fix: songs.filter(s => s.status === "fix").length, ok: songs.filter(s => s.status === "ok").length };
    const langSel = (key, none) => { const s = h("select", { class: "input" }, none ? h("option", { value: "" }, "— none —") : null, ...Object.entries(LANGS).map(([k, v]) => h("option", { value: k }, v))); s.value = st[key] || ""; s.onchange = () => { st[key] = s.value; saveSettings(); }; return s; };
    const name = h("input", { class: "input", value: st.churchName }); name.onchange = () => { st.churchName = name.value; th.churchName = name.value; saveSettings(); };
    const lps = h("select", { class: "input" }, ...[2, 3, 4, 5, 6, 8].map(n => h("option", { value: n }, `${n} lines`))); lps.value = st.linesPerSlide; lps.onchange = () => { st.linesPerSlide = +lps.value; saveSettings(); };
    const ac = h("input", { type: "checkbox", checked: st.autoChorus }); ac.onchange = () => { st.autoChorus = ac.checked; saveSettings(); };
    const bgFile = h("input", { type: "file", accept: "image/*", style: "display:none" });
    bgFile.onchange = () => { const f = bgFile.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { downscale(r.result, 1920).then(u => { th.bgImage = u; th.bg = "image"; saveSettings(); render(); }); }; r.readAsDataURL(f); };
    const scale = h("input", { type: "range", min: 0.6, max: 1.4, step: 0.05, value: th.scale }); scale.oninput = () => { th.scale = +scale.value; saveSettings(); };
    const dim = h("input", { type: "range", min: 0, max: 0.8, step: 0.05, value: th.dim }); dim.oninput = () => { th.dim = +dim.value; saveSettings(); };
    const col = (k) => { const c = h("input", { type: "color", value: th[k], style: "width:60px;height:30px;border:0;background:none" }); c.onchange = () => { th[k] = c.value; saveSettings(); }; return c; };
    const chk = (k, label) => { const c = h("input", { type: "checkbox", checked: !!th[k] }); c.onchange = () => { th[k] = c.checked; saveSettings(); }; return h("label", { class: "row", style: "gap:6px" }, c, label); };
    let info = null; try { info = await fetch("/api/info").then(r => r.json()); } catch { }
    const displays = native?.displays ? await native.displays() : null;

    page.append(h("div", { class: "two" },
      h("div", { class: "col", style: "gap:14px" },
        h("div", { class: "card col" }, h("div", { style: "font-weight:650;font-size:14px" }, "Church"), h("label", { class: "f" }, "Name shown on the logo screen and title cards", name)),
        h("div", { class: "card col" },
          h("div", { style: "font-weight:650;font-size:14px" }, "Projector look"),
          h("div", { class: "row" }, ...Object.entries(BACKGROUNDS).map(([k, v]) => h("div", { class: "swatch" + (th.bg === k ? " on" : ""), title: k, style: `background:${v}`, onclick: () => { th.bg = k; saveSettings(); render(); } })),
            h("div", { class: "swatch" + (th.bg === "image" ? " on" : ""), title: "Your image", style: th.bgImage ? `background:url(${th.bgImage}) center/cover` : "display:grid;place-items:center;font-size:18px", onclick: () => bgFile.click() }, th.bgImage ? "" : "+"), bgFile,
            h("div", { class: "swatch" + (th.bg === "video" ? " on" : ""), title: "Moving background", style: "display:grid;place-items:center;font-size:16px", onclick: () => pickVideoBg(th) }, "🎬")),
          th.bg === "video" ? h("div", { class: "dim", style: "font-size:12px" }, "Moving background: " + decodeURIComponent((th.bgVideo || "").split("/").pop() || "—") + " · ", h("a", { href: "#", onclick: (e) => { e.preventDefault(); pickVideoBg(th); } }, "change")) : null,
          h("div", { class: "row" }, h("label", { class: "f", style: "flex:1" }, "Text size", scale), h("label", { class: "f", style: "flex:1" }, "Darken background image", dim)),
          h("div", { class: "row" }, h("label", { class: "f" }, "Main text", col("color")), h("label", { class: "f" }, "Second language", col("color2")),
            h("label", { class: "f" }, "Font", (() => { const s = h("select", { class: "input" }, h("option", { value: "sans" }, "Sans"), h("option", { value: "serif" }, "Serif")); s.value = th.font; s.onchange = () => { th.font = s.value; saveSettings(); }; return s; })()),
            h("label", { class: "f" }, "Align", (() => { const s = h("select", { class: "input" }, h("option", { value: "center" }, "Centre"), h("option", { value: "left" }, "Left")); s.value = th.align; s.onchange = () => { th.align = s.value; saveSettings(); }; return s; })())),
          h("div", { class: "row" }, chk("shadow", "Text shadow"), chk("footer", "Song title / reference at the bottom"), chk("uppercase", "UPPERCASE"))),
        h("div", { class: "card col" },
          h("div", { style: "font-weight:650;font-size:14px" }, "Slides"),
          h("div", { class: "row" }, h("label", { class: "f" }, "Lines per slide", lps), h("label", { class: "row", style: "gap:6px;margin-top:16px" }, ac, "Repeat the chorus after every verse")),
          h("div", { class: "row" }, h("label", { class: "f" }, "Hindi songs show", langSel("lang1")), h("label", { class: "f" }, "with", langSel("lang2", true))),
          h("div", { class: "row" }, h("label", { class: "f" }, "Other songs show", langSel("lang1en")), h("label", { class: "f" }, "with", langSel("lang2en", true))))),
      h("div", { class: "col", style: "gap:14px" },
        h("div", { class: "card col" },
          h("div", { style: "font-weight:650;font-size:14px" }, "Screens"),
          displays ? h("div", { class: "col" }, ...displays.map(d => h("div", { class: "row" }, h("div", { style: "flex:1" }, `${d.label}${d.primary ? " (this screen)" : ""}`, h("span", { class: "dim" }, ` ${d.width}×${d.height}`)),
            h("button", { class: "btn sm", onclick: () => native.openOutput("projector", d.id) }, "Projector here"), h("button", { class: "btn sm", onclick: () => native.openOutput("stage", d.id) }, "Stage here")))) :
            h("div", { class: "muted", style: "font-size:12.5px" }, "Open the projector window, drag it to the projector screen and double-click it to go full screen."),
          h("div", { class: "row" }, h("button", { class: "btn", onclick: () => openOutput("projector") }, "Open projector window"), h("button", { class: "btn", onclick: () => openOutput("stage") }, "Open stage display"), native ? h("button", { class: "btn ghost", onclick: () => native.closeOutputs() }, "Close outputs") : null)),
        h("div", { class: "card col" },
          h("div", { style: "font-weight:650;font-size:14px" }, "Phone remote & other screens"),
          info ? h("div", { class: "col" }, h("div", { class: "muted", style: "font-size:12.5px" }, "On a phone or tablet on the same Wi-Fi, open:"), ...info.addresses.map(a => h("div", { class: "copyable" }, `http://${a}:${info.port}/remote.html`)),
            h("div", { class: "muted", style: "font-size:12.5px" }, "Stage display on any screen:"), ...info.addresses.slice(0, 1).map(a => h("div", { class: "copyable" }, `http://${a}:${info.port}/output.html?mode=stage`)),
            h("div", { class: "muted", style: "font-size:12.5px" }, "Congregation songbook (read-only):"), ...info.addresses.slice(0, 1).map(a => h("div", { class: "copyable" }, `http://${a}:${info.port}/songbook.html`)),
            h("div", { class: "muted", style: "font-size:12.5px" }, "Phone songbook — anywhere, works offline (Android: menu ⋮ → Install app; asks the church library password once):"), h("div", { class: "copyable" }, "https://capstoneen04.github.io/revival-worship-releases/songbook/"))
            : h("div", { class: "muted", style: "font-size:12.5px" }, "The phone remote works when the Revival Mac app is running.")),
        h("div", { class: "card col" },
          h("div", { style: "font-weight:650;font-size:14px" }, "Library"),
          h("div", {}, `${counts.total.toLocaleString()} songs · ${counts.ok} approved · ${counts.fix} need fixing`),
          h("div", { class: "muted", style: "font-size:12.5px" }, "Songs imported from the old books are marked “Not reviewed”; ones with garbled Hindi from the PDF are marked “Needs fixing”. Filter by status in Songs to work through them."),
          h("div", { class: "row" },
            h("button", { class: "btn", onclick: async () => { const data = await exportBackup(); const a = h("a", { href: URL.createObjectURL(new Blob([JSON.stringify(data)], { type: "application/json" })), download: `revival-backup-${new Date().toISOString().slice(0, 10)}.json` }); a.click(); } }, "Download backup"),
            (() => { const f = h("input", { type: "file", accept: ".json", style: "display:none" }); f.onchange = async () => { const t = await f.files[0].text(); modal("Restore this backup?", h("p", { class: "muted" }, "This replaces the songs, services, quotes and settings on this computer."), [{ label: "Cancel" }, { label: "Restore", cls: "live", fn: async () => { await importBackup(JSON.parse(t)); location.reload(); } }]); }; return h("span", {}, f, h("button", { class: "btn", onclick: () => f.click() }, "Restore backup")); })(),
            h("button", { class: "btn ghost", onclick: () => modal("Reload the original library?", h("p", { class: "muted" }, "Re-imports all songs from the songbooks. Your edits to songs will be lost (services and quotes are kept). Download a backup first."), [{ label: "Cancel" }, { label: "Reload", cls: "live", fn: async () => { await db.clear("songs"); await setSetting("seedVersion", 0); await setSetting("seedPlain", 1); location.reload(); } }]) }, "Reset song library")),
          h("div", { class: "dim", style: "font-size:11.5px" }, "Everything is stored on this Mac. Keyboard: ⌘1–7 switch pages, ⌘F search.")),
        biblesCard(), screensCard(), controlCard(), updatesCard(), lookCard(), backupCard())));
  }
  return { onShow: render };
}

// Moving (video) backgrounds: Media/Backgrounds and Media/Videos
async function pickVideoBg(th) {
  const get = (d) => fetch("/api/media?dir=" + d).then(r => r.json()).then(j => (j.files || []).filter(f => /\.(mp4|m4v|mov|webm)$/i.test(f.name))).catch(() => []);
  const files = [...await get("Backgrounds"), ...await get("Videos")];
  const grid = h("div", { class: "pics" }, ...files.map(f => h("button", { class: "pic" + (th.bgVideo === f.url ? " on" : ""), onclick: () => { th.bg = "video"; th.bgVideo = f.url; saveSettings(); document.querySelector(".modal-bg")?.remove(); window.rwShow("settings"); } },
    h("video", { src: f.url, muted: true, autoplay: true, loop: true, style: "width:100%;aspect-ratio:16/9;object-fit:cover;display:block" }), h("div", { style: "padding:4px 6px;font-size:11.5px" }, f.name.replace(/\.[^.]+$/, "")))));
  modal("Moving background", h("div", { class: "col" },
    files.length ? grid : h("div", { class: "warnline" }, "No videos yet."),
    h("div", { class: "muted", style: "font-size:12px" }, "Loops without sound behind the words. Add your own .mp4 files to Media › Backgrounds."),
    native?.openMediaFolder ? h("button", { class: "btn ghost sm", onclick: () => native.openMediaFolder("Backgrounds") }, "Open Backgrounds folder") : null), [{ label: "Close" }]);
}

// Screens: projector language layout, stage display layout, camera
function screensCard() {
  const sc = S.settings.screens ||= {}; const pj = sc.projector ||= {}; const st = sc.stage ||= {}; const cam = sc.camera ||= {};
  const save = () => saveSettings();
  const seg = (obj, key, opts, after) => h("div", { class: "seg" }, ...opts.map(([v, l]) => h("button", { class: "btn sm" + ((obj[key] ?? opts[0][0]) === v ? " on" : ""), onclick: (e) => { obj[key] = v; save(); e.target.parentNode.querySelectorAll(".btn").forEach(b => b.classList.toggle("on", b === e.target)); after && after(); } }, l)));
  const split = h("input", { type: "range", min: 0.5, max: 1, step: 0.02, value: pj.split ?? 0.82, oninput: (e) => { pj.split = +e.target.value; save(); } });
  const ck = (obj, key, label, def = false) => h("label", { class: "row", style: "gap:6px" }, h("input", { type: "checkbox", checked: obj[key] ?? def, onchange: (e) => { obj[key] = e.target.checked; save(); } }), label);
  const camSel = h("select", { class: "input", style: "flex:1" }, h("option", { value: "" }, "ATEM / first camera"));
  navigator.mediaDevices?.enumerateDevices?.().then(ds => ds.filter(d => d.kind === "videoinput" && d.label).forEach(d => camSel.appendChild(h("option", { value: d.label, selected: d.label === cam.device }, d.label)))).catch(() => { });
  camSel.onchange = () => { cam.device = camSel.value; save(); };
  return h("div", { class: "card col" },
    h("div", { style: "font-weight:650;font-size:14px" }, "Screens"),
    h("div", { class: "muted", style: "font-size:12.5px" }, "Projector — two languages"),
    h("div", { class: "row" }, seg(pj, "layout", [["stacked", "One under the other"], ["side", "Side by side"]]), ck(pj, "swap", "Swap languages"), ck(pj, "showSecond", "Show the second language", true)),
    h("label", { class: "f" }, "Second language size", split),
    h("div", { class: "muted", style: "font-size:12.5px;margin-top:6px" }, "Stage display"),
    seg(st, "layout", [["classic", "Now + next"], ["lyrics", "Big lyrics"], ["musician", "Musicians (chords)"], ["preacher", "Preacher (timer)"]]),
    ck(st, "chords", "Show chords in the musicians' layout", true),
    h("div", { class: "muted", style: "font-size:12.5px;margin-top:6px" }, "Camera on the projector (Live → Camera)"),
    h("div", { class: "row", style: "flex-wrap:nowrap" }, camSel));
}

// Bible versions: pick the main + second Bible, add more from files (Zefania / OSIS / USFX)
function biblesCard() {
  const box = h("div", { class: "card col" });
  const render = async () => {
    const { listBibles, setBibleMap } = await import("../bible.js");
    const list = await listBibles(); const bs = S.settings.bibles ||= { v1: "kjv", v2: "hindi" };
    const sel = (key) => { const s = h("select", { class: "input" }, ...list.map(b => h("option", { value: b.id, selected: b.id === bs[key] }, b.title))); s.onchange = () => { bs[key] = s.value; setBibleMap({ kjv: bs.v1, hindi: bs.v2 }); saveSettings(); toast("Bible versions changed"); }; return s; };
    box.innerHTML = "";
    box.append(h("div", { style: "font-weight:650;font-size:14px" }, "Bible versions"),
      h("div", { class: "row" }, h("label", { class: "f", style: "flex:1" }, "Main Bible", sel("v1")), h("label", { class: "f", style: "flex:1" }, "Second Bible (shown under it)", sel("v2"))),
      h("div", { class: "muted", style: "font-size:12.5px" }, `${list.length} installed: ` + list.map(b => b.title).join(" · ")),
      h("div", { class: "row" }, h("button", { class: "btn", onclick: addBible }, "Add a Bible version…"),
        ...list.filter(b => b.where === "added").map(b => h("button", { class: "btn sm ghost", title: "Remove " + b.title, onclick: () => modal("Remove " + b.title + "?", h("p", { class: "muted" }, "You can add it again from its file."), [{ label: "Cancel" }, { label: "Remove", cls: "live", fn: async () => { await fetch("/api/bible-remove?id=" + b.id, { method: "POST" }); render(); } }]) }, "✕ " + b.title))),
      h("div", { class: "dim", style: "font-size:11.5px" }, "Free Bibles in many Indian languages (e.g. Marathi IRV, Hindi IRV) can be downloaded from ebible.org as Zefania, OSIS or USFX XML."));
  };
  async function addBible() {
    const { readBibleFile } = await import("../bible-import.js");
    const f = h("input", { type: "file", accept: ".xml,.json,.osis,.usfx,.zef" });
    const id = h("input", { class: "input", placeholder: "Short name, e.g. marathi-irv" }), title = h("input", { class: "input", placeholder: "Title shown in the app, e.g. Marathi IRV" });
    const info = h("div", { class: "muted", style: "font-size:12.5px;min-height:18px" }, "");
    let bible = null;
    f.onchange = async () => { info.textContent = "Reading…"; try { bible = await readBibleFile(f.files[0]); info.textContent = `${bible.format}: ${bible.verses.toLocaleString()} verses · first book “${bible.books[0]}”`; if (!title.value) title.value = bible.title || f.files[0].name.replace(/\.[^.]+$/, ""); if (!id.value) id.value = title.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30); } catch (e) { bible = null; info.textContent = e.message; } };
    modal("Add a Bible version", h("div", { class: "col" }, h("button", { class: "btn", onclick: () => f.click() }, "Choose file…"), info, h("label", { class: "f" }, "Title", title), h("label", { class: "f" }, "Short name", id)),
      [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: async () => {
        if (!bible) { toast("Choose a Bible file first"); return false; }
        const r = await fetch("/api/bible-import?id=" + encodeURIComponent(id.value), { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ title: title.value || id.value, description: title.value, copyright: "", books: bible.books, text: bible.text }) });
        if (!r.ok) { toast("Could not add: " + await r.text()); return false; }
        toast(title.value + " added"); render();
      } }]);
  }
  render().catch(() => { });
  return box;
}

// Stream Deck / Companion buttons
function controlCard() {
  const box = h("div", { class: "card col" }, h("div", { style: "font-weight:650;font-size:14px" }, "Stream Deck & buttons"));
  fetch("/api/control-info").then(r => r.json()).then(ci => {
    const base = `http://localhost:${ci.port}/api/control/`, lan = ci.addresses[0] ? `http://${ci.addresses[0]}:${ci.port}/api/control/` : "";
    box.append(h("div", { class: "muted", style: "font-size:12.5px" }, "In Bitfocus Companion (Stream Deck) add a “Generic HTTP → GET” action with one of these addresses. On this computer no key is needed; from another computer add ?key=" + ci.key + "."),
      ...[["next", "Next slide"], ["prev", "Previous"], ["blank", "Blank"], ["logo", "Logo"], ["clear", "Clear text"], ["lower", "Lyrics on stream"], ["camera", "Camera on projector"], ["timer-start?minutes=45", "Start 45-min timer"], ["timer-pause", "Pause timer"], ["timer-reset", "Reset timer"], ["scene?name=Sermon", "OBS scene “Sermon”"], ["audience?text=Hello", "Audience message"]]
        .map(([c, l]) => h("div", { class: "row", style: "flex-wrap:nowrap;gap:8px" }, h("span", { style: "width:150px;flex:0 0 150px;font-size:12.5px" }, l), h("div", { class: "copyable", style: "flex:1" }, base + c))),
      lan ? h("div", { class: "dim", style: "font-size:11.5px" }, `From another computer: ${lan}next?key=${ci.key}`) : null);
  }).catch(() => box.append(h("div", { class: "muted" }, "Works in the Revival Worship app.")));
  return box;
}

// Updates from GitHub (Settings → Updates)
function updatesCard() {
  const box = h("div", { class: "card col", id: "upd-card" });
  const U = native?.updates;
  let tok = 0;
  const render = async (st) => {
    const my = ++tok;
    st = st || await U.status();
    if (my !== tok) return;                                  // a newer render started meanwhile
    const cfg = st.config || {};
    const live = !!S.obsStats?.stream;
    const line = {
      idle: "Not checked yet", checking: "Checking GitHub…", current: `You have the newest version`, none: "No updates published yet",
      downloading: `Downloading ${st.what || "update"}… ${st.progress || 0}%`, installing: "Unpacking the update…",
      available: `Version ${st.latest} is available`, ready: `Version ${st.latest} is downloaded — it starts after a restart`,
      installer: `Version ${st.latest} needs the full installer (a bigger change)`, failed: `Version ${st.latest} did not start properly, so the app went back to ${st.running}`, error: "Could not check: " + (st.error || ""),
    }[st.state] || st.state;
    box.innerHTML = "";
    box.append(
      h("div", { style: "font-weight:650;font-size:14px" }, "Updates"),
      h("div", {}, h("b", {}, `Version ${st.running || "?"}`), h("span", { class: "muted" }, st.fromUpdate ? ` (updated · installed ${st.installed})` : " (installed)")),
      h("div", { class: "muted", style: "font-size:12.5px" }, line + (st.checkedAt ? ` · checked ${new Date(st.checkedAt).toLocaleString([], { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}` : "")),
      typeof st.libNote === "string" && st.libNote ? h("div", { class: "muted", style: "font-size:12.5px" }, st.libNote) : null,
      st.notes && ["ready", "available", "installer"].includes(st.state) ? h("div", { class: "copyable", style: "white-space:pre-wrap;user-select:text;font-family:inherit;max-height:140px;overflow:auto" }, st.notes) : null,
      h("div", { class: "row" },
        h("button", { class: "btn", disabled: ["checking", "downloading", "installing"].includes(st.state), onclick: async () => render(await U.check()) }, "Check now"),
        st.state === "ready" ? h("button", { class: "btn primary", disabled: live, title: live ? "Not while streaming" : "", onclick: () => modal("Restart to update?", h("p", { class: "muted" }, "Revival Worship closes and opens again with the new version (about 5 seconds). Projector and OBS overlays come back by themselves."), [{ label: "Later" }, { label: "Restart now", cls: "primary", fn: () => U.restart() }]) }, live ? "Restart after the stream" : "Restart now") : null,
        st.state === "failed" ? h("button", { class: "btn", onclick: () => U.latest() }, "Try it again") : null,
        st.state === "installer" && st.installer ? h("button", { class: "btn primary", onclick: () => native.openUrl(st.installer) }, "Download installer") : null,
        st.url ? h("button", { class: "btn ghost", onclick: () => native.openUrl(st.url) }, "What's new") : null),
      h("label", { class: "row", style: "gap:6px;font-size:12.5px" }, h("input", { type: "checkbox", checked: cfg.auto !== false, onchange: async (e) => { await U.config({ auto: e.target.checked }); } }), "Check and download updates by themselves (installs only when you restart)"),
      h("div", { class: "row", style: "gap:6px" },
        st.fromUpdate ? h("button", { class: "btn sm ghost", onclick: () => modal("Go back to the previous version?", h("p", { class: "muted" }, "Use this if something went wrong after an update. The app restarts with the version before this one."), [{ label: "Cancel" }, { label: "Go back", cls: "live", fn: () => U.previous() }]) }, "Go back to the previous version") : null,
        !st.fromUpdate && st.installed && st.latest && st.state === "current" ? null : null));
  };
  if (!U) { box.append(h("div", { style: "font-weight:650;font-size:14px" }, "Updates"), h("div", { class: "muted" }, "Updates work in the Revival Worship app.")); return box; }
  render().catch(() => { });
  U.onStatus((st) => { if (document.body.contains(box)) render({ ...st, config: undefined }).catch(() => { }); });
  return box;
}

// App look (light / dark / match the Mac)
function lookCard() {
  const p = uiPref();
  const opt = (k, lab, sub) => h("button", { class: "btn" + (p === k ? " on" : ""), onclick: (e) => { setUi(k); e.target.closest(".card").replaceWith(lookCard()); } }, lab);
  return h("div", { class: "card col" },
    h("div", { style: "font-weight:650;font-size:14px" }, "App look"),
    h("div", { class: "seg" }, opt("light", "☀︎ Light (white)"), opt("dark", "☾ Dark"), opt("auto", "◐ Match the Mac")),
    h("div", { class: "muted", style: "font-size:12.5px" }, "Only changes this app's screens. The projector, stage display and OBS graphics stay the same. Dark is easier on the eyes in a dim hall during the service; the ☾/☀︎ button at the top right switches quickly."));
}
// Backups & moving to another Mac
function backupCard() {
  const msg = h("div", { class: "muted", style: "font-size:12.5px" }, "");
  fetch("/api/setup").then(r => r.json()).then(s => {
    msg.textContent = `App folder: ${s.appDir.replace(/^\/Users\/[^/]+/, "~")}` + (s.copied ? ` · first-run setup copied ${s.copied} files` : "") + (s.errors?.length ? ` · ${s.errors.length} setup problems` : "");
  }).catch(() => { });
  return h("div", { class: "card col" },
    h("div", { style: "font-weight:650;font-size:14px" }, "Backups & another Mac"),
    h("div", { class: "muted", style: "font-size:12.5px" }, "The app saves a copy of the songs, members, services, themes and settings into Documents › Revival Church › Revival Worship App › Backup every 30 minutes (one file per day, 30 days kept). To set up another Mac: install the app there and copy the whole “Revival Worship App” folder across — the newest backup is loaded on first launch."),
    msg,
    h("div", { class: "row" },
      h("button", { class: "btn", onclick: async (e) => { e.target.disabled = true; try { await saveBackupToFolder(); toast("Backup saved"); } catch (er) { toast("Backup failed: " + er.message); } e.target.disabled = false; } }, "Back up now"),
      native?.openMediaFolder ? h("button", { class: "btn ghost", onclick: () => native.openMediaFolder("@backup") }, "Open Backup folder") : null,
      native?.openMediaFolder ? h("button", { class: "btn ghost", onclick: () => native.openMediaFolder("@app") }, "Open app folder") : null));
}

function downscale(dataUrl, max) {
  return new Promise(res => { const i = new Image(); i.onload = () => { const s = Math.min(1, max / i.width); const c = document.createElement("canvas"); c.width = i.width * s; c.height = i.height * s; c.getContext("2d").drawImage(i, 0, 0, c.width, c.height); res(c.toDataURL("image/jpeg", 0.86)); }; i.src = dataUrl; });
}
