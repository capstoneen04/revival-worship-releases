import { S, h, toast, modal, saveSong, uid, LANGS, present, showLowerCard } from "../core.js";
import { krutiToUnicode, looksLikeKruti } from "../krutidev.js";
import { romanize, capitalizeLines } from "../translit.js";
import { textToSections, sectionsToText } from "./songs.js";

const OCR_LANGS = { hin: "Hindi", eng: "English", mar: "Marathi", por: "Português", spa: "Español" };
let worker = null, workerLangs = "";

async function loadTesseract() {
  if (window.Tesseract) return;
  await new Promise((res, rej) => { const s = document.createElement("script"); s.src = "vendor/tesseract/tesseract.min.js"; s.onload = res; s.onerror = () => rej(new Error("Could not load OCR engine")); document.head.appendChild(s); });
}
async function getWorker(langs, logger) {
  await loadTesseract();
  const key = langs.join("+");
  if (worker && workerLangs === key) return worker;
  if (worker) { await worker.terminate(); worker = null; }
  const base = new URL(".", location.href).href;
  worker = await window.Tesseract.createWorker(langs, 1, {
    workerPath: base + "vendor/tesseract/worker.min.js",
    corePath: base + "vendor/tesseract/core",
    langPath: base + "vendor/tesseract/lang",
    gzip: true, workerBlobURL: false, logger,
  });
  workerLangs = key;
  return worker;
}

function prepCanvas(img, { enhance = true, rotate = 0 } = {}) {
  let w = img.naturalWidth || img.width, hgt = img.naturalHeight || img.height;
  const scale = w < 1400 ? Math.min(2.5, 1800 / w) : w > 3500 ? 3500 / w : 1;
  w = Math.round(w * scale); hgt = Math.round(hgt * scale);
  const c = document.createElement("canvas");
  const rot = ((rotate % 360) + 360) % 360;
  c.width = rot % 180 ? hgt : w; c.height = rot % 180 ? w : hgt;
  const x = c.getContext("2d");
  x.translate(c.width / 2, c.height / 2); x.rotate(rot * Math.PI / 180); x.drawImage(img, -w / 2, -hgt / 2, w, hgt);
  x.setTransform(1, 0, 0, 1, 0, 0);
  if (enhance) {
    const d = x.getImageData(0, 0, c.width, c.height), p = d.data;
    // grayscale + contrast stretch
    let min = 255, max = 0;
    for (let i = 0; i < p.length; i += 4) { const g = 0.299 * p[i] + 0.587 * p[i + 1] + 0.114 * p[i + 2]; p[i] = g; if (g < min) min = g; if (g > max) max = g; }
    const lo = min + (max - min) * 0.08, hi = max - (max - min) * 0.15, span = Math.max(1, hi - lo);
    for (let i = 0; i < p.length; i += 4) { let g = (p[i] - lo) / span * 255; g = g < 0 ? 0 : g > 255 ? 255 : g; p[i] = p[i + 1] = p[i + 2] = g; }
    x.putImageData(d, 0, 0);
  }
  return c;
}

export function cleanOcr(t, isHindi) {
  let s = t.replace(/\r/g, "");
  if (isHindi) s = s.replace(/\s*[|]\s*$/gm, "।").replace(/(\S)\s*\|\s*/g, "$1। ").replace(/ +([,।])/g, "$1").replace(/,।/g, ",");
  s = s.replace(/[ \t]+/g, " ").replace(/^ +| +$/gm, "").replace(/-\n(?=[a-z])/g, "");
  let lines = s.split("\n").map(l => {
    if (isHindi && /[\u0900-\u097F]/.test(l)) l = l.replace(/[\s.,:;'‘’"`~_\-a-zA-Z]{3,}$/, m => (/[a-zA-Z]{4,}/.test(m) ? m : (m.trim().startsWith(",") ? "," : "")));
    return l.trim();
  });
  // drop short junk lines (page edges, bleed-through)
  lines = lines.filter(l => !l || /[\u0900-\u097F]{3,}|[A-Za-zÀ-ÿ]{3,}/.test(l.replace(/\s/g, "")) && !(l.length < 12 && !(l.split(/\s+/).some(w => w.replace(/[^\u0900-\u097FA-Za-z]/g, "").length >= 3))));
  // Tesseract often puts a blank line after every line; collapse when that happens
  const text = lines.filter(Boolean).length, blanks = lines.filter(l => !l).length;
  if (blanks > text * 0.45) lines = lines.filter(Boolean);
  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

// OCR text -> section markup
export function smartMarkup(text) {
  const lines = text.split("\n");
  const out = []; let v = 0;
  for (const raw of lines) {
    const l = raw.trim();
    if (!l) { out.push(""); continue; }
    if (/^(chorus|coro|refr[aã]o|कोरस|को0)\s*[:.-]?\s*$/i.test(l)) { out.push("", "[Chorus]"); continue; }
    const m = l.match(/^\(?([0-9१-९])\s*[).।.-]\s*(.+)$/);
    if (m) { v++; out.push("", `[Verse ${v}]`, m[2]); continue; }
    out.push(l);
  }
  let txt = out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  if (!/^\[/.test(txt)) txt = (v ? "[Chorus]\n" : "[Verse 1]\n") + txt;
  return txt;
}

export function ocrView(root) {
  const langBoxes = Object.entries(OCR_LANGS).map(([k, v]) => { const cb = h("input", { type: "checkbox", value: k }); if (k === "hin" || k === "eng") cb.checked = true; return h("label", { class: "row", style: "gap:5px;cursor:pointer" }, cb, v); });
  const enhance = h("input", { type: "checkbox", checked: true });
  let rotate = 0;
  const fileIn = h("input", { type: "file", accept: "image/*", multiple: true, style: "display:none" });
  const drop = h("div", { class: "drop" }, h("div", { style: "font-size:15px;color:var(--text);margin-bottom:4px" }, "Drop photos of song pages here"), "or click to choose · JPG, PNG, HEIC screenshots · several at once is fine · you can also paste an image (⌘V)");
  const imgs = h("div", { class: "col" });
  const prog = h("div", { class: "progress" }, h("div", {}));
  const status = h("div", { class: "muted", style: "font-size:12px;min-height:18px" });
  const out = h("textarea", { class: "input", rows: 22, style: "font-family:var(--lyric);font-size:15px;width:100%", placeholder: "Recognised text appears here. You can edit it, or paste old Kruti Dev text and press “Fix Kruti Dev”." });
  let files = [];

  root.append(h("div", { class: "pagepad" }, h("div", { class: "two" },
    h("div", { class: "col" },
      h("div", { class: "card col" },
        h("div", { style: "font-weight:650;font-size:14px" }, "1 · Choose images"),
        drop, fileIn,
        h("div", { class: "row" }, h("span", { class: "muted" }, "Languages on the page:"), ...langBoxes),
        h("div", { class: "row" }, h("label", { class: "row", style: "gap:5px" }, enhance, "Improve contrast"), h("button", { class: "btn sm", onclick: () => { rotate = (rotate + 90) % 360; renderImgs(); } }, "Rotate ↻"), h("button", { class: "btn sm ghost", onclick: () => { files = []; renderImgs(); } }, "Remove images")),
        imgs),
      h("div", { class: "card col" }, h("div", { style: "font-weight:650;font-size:14px" }, "Tips"),
        h("div", { class: "muted", style: "font-size:12.5px;line-height:1.6" }, "Printed pages read well; handwriting less so — always check the result. Photograph straight-on in good light. Tick only the languages actually on the page: Hindi + English is the usual pair. Marathi uses the same script as Hindi, so tick Marathi for Marathi songs."))),
    h("div", { class: "col" },
      h("div", { class: "card col" },
        h("div", { class: "row" }, h("div", { style: "font-weight:650;font-size:14px;flex:1" }, "2 · Read and correct"), h("button", { class: "btn primary", id: "ocr-go", onclick: run }, "Read text from images")),
        prog, status, out,
        h("div", { class: "row" },
          h("button", { class: "btn sm", onclick: () => { out.value = krutiToUnicode(out.value); toast("Converted Kruti Dev → Unicode Hindi"); } }, "Fix Kruti Dev"),
          h("button", { class: "btn sm", onclick: () => { out.value = smartMarkup(out.value); } }, "Mark verses & chorus"),
          h("button", { class: "btn sm", onclick: () => { out.value = capitalizeLines(romanize(out.value)); } }, "Convert to Hinglish"),
          h("button", { class: "btn sm", onclick: async () => { await navigator.clipboard.writeText(out.value); toast("Copied"); } }, "Copy")),
        h("hr", { class: "sep" }),
        h("div", { style: "font-weight:650;font-size:14px" }, "3 · Use it"),
        h("div", { class: "row" },
          h("button", { class: "btn primary", onclick: saveAsSong }, "Save as new song"),
          h("button", { class: "btn", onclick: addToExisting }, "Add as language to a song"),
          h("button", { class: "btn live", onclick: () => { if (out.value.trim()) present({ type: "text", title: "", text: out.value.replace(/^\[.*\]$/gm, "") }); } }, "▶ Project as text"),
          h("button", { class: "btn", onclick: () => { const t = out.value.trim(); if (t) showLowerCard({ type: "text", lines: t.split("\n").filter(l => l && !/^\[/.test(l)).slice(0, 4) }); } }, "Lower third")))))));

  drop.onclick = () => fileIn.click();
  fileIn.onchange = () => addFiles([...fileIn.files]);
  drop.ondragover = e => { e.preventDefault(); drop.classList.add("over"); };
  drop.ondragleave = () => drop.classList.remove("over");
  drop.ondrop = e => { e.preventDefault(); drop.classList.remove("over"); addFiles([...e.dataTransfer.files].filter(f => f.type.startsWith("image/"))); };
  document.addEventListener("paste", e => {
    if (!root.classList.contains("on")) return;
    const items = [...(e.clipboardData?.items || [])].filter(i => i.type.startsWith("image/"));
    if (items.length) { e.preventDefault(); addFiles(items.map(i => i.getAsFile())); }
  });
  function addFiles(fs) { for (const f of fs) files.push({ file: f, url: URL.createObjectURL(f) }); renderImgs(); }
  function renderImgs() {
    imgs.innerHTML = "";
    files.forEach((f, i) => imgs.appendChild(h("div", { style: "position:relative" }, h("img", { class: "ocr-img", src: f.url, style: `transform:rotate(${rotate}deg)` }),
      h("button", { class: "btn sm", style: "position:absolute;top:6px;right:6px", onclick: () => { files.splice(i, 1); renderImgs(); } }, "✕"))));
  }
  async function run() {
    if (!files.length) { toast("Add an image first"); return; }
    const langs = langBoxes.map(l => l.querySelector("input")).filter(c => c.checked).map(c => c.value);
    if (!langs.length) { toast("Tick at least one language"); return; }
    const btn = root.querySelector("#ocr-go"); btn.disabled = true;
    const bar = prog.firstChild;
    try {
      status.textContent = "Loading OCR engine and language data…";
      const w = await getWorker(langs, m => { if (m.status) status.textContent = m.status.replace(/^./, c => c.toUpperCase()) + (m.progress ? ` ${Math.round(m.progress * 100)}%` : ""); if (m.status === "recognizing text") bar.style.width = Math.round(m.progress * 100) + "%"; });
      const texts = [];
      for (let i = 0; i < files.length; i++) {
        status.textContent = `Reading image ${i + 1} of ${files.length}…`;
        const img = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = files[i].url; });
        const canvas = prepCanvas(img, { enhance: enhance.checked, rotate });
        const { data } = await w.recognize(canvas);
        texts.push(cleanOcr(data.text, langs.includes("hin") || langs.includes("mar")));
      }
      let txt = texts.join("\n\n");
      if (looksLikeKruti(txt)) txt = krutiToUnicode(txt);
      out.value = txt; bar.style.width = "100%";
      status.textContent = `Done — ${txt.split("\n").filter(Boolean).length} lines. Check the text, then save it.`;
    } catch (e) { console.error(e); status.textContent = "OCR failed: " + e.message; }
    btn.disabled = false;
  }
  function detectLang(t) { if (/[ऀ-ॿ]/.test(t)) return langBoxes[2].querySelector("input").checked && !langBoxes[0].querySelector("input").checked ? "mr" : "hi"; if (/\b(não|você|coração|meu|minha|Senhor)\b/i.test(t)) return "pt"; if (/\b(el|los|mi|Señor|corazón|Dios)\b/.test(t)) return "es"; return "en"; }
  function saveAsSong() {
    const t = out.value.trim(); if (!t) { toast("Nothing to save"); return; }
    const markup = /^\[/m.test(t) ? t : smartMarkup(t);
    const firstLine = markup.split("\n").find(l => l && !/^\[/.test(l)) || "New song";
    const title = h("input", { class: "input", value: firstLine.replace(/[,।.]+$/, "") });
    const lang = h("select", { class: "input" }, ...Object.entries(LANGS).map(([k, v]) => h("option", { value: k }, v))); lang.value = detectLang(t);
    const book = h("input", { class: "input", placeholder: "Book & number, e.g. RH 97 (optional)" });
    const hl = h("input", { type: "checkbox", checked: true });
    modal("Save as new song", h("div", { class: "col" }, h("label", { class: "f" }, "Title", title), h("label", { class: "f" }, "Language", lang), h("label", { class: "f" }, "Book number", book), h("label", { class: "row", style: "gap:6px" }, hl, "Also create a Hinglish version (Hindi only)")),
      [{ label: "Cancel" }, { label: "Save", cls: "primary", fn: async () => {
        const secs = textToSections(markup);
        const song = { id: uid("s"), title: title.value.trim() || firstLine, lang: lang.value, key: "", tags: [], status: "review", source: "Image to text", books: [], versions: { [lang.value]: { title: title.value.trim() || firstLine, sections: secs } } };
        const bm = book.value.trim().match(/^([A-Za-z0-9]+)\s+(\d+)$/); if (bm) song.books.push({ book: bm[1].toUpperCase(), num: +bm[2] });
        if (lang.value === "hi" && hl.checked) song.versions["hi-Latn"] = { title: capitalizeLines(romanize(song.title)), auto: true, sections: secs.map(s => ({ label: s.label, lines: s.lines.map(l => capitalizeLines(romanize(l))) })) };
        await saveSong(song);
        toast("Song saved to the library");
        window.rwShow("songs"); window.rwViews?.songs?.select(song);
      } }]);
  }
  function addToExisting() {
    const t = out.value.trim(); if (!t) { toast("Nothing to add"); return; }
    const q = h("input", { class: "input", type: "search", placeholder: "Find the song…" });
    const res = h("div", { class: "list", style: "max-height:260px;overflow:auto;border:1px solid var(--line);border-radius:8px" });
    const lang = h("select", { class: "input" }, ...Object.entries(LANGS).map(([k, v]) => h("option", { value: k }, v))); lang.value = detectLang(t);
    let picked = null;
    q.oninput = () => { res.innerHTML = ""; S.index.search(q.value, { limit: 20 }).forEach(r => res.appendChild(h("div", { class: "item", onclick: (e) => { picked = r.song; res.querySelectorAll(".item").forEach(x => x.classList.remove("sel")); e.currentTarget.classList.add("sel"); } }, h("div", { class: "t" }, r.song.title)))); };
    modal("Add as a language version", h("div", { class: "col" }, q, res, h("label", { class: "f" }, "This text is in", lang)), [{ label: "Cancel" }, { label: "Add", cls: "primary", fn: async () => {
      if (!picked) { toast("Pick a song"); return false; }
      const markup = /^\[/m.test(t) ? t : smartMarkup(t);
      picked.versions[lang.value] = { title: picked.title, sections: textToSections(markup) };
      await saveSong(picked); toast(`${LANGS[lang.value]} added to “${picked.title}”`);
      window.rwShow("songs"); window.rwViews?.songs?.select(picked);
    } }]);
  }
  return {};
}
