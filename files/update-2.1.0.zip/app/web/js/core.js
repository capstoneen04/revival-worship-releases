// Shared app state + live presentation engine
import { db, getSetting, setSetting, uid } from "./db.js";
import { createBus } from "./bus.js";
import { songSlides, proseSlides, textSlides } from "./slides.js";
import { loadBible, getVerses, refLabel, setHindiNames } from "./bible.js";
import { SongIndex } from "./search.js";
import { OBSClient } from "./obs.js";
import { DEFAULT_THEME } from "./render.js";
// el.append(a, cond ? b : null) would print "null": skip empty children everywhere (like h() does)
for (const P of [Element.prototype, DocumentFragment.prototype]) { const orig = P.append; if (!orig.__rw) { P.append = function (...k) { return orig.apply(this, k.filter(c => c != null && c !== false)); }; P.append.__rw = true; } }

export const DEFAULT_SETTINGS = {
  churchName: "Revival Fellowship",
  linesPerSlide: 4, autoChorus: true,
  lang1: "hi", lang2: "",            // default display languages for Hindi songs
  lang1en: "en", lang2en: "",
  theme: { ...DEFAULT_THEME, churchName: "Revival Fellowship" },
  lowerStyle: { look: "pro", accent: "#1f6fe0", accent2: "#0b2f6e", logo: true },
  lowerAutoHide: 0,
  obs: { url: "ws://localhost:4455", password: "", autoConnect: true, connectedOnce: false, autoScenes: { song: "", bible: "", message: "", blank: "" } },
  bibleVersion: "both",
  themes: [], activeTheme: "",
  atem: { ip: "", auto: true },
  speakers: null,
  audio: { deviceId: "" },
  screens: { projector: { layout: "stacked", split: 0.82, swap: false, showSecond: true }, stage: { layout: "classic", chords: true }, camera: { device: "" } },
  bibles: { v1: "kjv", v2: "hindi" }, recent: [], timers: { sermonMinutes: 45 },
  broadcast: {
    serviceTitle: "Sunday Worship Service", speaker: "", sermonTitle: "",
    countdownTo: 0, startLabel: "Service begins shortly",
    verse: { text: "I was glad when they said unto me, Let us go into the house of the LORD.", ref: "Psalm 122:1" },
    announcements: ["Welcome to Revival Fellowship Mumbai", "Regular prayer meeting: every Sunday at 2:00 PM", "Prayer Hall: Mahavir Classes, 1st Floor, Peninsula, Behind R.K.T. College, Ulhasnagar"],
    ticker: "Welcome to Revival Fellowship Mumbai  •  Every Sunday 2:00 PM  •  Jesus Christ the same yesterday, and to day, and for ever — Hebrews 13:8",
    brbTitle: "Let us pray", brbText: "We will be right back",
    endTitle: "God Bless You", endText: "Thank you for worshipping with us",
    nextService: "Every Sunday · 2:00 PM", address: "Mahavir Classes, 1st Floor, Peninsula, Behind R.K.T. College, Ulhasnagar – 421 003",
    social: "YouTube · @RevivalChurchMumbai", accent: "#1f6fe0", gold: "#d4a24c",
    streamLang: "hi", streamSub: true, serviceCode: "", meeting: "", place: "", night: "",
    qotd: null, showQotd: true, look: "pro", streamName: "Revival Church Mumbai",
    headline: { a: "the", b: "EAGLES", c: "gathering", d: "TOGETHER" }, brandGold: "",
    startPicture: { src: "assets/img/backgrounds/eagle.jpg", layout: "left", zoom: 0.78, dx: -0.24, dy: 0.12, dim: 0 },
    endPicture: { src: "assets/img/backgrounds/cloud.jpg", layout: "left", zoom: 0.86, dx: -0.06, dy: 0.28, dim: 0.05 },
    music: { start: { on: true, dir: "Music/Start", volume: 0.55, shuffle: true, title: true }, end: { on: true, dir: "Music/End", volume: 0.5, shuffle: true, title: true } },
  },
};

export const S = {
  settings: structuredClone(DEFAULT_SETTINGS),
  books: {}, index: new SongIndex(), songs: [],
  service: null,
  live: { key: null, title: "", kind: null, slides: [], index: -1, override: "logo", item: null, fromService: false },
  lowerFollow: false, lowerManual: null, stageMessage: "", audienceMessage: "", timer: null,
  obs: new OBSClient(), obsScenes: { current: "", list: [] },
  busConnected: false,
};

const subs = new Set();
export function onChange(fn) { subs.add(fn); return () => subs.delete(fn); }
export function emit(what = "live") { subs.forEach(fn => { try { fn(what); } catch (e) { console.error(e); } }); }

export const bus = createBus("operator");
bus.on(m => {
  if (m.type === "_bus") { S.busConnected = m.connected; emit("bus"); }
  if (m.type === "need-state") { sendTheme(); broadcast(); sendBroadcast(); }
  if (m.type === "cmd") handleCmd(m);
  if (m.type === "quote-captured") emit({ quote: m.quote });
});

export function handleCmd(m) {
  switch (m.cmd) {
    case "next": next(); break;
    case "prev": prev(); break;
    case "blank": toggleOverride("blank"); break;
    case "logo": toggleOverride("logo"); break;
    case "clear": toggleOverride("clear"); break;
    case "lower": toggleLowerFollow(); break;
    case "goto": go(m.index); break;
    case "camera": toggleOverride("camera"); break;
    case "scene": if (m.name && S.obs.connected) S.obs.setScene(S.obsScenes.list.find(x => x.toLowerCase().includes(String(m.name).toLowerCase())) || m.name).catch(() => { }); break;
    case "timer-start": timerStart(m.minutes); break;
    case "timer-pause": timerPause(); break;
    case "timer-reset": timerReset(); break;
    case "audience": S.audienceMessage = m.text || ""; broadcast(); emit("live"); break;
    case "stage-message": S.stageMessage = m.text || ""; broadcast(); emit("live"); break;
  }
}

// ---------- settings ----------
export async function loadSettings() {
  const saved = await getSetting("app", null);
  if (saved) S.settings = deepMerge(structuredClone(DEFAULT_SETTINGS), saved);
}
export async function saveSettings() { await setSetting("app", S.settings); sendTheme(); broadcast(); sendBroadcast(); }
function deepMerge(a, b) { for (const k in b) { if (b[k] && typeof b[k] === "object" && !Array.isArray(b[k]) && a[k] && typeof a[k] === "object") deepMerge(a[k], b[k]); else a[k] = b[k]; } return a; }

export function sendBroadcast() { bus.send({ type: "broadcast", data: { ...S.settings.broadcast, churchName: S.settings.churchName, lowerStyle: S.settings.lowerStyle } }); }
export function sendTheme() { bus.send({ type: "theme", theme: { ...S.settings.theme, churchName: S.settings.churchName } }); }

// ---------- library ----------
export async function loadLibrary() {
  S.songs = await db.all("songs");
  S.books = await getSetting("books", {});
  S.index.build(S.songs);
}
export function songById(id) { return S.index.byId.get(id)?.song; }
export async function saveSong(song) {
  song.updated = new Date().toISOString();
  await db.put("songs", song);
  const i = S.songs.findIndex(s => s.id === song.id);
  if (i >= 0) S.songs[i] = song; else S.songs.push(song);
  S.index.upsert(song);
  emit("songs");
}
export async function deleteSong(id) { await db.del("songs", id); S.songs = S.songs.filter(s => s.id !== id); S.index.remove(id); emit("songs"); }

// ---------- service ----------
export async function loadService() {
  const id = await getSetting("currentService", null);
  if (id) S.service = await db.get("services", id);
  if (!S.service) { S.service = newService(); await db.put("services", S.service); await setSetting("currentService", S.service.id); }
}
export function newService(name) {
  const d = new Date();
  return { id: uid("svc"), name: name || "Sunday Service", date: d.toISOString().slice(0, 10), items: [] };
}
export async function saveService() { if (S.service) await db.put("services", S.service); emit("service"); }
export async function switchService(svc) { S.service = svc; await setSetting("currentService", svc.id); emit("service"); }
export function addToService(item) {
  item.id = item.id || uid("it");
  S.service.items.push(item); saveService(); toast(`Added to “${S.service.name}”`);
}
export function itemTitle(it) {
  if (it.type === "song") { const s = songById(it.songId); return s ? s.title : "(missing song)"; }
  if (it.type === "bible") return it.label || "Scripture";
  if (it.type === "message") return it.title || "Quote";
  if (it.type === "name") return it.name;
  if (it.type === "title") return it.title;
  if (it.type === "text") return it.title || (it.text || "").split("\n")[0];
  if (it.type === "sermon") return "Sermon: " + (it.sermon?.en?.title || it.sermon?.hi?.title || "notes");
  if (it.type === "header") return it.title || "Section";
  if (it.type === "media") return it.title || (it.src || "").split("/").pop() || "Media";
  return "Item";
}

// ---------- slides ----------
export function songOpts(song, it = {}) {
  const st = S.settings;
  const isHindi = !!song.versions.hi || song.lang === "hi-Latn";
  let lang1 = it.lang1 || (isHindi ? st.lang1 : st.lang1en);
  let lang2 = it.lang2 !== undefined ? it.lang2 : (isHindi ? st.lang2 : st.lang2en);
  if (!song.versions[lang1]) lang1 = song.versions[song.lang] ? song.lang : Object.keys(song.versions)[0];
  if (lang2 && !song.versions[lang2]) lang2 = "";
  return { lang1, lang2, linesPerSlide: it.linesPerSlide || st.linesPerSlide, autoChorus: it.autoChorus ?? st.autoChorus, order: it.order || null };
}

export async function buildSlides(it) {
  if (it.type === "song") { const s = songById(it.songId); return s ? songSlides(s, songOpts(s, it)) : []; }
  if (it.type === "bible") {
    const ver = it.version || S.settings.bibleVersion;
    const kjv = await loadBible("kjv"); const hin = await loadBible("hindi"); setHindiNames(hin.books);
    const r = it.ref;
    const en = getVerses(kjv, r), hi = getVerses(hin, r);
    const out = [];
    en.forEach((v, i) => {
      const one = { ...r, verse: v.v, to: null };
      const refTxt = ver === "hindi" ? refLabel(hin, one) : ver === "both" ? `${refLabel(kjv, one)} · ${refLabel(hin, one)}` : refLabel(kjv, one);
      const t1 = ver === "hindi" ? hi[i]?.text || "" : v.text;
      const t2 = ver === "both" ? hi[i]?.text || "" : "";
      out.push(...proseSlides(t1, { kind: "bible", title: it.label, ref: refTxt, text2: t2, maxChars: ver === "both" ? 170 : 240 }).map(s => ({ ...s, label: `v${v.v}` + (s.label ? ` ${s.label}` : ""), alt: { en: [v.text], hi: [hi[i]?.text || ""] }, refEn: refLabel(kjv, one), refHi: refLabel(hin, one) })));
    });
    return out;
  }
  if (it.type === "message") {
    const ref = [it.title, it.code, it.para ? `¶${it.para}` : ""].filter(Boolean).join(" · ");
    return proseSlides(it.text || "", { kind: "message", title: it.title, ref, maxChars: 260 });
  }
  if (it.type === "text") return textSlides(it.text || "", { title: it.title, linesPerSlide: S.settings.linesPerSlide });
  if (it.type === "sermon") return sermonSlides(it.sermon || {});
  if (it.type === "header") return [];
  if (it.type === "media") return [{ kind: "media", title: it.title || "", label: it.video ? "video" : "picture", src: it.src, video: !!it.video, loop: !!it.loop, lines: [] }];
  if (it.type === "name" || it.type === "title") return [{ kind: it.type, title: it.name || it.title, label: it.type, lines: [it.name || it.title], lines2: it.role ? [it.role] : null }];
  return [];
}

// Title / Subject / Inspiration / Scripture — English with Hindi (or the other way round on the stream toggle)
export const NOTE_PARTS = [["title", "Title", "शीर्षक"], ["sub", "Subject", "विषय"], ["ins", "Inspiration", "प्रेरणा"], ["scripture", "Scripture", "पवित्रशास्त्र"]];
export function sermonSlides(sm) {
  const out = [];
  for (const [k, en, hi] of NOTE_PARTS) {
    const e = (sm.en || {})[k] || "", x = (sm.hi || {})[k] || "";
    if (!e && !x) continue;
    const fix = (t) => k === "scripture" ? t.replace(/\s*:\s*/g, ":").replace(/\s*-\s*/g, "-").replace(/\s*;\s*/g, "  ·  ").replace(/[.]\s*$/, "") : t;
    out.push({ kind: "notes", part: k, title: sm.en?.title || "Sermon", label: en, kickerEn: en, kickerHi: hi, lines: [fix(e || x)], lines2: e && x ? [fix(x)] : null, alt: { en: e ? [fix(e)] : null, hi: x ? [fix(x)] : null }, ref: k === "title" && sm.page ? sm.page : "" });
  }
  return out;
}

// ---------- recent songs / verses (last 30 shown, like VerseVIEW) ----------
export function noteRecent(it) {
  if (!["song", "bible"].includes(it.type)) return;
  const r = S.settings.recent ||= [];
  const key = it.type === "song" ? "s:" + it.songId : "b:" + JSON.stringify(it.ref);
  const i = r.findIndex(x => x.key === key); if (i >= 0) r.splice(i, 1);
  r.unshift({ key, at: Date.now(), item: { type: it.type, songId: it.songId, ref: it.ref, version: it.version, label: it.label, v1: it.v1, v2: it.v2 } });
  r.length = Math.min(r.length, 30);
  clearTimeout(noteRecent._t); noteRecent._t = setTimeout(() => saveSettingsQuiet(), 2000);
}
async function saveSettingsQuiet() { await setSetting("app", S.settings); }

// ---------- live engine ----------
const SKIP = ["name", "title", "header"];
export async function present(it, index = 0, { fromService = false } = {}) {
  if (it.type === "name" || it.type === "title") { showLowerCard(it); return; }
  if (it.type === "header") return;
  noteRecent(it);
  const slides = await buildSlides(it);
  S.live = { key: it.id || uid("adhoc"), title: itemTitle(it), kind: it.type, slides, index: Math.min(index, slides.length - 1), override: null, item: it, fromService };
  autoScene(it.type);
  broadcast(); emit("live");
}
export function go(i) {
  if (!S.live.slides.length) return;
  S.live.index = Math.max(0, Math.min(S.live.slides.length - 1, i));
  S.live.override = null; broadcast(); emit("live");
}
export async function next() {
  if (S.live.override && S.live.slides.length) { S.live.override = null; broadcast(); emit("live"); return; }
  if (S.live.index < S.live.slides.length - 1) return go(S.live.index + 1);
  if (S.live.fromService && S.service) {
    const items = S.service.items; const i = items.findIndex(x => x.id === S.live.key);
    for (let j = i + 1; j < items.length; j++) if (!SKIP.includes(items[j].type)) return present(items[j], 0, { fromService: true });
  }
}
export async function prev() {
  if (S.live.index > 0) return go(S.live.index - 1);
  if (S.live.fromService && S.service) {
    const items = S.service.items; const i = items.findIndex(x => x.id === S.live.key);
    for (let j = i - 1; j >= 0; j--) if (!SKIP.includes(items[j].type)) { const sl = await buildSlides(items[j]); return present(items[j], sl.length - 1, { fromService: true }); }
  }
}
export function toggleOverride(kind) { S.live.override = S.live.override === kind ? null : kind; if (kind === "blank") autoScene("blank"); broadcast(); emit("live"); }
export function setOverride(kind) { S.live.override = kind; broadcast(); emit("live"); }
export function toggleLowerFollow() { S.lowerFollow = !S.lowerFollow; if (S.lowerFollow) S.lowerManual = null; broadcast(); emit("lower"); }
export function showLowerCard(card) {
  // card: {type:'name'|'title'|'message'|'bible'|'text', ...}
  const st = S.settings.lowerStyle;
  let l;
  if (card.type === "name") l = { kind: "name", lines: [card.name], kicker: card.role || "", };
  else if (card.type === "title") l = { kind: "title", kicker: card.kicker || S.settings.churchName, lines: [card.title], lines2: card.subtitle ? [card.subtitle] : null };
  else l = { kind: card.type, kicker: card.kicker || "", lines: card.lines || [], lines2: card.lines2 || null, ref: card.ref || "" };
  S.lowerManual = { ...l, visible: true, style: st, autoHide: card.autoHide ?? S.settings.lowerAutoHide };
  broadcast(); emit("lower");
}
export function hideLower() { S.lowerManual = null; S.lowerFollow = false; broadcast(); emit("lower"); }

// ---------- sermon / countdown timer (shown on the stage display) ----------
export function timerStart(minutes) {
  const t = S.timer;
  if (t && !t.running && minutes == null) { t.running = true; t.started = Date.now(); }         // resume
  else S.timer = { duration: Math.round((+minutes || S.settings.timers?.sermonMinutes || 45) * 60), elapsed: 0, started: Date.now(), running: true };
  broadcast(); emit("timer");
}
export function timerPause() { const t = S.timer; if (!t || !t.running) return; t.elapsed += (Date.now() - t.started) / 1000; t.running = false; broadcast(); emit("timer"); }
export function timerReset() { S.timer = null; broadcast(); emit("timer"); }
export function timerText() {
  const t = S.timer; if (!t) return "";
  const left = t.duration - (t.elapsed + (t.running ? (Date.now() - t.started) / 1000 : 0));
  const a = Math.abs(Math.round(left)); return (left < 0 ? "+" : "") + `${Math.floor(a / 60)}:${String(a % 60).padStart(2, "0")}`;
}

export function liveSlide() {
  if (S.live.override) return { kind: S.live.override };
  return S.live.slides[S.live.index] || { kind: "logo" };
}
// Stream language: what OBS shows can differ from the projector (Hindi / English toggle)
export function streamLines(sl) {
  const b = S.settings.broadcast || {};
  const lang = b.streamLang || "hi", sub = b.streamSub !== false;
  const a = sl.alt || {};
  let main, second = null;
  if (sl.kind === "song") {
    if (lang === "en") { main = a.en || a["hi-Latn"] || a.pt || sl.lines; if (sub) second = a.en ? (a.hi || null) : null; }
    else { main = a.hi || a["hi-Latn"] || sl.lines; if (sub) second = a.hi ? (a["hi-Latn"] || a.en || null) : null; }
  } else if (sl.kind === "bible") {
    if (lang === "en") { main = a.en || sl.lines; if (sub) second = a.hi || null; }
    else { main = a.hi || sl.lines; if (sub) second = a.en || null; }
  } else if (sl.kind === "notes") {
    if (lang === "en") { main = a.en || a.hi || sl.lines; second = sub && a.en ? a.hi : null; }
    else { main = a.hi || a.en || sl.lines; second = sub && a.hi ? a.en : null; }
  } else { main = sl.lines; second = sl.lines2; }
  if (second && main && second.join() === main.join()) second = null;
  return { main, second, lang };
}
function lowerState() {
  if (S.lowerManual) return S.lowerManual;
  const sl = liveSlide();
  if (S.lowerFollow && !S.live.override && sl && (sl.kind === "song" || sl.kind === "bible" || sl.kind === "message" || sl.kind === "text" || sl.kind === "notes")) {
    const kind = sl.kind === "song" ? "lyrics" : sl.kind;
    const { main, second, lang } = streamLines(sl);
    const ref = sl.kind === "bible" ? ((lang === "en" ? sl.refEn : sl.refHi) || sl.ref) + (second ? " · " + (lang === "en" ? sl.refHi : sl.refEn) : "") : sl.kind === "song" ? sl.ref : sl.ref;
    const kicker = sl.kind === "song" ? sl.title : sl.kind === "message" ? "The Message" : sl.kind === "bible" ? "Scripture" : sl.kind === "notes" ? sl.kickerEn : sl.title;
    return { visible: true, kind, kicker, lines: main, lines2: second, ref, style: S.settings.lowerStyle };
  }
  return { visible: false };
}
export function broadcast() {
  const live = liveSlide();
  const nxt = S.live.override ? S.live.slides[S.live.index] : S.live.slides[S.live.index + 1];
  bus.send({ type: "state", state: {
    live, next: nxt || null, index: S.live.override ? -1 : S.live.index, title: S.live.title,
    slides: S.live.slides.map(s => ({ label: s.label, lines: (s.lines || []).slice(0, 1) })),
    lower: lowerState(), stageMessage: S.stageMessage, audienceMessage: S.audienceMessage, timer: S.timer, screens: S.settings.screens, transpose: S.live.item?.transpose || 0, program: S.obs.connected ? S.obsScenes.current : "",
  } });
}

// ---------- OBS ----------
// Read OBS's WebSocket settings from this Mac (Mac app only) so nobody has to retype the password
export async function detectLocalOBS() {
  if (!native?.obsLocalConfig) return null;
  const c = await native.obsLocalConfig();
  if (!c || !c.found) return null;
  S.settings.obs.url = `ws://localhost:${c.port || 4455}`;
  S.settings.obs.password = c.auth ? c.password : "";
  S.settings.obs.useLocal = true;
  return c;
}
export async function obsConnect(quiet = false) {
  const o = S.settings.obs;
  const isLocal = /localhost|127\.0\.0\.1/.test(o.url);
  try {
    if (isLocal && (o.useLocal || !o.password)) await detectLocalOBS();
    await S.obs.connect(o.url, o.password);
    S.obsScenes = await S.obs.scenes();
    if (!o.connectedOnce) { o.connectedOnce = true; }
    await saveSettings();
    emit("obs"); if (!quiet) toast("Connected to OBS");
    return true;
  } catch (e) {
    if (isLocal && !o.useLocal && native?.obsLocalConfig) { o.useLocal = true; return obsConnect(quiet); }
    emit("obs"); if (!quiet) toast(e.message); return false;
  }
}
S.obs.addEventListener("event", e => {
  const d = e.detail;
  if (d.eventType === "CurrentProgramSceneChanged") { S.obsScenes.current = d.eventData.sceneName; emit("obs"); broadcast(); }
  if (d.eventType === "SceneListChanged") S.obs.scenes().then(s => { S.obsScenes = s; emit("obs"); });
});
S.obs.addEventListener("disconnected", () => emit("obs"));
function autoScene(kind) {
  const sc = S.settings.obs.autoScenes?.[kind];
  if (sc && S.obs.connected && S.obsScenes.current !== sc) S.obs.setScene(sc).catch(() => { });
}

// ---------- outputs ----------
export const native = window.revival || null;   // provided by the Mac app (Electron preload)
export function openOutput(mode = "projector") {
  if (native) return native.openOutput(mode);
  const w = window.open(`output.html?mode=${mode}`, `rw-${mode}`, "popup,width=960,height=540");
  if (!w) toast("Allow pop-ups to open the projector window"); else toast("Drag this window to the projector screen and double-click it for full screen");
}

// ---------- stream helpers ----------
export function dateCode(d = new Date()) {
  const b = S.settings.broadcast; if (b.serviceCode) return b.serviceCode;
  const yy = String(d.getFullYear()).slice(2), mm = String(d.getMonth() + 1).padStart(2, "0"), dd = String(d.getDate()).padStart(2, "0");
  return `${yy}${mm}${dd} ${d.getHours() < 15 ? "M" : "E"}`;
}
// Same pattern as the church's YouTube titles: "261018 M | Revival Church | Br. Royal | Sunday Service | Mumbai - 2"
export function streamTitle() {
  const b = S.settings.broadcast;
  return [dateCode(), "Revival Church", b.speakerShort || b.speaker, b.meeting || b.serviceTitle, [b.place, b.night].filter(Boolean).join(" - ")].filter(x => x && String(x).trim()).join(" | ");
}
export async function fetchQotd(force = false) {
  const b = S.settings.broadcast, today = new Date().toISOString().slice(0, 10);
  if (!force && b.qotd && b.qotd.date === today) return b.qotd;
  if (!native?.qotd) return b.qotd;
  const r = await native.qotd();
  if (r.ok) { b.qotd = { ...r.qotd, short: shortQuote(r.qotd.text) }; await saveSettings(); }
  return b.qotd;
}
// a screen-friendly excerpt (whole sentences, ~240 characters)
export function shortQuote(t = "") {
  const sents = t.replace(/\n+/g, " ").match(/[^.!?…]+[.!?…]+["”’]?\s*/g) || [t];
  let out = "";
  for (const s of sents) { if ((out + s).length > 240 && out) break; out += s; }
  return out.trim();
}

// ---------- ui helpers ----------
export function toast(msg, ms = 2600) {
  const t = document.createElement("div"); t.className = "toast"; t.textContent = msg; document.body.appendChild(t);
  setTimeout(() => t.remove(), ms);
}
export function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v; else if (k === "style") el.style.cssText = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "html") el.innerHTML = v; else el.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) if (c != null && c !== false) el.appendChild(typeof c === "string" || typeof c === "number" ? document.createTextNode(String(c)) : c);
  return el;
}
export function modal(title, body, actions = []) {
  const bg = h("div", { class: "modal-bg", onclick: e => { if (e.target === bg) bg.remove(); } },
    h("div", { class: "modal" }, h("h3", {}, title), body, h("div", { class: "row", style: "justify-content:flex-end;margin-top:14px" }, ...actions.map(a => h("button", { class: "btn " + (a.cls || ""), onclick: async () => { const r = await a.fn?.(); if (r !== false) bg.remove(); } }, a.label)))));
  document.body.appendChild(bg); return bg;
}
export const LANGS = { hi: "Hindi", "hi-Latn": "Hinglish", en: "English", mr: "Marathi", pt: "Português", es: "Español" };
export function isTyping() { const a = document.activeElement; return a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA" || a.tagName === "SELECT" || a.isContentEditable); }
export { uid, db };
